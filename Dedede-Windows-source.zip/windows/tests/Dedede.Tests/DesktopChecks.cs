using Dedede.Core;
using System.Diagnostics;
using System.Text.Json;

internal static class DesktopChecks
{
    public static async Task<int> Run(string assets,string root,bool benchmark)
    {
        int passed=0;void Assert(bool ok,string name){if(!ok)throw new Exception(name);passed++;}
        string temp=Path.Combine(Path.GetTempPath(),"Dedede-Workspace-Test-"+Guid.NewGuid().ToString("N"));
        try
        {
            var store=new LocalStore(temp);var r=new CheckResult{Original="甲乙",Changes=[new(){Start=1,Original="乙",Replacement="丙",Accepted=false,Confidence=.93f}]};
            store.SaveWorkspace(new(){Source="甲乙",Result=r,View=1});var saved=store.LoadWorkspace();
            Assert(saved.Source=="甲乙"&&saved.Result!.Corrected=="甲乙"&&!saved.Result.Changes[0].Accepted&&saved.View==1,"workspace restores all state");
            store.ClearWorkspace();store.SaveDraft("甲乙");store.AddHistory(r);Assert(store.LoadWorkspace().Result!.Changes[0].Confidence==.93f,"legacy draft upgrades matching history");store.SaveDraft("另一篇");Assert(store.LoadWorkspace().Result==null,"never pair unrelated result");store.ClearWorkspace();Assert(store.LoadWorkspace().Source=="","clear both draft formats");
            var undo=new RevisionUndo();undo.Record(r);r.Changes[0].Accepted=true;Assert(undo.Apply(r,false)&&r.Corrected=="甲乙","undo correction");Assert(undo.Apply(r,true)&&r.Corrected=="甲丙","redo correction");
            string indent=EditorActions.IndentParagraphs("第一行\r\n\r\n  第二行\n　　第三行\n");Assert(indent=="　　第一行\r\n\r\n　　第二行\n　　第三行\n","indent preserves line endings");Assert(EditorActions.IndentParagraphs(indent)==indent,"indent idempotent");
            Assert(EditorActions.CleanPunctuation("https://a:b/x,y;z")=="https://a:b/x,y;z","cleanup preserves English and URLs");
            Assert(CheckShortcut.Valid("Primary+Enter")&&CheckShortcut.Valid("Primary+Shift+Enter")&&CheckShortcut.Valid("F8"),"custom shortcut combinations");Assert(!CheckShortcut.Valid("Enter")&&!CheckShortcut.Valid("Primary+Z")&&!CheckShortcut.Valid("Alt+F4")&&!CheckShortcut.Valid("F11"),"preserve system and editing shortcuts");
        }
        finally{Directory.Delete(temp,true);}
        var config=new CheckSettings();
        using(var plain=new CorrectionEngine(assets,cacheEnabled:false))
        using(var cached=new CorrectionEngine(assets))
        {
            await cached.PrepareAsync(config);Assert(cached.IsModelLoaded,"background preparation");
            string input="他高兴的跳了起来。她认真得检查了刚才遗漏地内容。";
            var reference=await plain.CheckAsync(input,config);var first=await cached.CheckAsync(input,config);var second=await cached.CheckAsync(input,config);
            string Fingerprint(CheckResult r)=>JsonSerializer.Serialize(r.Changes);
            Assert(Fingerprint(reference)==Fingerprint(first)&&Fingerprint(first)==Fingerprint(second),"every correction and confidence unchanged by cache");Assert(second.CacheHits>0,"repeat inputs reused");
            var protectedResult=await cached.CheckAsync(input,config,new Dictionary<string,string>{{"高兴的","高兴的"}});Assert(protectedResult.Corrected.Contains("高兴的"),"new whitelist not bypassed by cache");
            var strict=config.Snapshot();strict.Thresholds=[1,1,1,1,1];Assert(Fingerprint(await plain.CheckAsync(input,strict))==Fingerprint(await cached.CheckAsync(input,strict)),"new thresholds applied to cached logits");
            await cached.ReleaseIfIdleAsync(TimeSpan.Zero);Assert(!cached.IsModelLoaded,"release model and cache");await cached.PrepareAsync(config);Assert(cached.IsModelLoaded,"prepare after release");
        }
        if(benchmark)
        {
            var measurements=new List<object>();string text="他作完作业就迅速的跑去了。";
            using var baseline=new CorrectionEngine(assets,cacheEnabled:false);using var updated=new CorrectionEngine(assets);
            async Task Measure(CorrectionEngine engine,string name,string value){var t=Stopwatch.StartNew();var r=await engine.CheckAsync(value,config);measurements.Add(new{name,wallMs=Math.Round(t.Elapsed.TotalMilliseconds,2),r.ModelCalls,r.CacheHits,characters=value.Length});}
            await Measure(baseline,"cold_without_preload",text);await Measure(baseline,"warm_without_cache",text);var preload=Stopwatch.StartNew();await updated.PrepareAsync(config);double preloadMs=preload.Elapsed.TotalMilliseconds;await Measure(updated,"prepared_first_check",text);await Measure(updated,"repeat_same_text",text);
            string document=string.Join("\n",Enumerable.Range(1,20).Select(n=>$"第{n}段。他认真得检查了这份报告，又把遗漏地细节补充完整。"));
            await Measure(baseline,"document_without_cache",document);await Measure(updated,"document_first_check",document);await Measure(updated,"document_small_edit",document.Replace("第10段","第十个段落"));
            LocalStore.AtomicWrite(Path.Combine(root,"tests/desktop-performance.json"),JsonSerializer.Serialize(new{platform=System.Runtime.InteropServices.RuntimeInformation.OSDescription,architecture=System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString(),logicalProcessors=Environment.ProcessorCount,config.Threads,preloadMs,measurements},LocalStore.JsonOptions));
        }
        return passed;
    }
}
