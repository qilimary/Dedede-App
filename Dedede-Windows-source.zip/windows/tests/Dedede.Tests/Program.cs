using Dedede.Core;
using System.Diagnostics;
using System.Text.Json;

string root=Path.GetFullPath(args.FirstOrDefault()??".");string assets=Path.Combine(root,"assets");int passed=0;
void Assert(bool condition,string label){if(!condition)throw new Exception("FAIL: "+label);passed++;}
var watch=Stopwatch.StartNew();
var tokenizer=new HcamTokenizer(Path.Combine(assets,"models/tokenizer.json"));
using(var fixtures=JsonDocument.Parse(File.ReadAllText(Path.Combine(root,"tests/tokenizer-fixtures.json"))))
foreach(var item in fixtures.RootElement.EnumerateArray())
{
    string text=item.GetProperty("text").GetString()!;var enc=tokenizer.Encode(text);
    Assert(enc.Ids.SequenceEqual(item.GetProperty("ids").EnumerateArray().Select(x=>x.GetInt64())),"token IDs: "+text+"\nActual "+string.Join(",",enc.Ids)+"\nExpect "+string.Join(",",item.GetProperty("ids").EnumerateArray().Select(x=>x.GetInt64())));
    Assert(enc.Starts.SequenceEqual(item.GetProperty("starts").EnumerateArray().Select(x=>x.GetInt32())),"UTF16 starts: "+text);
    Assert(enc.Ends.SequenceEqual(item.GetProperty("ends").EnumerateArray().Select(x=>x.GetInt32())),"UTF16 ends: "+text);
}
var rules=new RuleSet(Path.Combine(assets,"android-rules.json"));Assert(rules.Grammar.Count==235&&rules.Protection.Count==79,"all imported rules compile");
foreach(var source in new[]{"",new string('的',1201),new string('字',298)+"😀\r\n地。", "你好。。再见。。。\r\n下一行\t做作",string.Concat(Enumerable.Repeat("abc😀的地得\r\n",300))})
{
    var pieces=TextSegments.Split(source);Assert(string.Concat(pieces.Select(s=>s.Text))==source,"lossless segmentation");Assert(pieces.All(s=>!char.IsHighSurrogate(s.Text[^1])&&!char.IsLowSurrogate(s.Text[0])),"surrogate-safe split");
}
using var engine=new CorrectionEngine(assets);
var fast=new CheckSettings{Professional=false};
foreach(var pair in new Dictionary<string,string>{["这项工作大约持续了三天左右。"]="这项工作大约持续了三天。",["我们有3个电脑。"]="我们有三台电脑。",["他买了一条鸡。"]="他买了一只鸡。",["你好。。再见。。。"]="你好。再见。。。",["请给老人让坐。"]="请给老人让座。"})
{
    var r=await engine.CheckAsync(pair.Key,fast);Assert(r.Corrected==pair.Value,$"rule result: {pair.Key} -> {r.Corrected}");
}
foreach(var source in new[]{"不妨照原样保留。","请切换界面。","他准备做数学题。","他带了三条鸡腿。"})
{var r=await engine.CheckAsync(source,fast);Assert(r.Corrected==source,"dictionary boundary: "+source);}
var customResult=await engine.CheckAsync("这项工作大约持续了三天左右。",fast,new Dictionary<string,string>{{"大约持续了三天左右","大约持续了三天左右"}});Assert(customResult.Changes.Count==0,"user whitelist overrides grammar");
var customReplacement=await engine.CheckAsync("专署名。",fast,new Dictionary<string,string>{{"专署名","专属名称"}});Assert(customReplacement.Corrected=="专属名称。","custom replacement variable length");
string temp=Path.Combine(Path.GetTempPath(),"dedede-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);
try
{
    var r=new CheckResult{Original="甲乙丙😀<script>",Changes=[new(){Start=1,Original="乙",Replacement="修改后",Kind="自定义"}]};Assert(r.Corrected=="甲修改后丙😀<script>","length-changing render");r.Changes[0].Accepted=false;Assert(r.Corrected==r.Original,"reject preserves source");
    Assert(Reports.Html(r).Contains("&lt;script&gt;")&&!Reports.Html(r).Contains("<script>"),"HTML escaped");
    var local=new LocalStore(temp);local.Save("state.json",r);Assert(local.Load("state.json",()=>new CheckResult()).Original==r.Original,"atomic JSON persistence");
    string doc=Path.Combine(temp,"中文文档.docx");Documents.ExportDocx(doc,"第一行\n第二行 😀\n的地得做作");Assert(Documents.ReadText(doc).Replace("\r\n","\n").TrimEnd()=="第一行\n第二行 😀\n的地得做作","DOCX export/import text roundtrip");
    Assert(LocalStore.ParseCustomRules("植物\n错词 → 正词\nA\tB").Count==3,"rules import formats");
    var canceled=new CancellationToken(true);bool caught=false;try{await engine.CheckAsync("取消测试",fast,null,null,canceled);}catch(OperationCanceledException){caught=true;}Assert(caught,"pre-canceled request");
}
finally{Directory.Delete(temp,true);}
// Real model smoke + reversible decisions; these are behavior checks, not a benchmark score.
var professional=new CheckSettings();var example=await engine.CheckAsync("他认真得检查了这份报告，又把遗漏地细节补充完整。\n\n她高兴的跑进温室，看到植物长的很好，便小心地记录下叶片的变化。\n\n这项工作大约持续了三天左右。我们会在下周继续做实验，并根据实际结果作出调整。\n\n他做的作业已经交了。地理老师说，这张地图画得很清楚。",professional);
Assert(example.ModelCalls>0,"real ONNX invoked");Assert(example.Corrected.Contains("认真地检查"),"real model / rules can correct");
File.WriteAllText(Path.Combine(root,"tests/example-result.json"),JsonSerializer.Serialize(example,LocalStore.JsonOptions));
foreach(var c in example.Changes)c.Accepted=false;Assert(example.Corrected==example.Original,"reject all restores exact original");
var pure=new CheckSettings{Dictionary=false,Grammar=false,Protection=false};var noChange=await engine.CheckAsync("他做的作业。",pure);Assert(noChange.Corrected=="他做的作业。","real model dense target phrase");
var progressCancel=new CancellationTokenSource();var progress=new DirectProgress(p=>{if(p.Completed>=1)progressCancel.Cancel();});bool canceledLong=false;
try{await engine.CheckAsync(string.Concat(Enumerable.Repeat("他认真的检查了模型的输出。",80)),professional,null,progress,progressCancel.Token);}catch(OperationCanceledException){canceledLong=true;}Assert(canceledLong,"cancel long inference between chunks");
Console.WriteLine(JsonSerializer.Serialize(new{passed,elapsedSeconds=watch.Elapsed.TotalSeconds,modelCalls=example.ModelCalls,example=resultText(example),runtime=Environment.Version.ToString()},LocalStore.JsonOptions));
string resultText(CheckResult r)=>string.Join("; ",r.Changes.Select(c=>c.Label));
sealed class DirectProgress(Action<CheckProgress> action):IProgress<CheckProgress>{public void Report(CheckProgress value)=>action(value);}
