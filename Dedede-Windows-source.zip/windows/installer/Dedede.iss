#ifndef VCMinimumVersion
#define VCMinimumVersion "14.44.35211.0"
#endif
[Setup]
AppId=纠错Pro
AppName=纠错 Pro
AppVersion=1.2.1
AppPublisher=奇
DefaultDirName={localappdata}\Programs\Dedede
UsePreviousAppDir=no
DefaultGroupName=纠错 Pro
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.19041
WizardStyle=modern
SetupIconFile=..\assets\app.ico
UninstallDisplayIcon={app}\Dedede-Launcher.exe
OutputDir=..\dist
OutputBaseFilename=Dedede-Windows-Setup
Compression=lzma2
SolidCompression=yes
SetupLogging=yes
CloseApplications=yes
RestartApplications=no
[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
[Tasks]
Name: "desktopicon"; Description: "创建桌面快捷方式"; Flags: checkedonce
Name: "sendto"; Description: "添加到文件右键的发送到菜单"; Flags: unchecked
[Files]
Source: "..\dist\Dedede-Windows-x64\*"; DestDir: "{app}"; Excludes: "prerequisites\*"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\dist\Dedede-Windows-x64\prerequisites\vc_redist.x64.exe"; DestDir: "{app}\prerequisites"; Flags: ignoreversion
[Icons]
Name: "{userprograms}\纠错 Pro\纠错 Pro"; Filename: "{app}\Dedede-Launcher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\assets\app.ico"; IconIndex: 0
Name: "{userprograms}\纠错 Pro\纠错 Pro（兼容启动）"; Filename: "{app}\Dedede-Launcher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\assets\app.ico"; IconIndex: 0; Parameters: "--safe-render"
Name: "{userdesktop}\纠错 Pro"; Filename: "{app}\Dedede-Launcher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\assets\app.ico"; IconIndex: 0; Tasks: desktopicon
Name: "{sendto}\纠错 Pro"; Filename: "{app}\Dedede-Launcher.exe"; WorkingDir: "{app}"; IconFilename: "{app}\assets\app.ico"; IconIndex: 0; Tasks: sendto
[InstallDelete]
Type: files; Name: "{app}\启动纠错.cmd"
Type: files; Name: "{app}\兼容启动.cmd"
[Run]
Filename: "{app}\Dedede-Launcher.exe"; Description: "启动纠错 Pro"; Flags: nowait postinstall skipifsilent; Check: CanLaunch
[Code]
var RuntimeReady: Boolean;
function Part(var S: String): Integer;
var P: Integer; T: String;
begin
 P := Pos('.', S); if P = 0 then begin T := S; S := ''; end else begin T := Copy(S,1,P-1); Delete(S,1,P); end;
 Result := StrToIntDef(T,0);
end;
function AtLeast(A,B: String): Boolean;
var I,X,Y: Integer;
begin
 Result := True;
 for I := 1 to 4 do begin X := Part(A); Y := Part(B); if X <> Y then begin Result := X > Y; Exit; end; end;
end;
function NeedsRuntime: Boolean;
var V: String;
begin
 Result := not GetVersionNumbersString(ExpandConstant('{sys}\msvcp140.dll'),V);
 if not Result then Result := not AtLeast(V,'{#VCMinimumVersion}');
 Result := Result or not FileExists(ExpandConstant('{sys}\vcruntime140_1.dll')) or not FileExists(ExpandConstant('{sys}\msvcp140_1.dll'));
end;
function PrepareToInstall(var NeedsRestart: Boolean): String;
var Code: Integer;
begin
 Result := ''; RuntimeReady := not NeedsRuntime;
 if RuntimeReady then Exit;
 ExtractTemporaryFile('vc_redist.x64.exe');
 if not ShellExec('runas',ExpandConstant('{tmp}\vc_redist.x64.exe'),'/install /passive /norestart /log "'+ExpandConstant('{tmp}\Dedede-VC.log')+'"','',SW_SHOWNORMAL,ewWaitUntilTerminated,Code) then begin
  Result := '微软 VC++ 运行库未安装。请允许系统权限提示后重试。错误码：'+IntToStr(Code); Exit;
 end;
 if Code = 3010 then begin NeedsRestart := True; Exit; end;
 if (Code <> 0) and (Code <> 1638) then begin Result := '微软 VC++ 运行库安装失败，错误码：'+IntToStr(Code)+#13#10+'日志：'+ExpandConstant('{tmp}\Dedede-VC.log'); Exit; end;
 RuntimeReady := not NeedsRuntime;
 if not RuntimeReady then Result := '运行库仍不完整。请重启 Windows 后重新运行安装程序。';
end;
function CanLaunch: Boolean;
begin Result := RuntimeReady and not NeedsRuntime; end;
procedure CurStepChanged(CurStep: TSetupStep);
var Code: Integer; Folder, SourceLog: String;
begin
 if CurStep = ssPostInstall then begin
  Folder := ExpandConstant('{localappdata}\Dedede'); ForceDirectories(Folder);
  SourceLog := ExpandConstant('{log}');
  if SourceLog <> '' then FileCopy(SourceLog,Folder+'\install.log',False);
  if RuntimeReady then begin
   if not Exec(ExpandConstant('{app}\Dedede-Launcher.exe'),'--check-runtime','',SW_HIDE,ewWaitUntilTerminated,Code) then RuntimeReady := False else RuntimeReady := Code = 0;
   if not RuntimeReady then MsgBox('程序已安装，但运行库检测未通过。请重启后再启动；记录位于 '+Folder,mbInformation,MB_OK);
  end;
 end;
end;
