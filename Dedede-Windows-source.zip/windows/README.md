# 纠错 Pro · Windows 1.0

Windows x64 桌面客户端，参考 Dedede-App 当前安卓 4.1-PTE 构建（提交 `10baa0cb64edc2dcb8add1ac46b22ab234398ff4`）。作者与模型训练：奇；公众号：Li的信箱。

## 直接使用

下载 **Dedede-Windows-x64.zip**，完整解压后双击 `启动纠错.cmd`。它只在缺少微软 VC++ x64 运行库时调用包内安装程序，然后打开 `Dedede.exe`。已安装运行库的电脑也可直接打开 `Dedede.exe`。不要把 EXE 单独移出文件夹。

这是免安装便携发布包，内含 .NET 10、ONNX Runtime、约 117 MiB 的 HCAM V2 模型、分词器及中英文 OCR 数据。推理无需联网、Python、CUDA 或独立显卡。模型推理和正文处理均在本机完成。

**验证状态必须注意：** 本次在 Linux 环境完成 WPF 交叉编译、Windows x64 自包含发布、790 项核心断言及真实 ONNX 推理。没有在 Windows 10/11 实机启动此包，Windows OCR 原生 DLL、托盘、热键和截图入口尚待实机验证。附带的 GitHub Windows 工作流会执行模型/OCR 冒烟测试并渲染真实 WPF 界面；没有运行过的测试不记为通过。HTML 界面预览是按实现制作的布局预览，不是实机截图。

## 功能

- 专业五字纠错、极速词库/规则模式；默认温度 1.0，的/地阈值 0.70，得/做/作阈值 0.75。
- 235 条安卓语法规则、79 条局部保护、46 个保护词、13 组量词规则和完整安卓错词库。
- 可调整的双栏、全文并排对比、行内差异、点击定位、逐条/全部采纳或忽略、手动修订。
- 文字/文件拖入、查找替换、撤销、标点整理、原文变化时取消推理并提示结果过期。
- TXT、MD、CSV、LOG、SRT、DOCX、PPTX、文字型 PDF 导入；图片/剪贴板/截图本地 OCR。
- 批量处理、单文件错误隔离、进度与取消；新文件输出，不覆盖原始文档。
- TXT/MD/DOCX 正文、HTML 完整对比报告、CSV 修改清单导出。
- 白名单和自定义替换，支持 Android JSON 映射导入导出；历史最多 50 条且原文总量最多 200 万字。
- 自动草稿、深浅主题、四种主题色、字号、同步滚动、托盘、迷你置顶窗口、全局快捷键。
- 模型 SHA-256 检查、按需加载、10 分钟空闲释放；CPU 线程可调；单实例唤醒。

文字导出不保留 Office/PDF 原排版；扫描 PDF 需另存图片后 OCR；OCR 主要面向清晰印刷文字，不能保证手写/复杂版式准确。预设系统规则沿用安卓，因此神经网络/规则都仍可能误改，重要文本宜逐条复核。

## 文件放置

将源码包解压到 **Dedede-App 仓库根目录**，新增两处：

```text
Dedede-App/
  .github/workflows/windows.yml
  windows/
    build.ps1
    global.json
    src/Dedede.Core/
    src/Dedede.Windows/
    assets/
    tests/
    scripts/
    docs/
```

安卓的 `dedede-build.sh`、现有工作流与文件不需要替换。没有代你提交、推送或修改远程仓库。

`windows/assets/models/HCAM_V2_5CHAR_INT8_PT.onnx` 超过 GitHub 普通文件限制，因此源码包不重复包含模型，且 `.gitignore` 排除它。**免安装运行包包含完整模型**。构建工作流会从你的第三个 Drive 目录下载指定文件并验证 SHA-256；依赖这个分享链接持续可访问。也可把免安装包中的模型复制到源码相同位置，供本地离线构建。

## GitHub 构建

上传以上新文件后，打开 Actions → **Windows 纠错 Pro** → Run workflow。完成后下载 `Dedede-Windows-x64` 产物；`Windows-native-previews` 包含 Windows 上实际渲染的各页面截图。工作流只读取仓库，不发布 Release、不改代码、不触碰安卓流程。

## 本地构建

安装 `.NET 10 SDK 10.0.401`（global.json 允许同功能带补丁升级），在 Windows PowerShell 中运行：

```powershell
cd windows
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

首次缺少模型时需 Python 3.11+ 下载工具；终端用户不需要 Python。依赖通过 NuGet 锁文件固定。成功后得到 `windows/dist/Dedede-Windows-x64.zip`。构建默认跑核心测试及 Windows 模型/OCR 测试；不要把 `-SkipTests` 构建误称为经过 Windows 验证。

## 数据与维护

默认保存位置：`%LOCALAPPDATA%\Dedede`。设置、词库、草稿和历史为普通本机文件，可在设置页关闭记录或打开目录。它们不随免安装目录搬迁，也不加密。关闭保留历史只停止新增；已有历史可单独清空。

目标平台为 Windows 10 22H2 / Windows 11 的 Intel/AMD x64 电脑。ARM64 没有提供原生版本。Win10 普通版本的厂商支持状态与“软件可能运行”是两回事；未声称微软仍为全部 Win10 版本提供官方支持。

采用 .NET 10 LTS 和固定依赖以减少不必要变动；LTS 仍需要补丁更新，未来系统也需验证，不能承诺永远零维护。模型、UI 和规则分层，将来更换模型或推理引擎不会要求重写全部界面。

详见 `docs/迁移说明.md`、`docs/验证记录.md` 和包内 `使用说明.html`。
