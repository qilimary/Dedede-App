# 纠错 Pro · 桌面版 1.2.1

Windows 与 macOS 共用纠错核心。基于仓库提交 b2c8aa9aba028a573206eccd7e54b7d037f51609 的桌面源码；Android 文件不改动。

## 替换与构建

只替换两份文件：

1. 仓库根目录 `Dedede-Windows-source.zip`，保持压缩状态。
2. `.github/workflows/windows.yml`。

如果下载名称带有 `(2)`、`(3)` 等后缀，上传前去掉。上传完成后运行 Actions → Desktop apps (Windows + Mac) → Run workflow。ZIP 内 `windows/workflows/windows.yml` 是同一工作流的备份。本次没有远程推送或触发构建。

## 安装程序与 ZIP 分享版

构建全部成功后，Releases 提供：

| 系统 | 直接安装版 | ZIP 分享版 |
| --- | --- | --- |
| Windows x64 | Dedede-Windows-Setup.exe | Dedede-Windows-Setup.zip |
| Mac Apple Silicon | Dedede-Mac-AppleSilicon.dmg | Dedede-Mac-AppleSilicon.zip |
| Mac Intel | Dedede-Mac-Intel.dmg | Dedede-Mac-Intel.zip |

分享版包含同一个完整安装程序和 README.txt，先解压，再运行安装程序。打包时检查 ZIP 完整性及包内安装文件的 SHA-256，保证与直接下载版一致。源码 ZIP 用于构建，不是安装包。

## 1.2.1 修复

- 修正 Windows 安装脚本不存在的 GetLogFileName 调用，使用 Inno Setup 的日志常量；同时识别 Inno Setup 6 / 7 的常见安装位置。
- 修正 Mac 快捷键组件的 ByteCount 和 RunApplicationEventLoop 编译错误，使用 UInt32 和 AppKit 事件循环。后台组件不显示 Dock 图标。原生组件提前到模型下载和 .NET 发布前编译，及早暴露 SDK 问题。
- 检查后默认完成纠正，移除“已采纳”状态、筛选与计数以及“全部采纳”按钮。保留置信度、序号定位、还原为原字、全部还原及撤销/重做。已还原项目可用“恢复纠正”恢复，不必重新检查。
- 无置信度且未还原的项目不再显示空白状态行；报告与使用说明同步简化。
- Windows 和两种 Mac 架构均增加 ZIP 分享版。

## 已保留的 1.2 功能

两种结果视图（修订标注 / 全文对比）、删除线原字与修订字、逐条手动修改、完整工作区恢复、直接撤销/重做与首行缩进、独立界面/正文字号、可自定义纠错快捷键、批量文档和本地 OCR、我的词库、可选后台工具。四项纠错功能固定启用；温度和修改阈值可调。

模型在窗口显示后和输入停顿时后台预热，复用会话并缓存精确输入；修改参数和保护词仍重新计算决定。当前使用 INT8 PT ONNX 的 CPU 推理，无需 CUDA，有独显不会自动加速。首篇新文本仍受硬件影响，不能保证比手机更快。

Windows 快捷方式明确设置 GUI 启动器、图标和工作目录，普通启动不显示短暂提示窗；异常或长时间未就绪才显示诊断。安装新版后使用新版生成的快捷方式。

## 验证与边界

已完成两端托管代码编译、811 项真实模型核心检查、28 项 Mac 控件流程检查、ZIP 字节一致性与构建脚本检查。此环境为 Linux；本次未完成 Inno 编译、macOS Swift 编译或原生安装，需要上传后在相应 GitHub runner 继续验证。详见 `docs/桌面版1.2.1验证.md`。1.1 / 1.2 验证文件保留作历史记录。

Windows 面向 Win 10 22H2 / Win 11 x64，自带 .NET；缺少 VC++ 运行库时安装器补装。Mac 面向 macOS 14+，自带 .NET，OCR 使用系统 Vision。Mac 默认本机签名，未做 Apple Developer ID 签名与公证。未来系统仍需验证。

## 开发入口

Windows：.NET 10 SDK 和 Inno Setup 6.3+，执行 `pwsh -File windows/build.ps1 -Installer`。Mac：.NET 10 SDK 与 Xcode 命令行工具，执行 `bash macos/build.sh`。模型由构建脚本下载并校验，运行时离线。

改源码后运行 `python windows/scripts/pack_source.py` 重新生成上传 ZIP；修改工作流时同步 `windows/workflows/windows.yml`。
