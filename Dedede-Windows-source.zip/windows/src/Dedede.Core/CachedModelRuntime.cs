using System.Runtime.InteropServices;
using System.Security.Cryptography;
namespace Dedede.Core;
// Serialized by CorrectionEngine. Cache only exact inputs, never final correction decisions.
internal sealed class CachedModelRuntime(IModelRuntime inner):IModelRuntime
{
    private readonly Dictionary<string,float[]> cache=[];
    private readonly Queue<string> order=[];
    private int bytes;
    public int Hits {get;private set;}
    public float[] Forward(long[] ids,bool[] mask,CancellationToken ct)
    {
        ct.ThrowIfCancellationRequested();using var h=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);h.AppendData(MemoryMarshal.AsBytes(ids.AsSpan()));h.AppendData(MemoryMarshal.AsBytes(mask.AsSpan()));string key=Convert.ToHexString(h.GetHashAndReset());
        if(cache.TryGetValue(key,out var saved)){Hits++;return (float[])saved.Clone();}
        var value=inner.Forward(ids,mask,ct);ct.ThrowIfCancellationRequested();int size=value.Length*sizeof(float);
        while(order.Count>0&&(order.Count>=128||bytes+size>4*1024*1024)){var k=order.Dequeue();bytes-=cache[k].Length*sizeof(float);cache.Remove(k);}
        if(size<=4*1024*1024){cache.Add(key,(float[])value.Clone());order.Enqueue(key);bytes+=size;}return value;
    }
    public void Dispose(){cache.Clear();order.Clear();bytes=0;inner.Dispose();}
}
