using System.Net;
using System.Text;

namespace Dedede.Core;
public static class Reports
{
    public static string Html(CheckResult result)
    {
        static string E(string x)=>WebUtility.HtmlEncode(x);
        var diff=new StringBuilder();int at=0;
        foreach(var c in result.Changes.OrderBy(c=>c.Start))
        {
            diff.Append(E(result.Original[at..c.Start]));
            if(c.Accepted){diff.Append("<del>").Append(E(c.Original)).Append("</del><ins>").Append(E(c.Replacement)).Append("</ins>");}else diff.Append(E(c.Original));at=c.End;
        }
        diff.Append(E(result.Original[at..]));
        var rows=string.Concat(result.Changes.Select(c=>$"<tr><td>{c.Start+1}</td><td>{E(c.Original)}</td><td>{E(c.Replacement)}</td><td>{E(c.Kind)}</td><td>{(c.Confidence.HasValue?c.Confidence.Value.ToString("P1"):"—")}</td><td>{(c.Accepted?"已采纳":"已忽略")}</td></tr>"));
        return "<!doctype html><html lang=\"zh-CN\"><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>纠错 Pro · 对比报告</title><style>body{font:16px/1.9 system-ui,sans-serif;color:#263449;background:#f3f6fa;margin:0;padding:4vw}main{max-width:1200px;margin:auto}h1{font-size:28px}section{background:white;padding:24px;border-radius:16px;margin:20px 0}.cols{display:grid;grid-template-columns:1fr 1fr;gap:24px}.text{white-space:pre-wrap;overflow-wrap:anywhere}del{background:#fde2e2;color:#a32531}ins{background:#dcf5e8;color:#166a42;text-decoration:none}table{width:100%;border-collapse:collapse}td,th{padding:8px;border-bottom:1px solid #e2e8f0;text-align:left}@media(max-width:700px){.cols{grid-template-columns:1fr}}</style><main>"+
            $"<h1>纠错 Pro · 对比报告</h1><p>{result.Created:yyyy-MM-dd HH:mm} · {E(result.Mode)} · {result.Changes.Count} 条建议 · 已采纳 {result.Changes.Count(c=>c.Accepted)} 条</p><section class=\"cols\"><div><h2>原文</h2><div class=\"text\">{E(result.Original)}</div></div><div><h2>修订后</h2><div class=\"text\">{E(result.Corrected)}</div></div></section><section><h2>行内对比</h2><div class=\"text\">{diff}</div></section><section><h2>修改清单</h2><table><tr><th>位置</th><th>原文</th><th>修订</th><th>来源</th><th>模型置信度</th><th>状态</th></tr>{rows}</table></section><p>本地 HCAM V2 · 作者：奇 · 公众号：Li的信箱</p></main></html>";
    }
    public static string Csv(CheckResult result)
    {
        static string Q(string value){if(value.Length>0&&"=+-@\t\r".Contains(value[0]))value="'"+value;return "\""+value.Replace("\"","\"\"")+"\"";}
        return "位置,原文,修订,来源,置信度,状态\r\n"+string.Join("\r\n",result.Changes.Select(c=>string.Join(',',new[]{(c.Start+1).ToString(),c.Original,c.Replacement,c.Kind,c.Confidence?.ToString("F4",System.Globalization.CultureInfo.InvariantCulture)??"",c.Accepted?"已采纳":"已忽略"}.Select(Q))));
    }
}
