using System.Text;
using System.Text.Json.Serialization;

namespace Dedede.Core;

public sealed class CheckSettings
{
    public bool Professional { get; set; } = true;
    public float Temperature { get; set; } = 1;
    public float[] Thresholds { get; set; } = [.70f, .70f, .75f, .75f, .75f];
    public bool Dictionary { get; set; } = true;
    public bool Grammar { get; set; } = true;
    public bool Protection { get; set; } = true;
    public bool DenseReview { get; set; } = true;
    public int Threads { get; set; } = Math.Clamp(Environment.ProcessorCount / 2, 1, 4);
    public void Validate()
    {
        if (!float.IsFinite(Temperature) || Temperature < .5 || Temperature > 2) throw new ArgumentException("温度必须在 0.5～2.0 之间。");
        if (Thresholds is not { Length: 5 } || Thresholds.Any(x => !float.IsFinite(x) || x < 0 || x > 1)) throw new ArgumentException("五个修改阈值必须在 0～1 之间。");
        if (Threads < 1 || Threads > 32) throw new ArgumentException("CPU 线程数必须在 1～32 之间。");
    }
    public CheckSettings Snapshot() => new() { Professional=Professional, Temperature=Temperature, Thresholds=[..Thresholds], Dictionary=Dictionary, Grammar=Grammar, Protection=Protection, DenseReview=DenseReview, Threads=Threads };
}

public sealed class AppSettings
{
    public CheckSettings Check { get; set; } = new();
    public string Theme { get; set; } = "system";
    public string Accent { get; set; } = "blue";
    public double FontSize { get; set; } = 18;
    public double UiFontSize { get; set; } = 14;
    public string CheckShortcut { get; set; } = "Primary+Enter";
    public bool KeepHistory { get; set; } = true;
    public bool SaveDraft { get; set; } = true;
    public bool CloseToTray { get; set; }
    public bool Hotkeys { get; set; }
    public bool SyncScroll { get; set; } = true;
    public Dictionary<string,string> CustomRules { get; set; } = new(StringComparer.Ordinal);
}

public sealed class Change
{
    public int Start { get; set; }
    public string Original { get; set; } = "";
    public string Replacement { get; set; } = "";
    public string Kind { get; set; } = "";
    public string Explanation { get; set; } = "";
    public float? Confidence { get; set; }
    public bool Accepted { get; set; } = true;
    public bool ManuallyEdited { get; set; }
    [JsonIgnore] public int Number { get; set; }
    [JsonIgnore] public string NumberLabel => $"[{Number}]";
    [JsonIgnore] public int End => Start + Original.Length;
    [JsonIgnore] public string Label => $"{Original}  →  {(Replacement.Length == 0 ? "（删除）" : Replacement)}";
    [JsonIgnore] public string Detail => (ManuallyEdited?"手动修订 · ":"")+(Confidence.HasValue?$"{(ManuallyEdited?"原建议":"")}置信度 {Confidence.Value*100:F1}% · ":"")+(Accepted?"已采纳":"已还原");
}

public sealed class CheckResult
{
    public string Original { get; set; } = "";
    public List<Change> Changes { get; set; } = [];
    public long ElapsedMs { get; set; }
    public int ModelCalls { get; set; }
    public int ReviewCalls { get; set; }
    public int CacheHits { get; set; }
    public string Mode { get; set; } = "专业";
    public DateTimeOffset Created { get; set; } = DateTimeOffset.Now;
    [JsonIgnore] public string Corrected => Render(Original, Changes);
    public static string Render(string original, IEnumerable<Change> changes)
    {
        var output=new StringBuilder(original.Length); int at=0;
        foreach(var c in changes.OrderBy(c=>c.Start))
        {
            if(c.Start < at || c.End > original.Length || original.AsSpan(c.Start,c.Original.Length).SequenceEqual(c.Original.AsSpan()) == false) throw new InvalidDataException("纠错位置与原文不一致。");
            output.Append(original.AsSpan(at,c.Start-at)); output.Append(c.Accepted ? c.Replacement : c.Original); at=c.End;
        }
        output.Append(original.AsSpan(at)); return output.ToString();
    }
    public int OutputOffset(Change change) => change.Start + Changes.Where(c=>c.Start<change.Start && c.Accepted).Sum(c=>c.Replacement.Length-c.Original.Length);
}
public record CheckProgress(int Completed, int Total, int Changes, string Stage);
public record TextSegment(int Start, string Text);

public static class TextSegments
{
    // Preserve every UTF-16 unit, including CRLF, emoji and whitespace. Models never receive a half surrogate.
    public static List<TextSegment> Split(string text, int maxLength=300)
    {
        if(maxLength < 8) throw new ArgumentOutOfRangeException(nameof(maxLength));
        var result=new List<TextSegment>(); int start=0;
        while(start<text.Length)
        {
            int limit=Math.Min(start+maxLength,text.Length), end=limit;
            for(int i=start;i<limit;i++) if("。！？!?\n".Contains(text[i]))
            {
                end=i+1;
                // Keep consecutive punctuation together so duplicate/conflicting punctuation rules can see it.
                while(end<limit && "。！？!?，、；：”’\"」』".Contains(text[end]))end++;
                break;
            }
            if(end==limit && end<text.Length)
            {
                for(int i=end-1;i>=Math.Max(start+1,end-60);i--) if("，,；;、".Contains(text[i])) {end=i+1;break;}
            }
            if(end<text.Length && char.IsLowSurrogate(text[end]) && end>start && char.IsHighSurrogate(text[end-1])) end--;
            if(end<text.Length && text[end-1]=='\r' && text[end]=='\n') end--;
            result.Add(new(start,text[start..end]));start=end;
        }
        return result;
    }
}
