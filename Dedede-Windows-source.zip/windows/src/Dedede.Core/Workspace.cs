using System.Text.Json;
using System.Text.RegularExpressions;
namespace Dedede.Core;
public sealed class WorkspaceState
{
    public string Source {get;set;}="";
    public CheckResult? Result {get;set;}
    public int View {get;set;}
    public void Validate(){if(Source is null||Source.Length>300_000)throw new InvalidDataException("草稿内容无效。");if(Result!=null){if(Result.Original is null||Result.Original.Length>300_000||Result.Changes is null)throw new InvalidDataException("修订记录无效。");_ = Result.Corrected;}View=Math.Clamp(View,0,1);}
}
public sealed class RevisionUndo
{
    private readonly List<string> undo=[],redo=[];
    public bool CanUndo=>undo.Count>0;
    public bool CanRedo=>redo.Count>0;
    public void Clear(){undo.Clear();redo.Clear();}
    public void Record(CheckResult r){undo.Add(JsonSerializer.Serialize(r.Changes));if(undo.Count>50)undo.RemoveAt(0);redo.Clear();}
    public bool Apply(CheckResult r,bool forward){var from=forward?redo:undo;var to=forward?undo:redo;if(from.Count==0)return false;to.Add(JsonSerializer.Serialize(r.Changes));r.Changes=JsonSerializer.Deserialize<List<Change>>(from[^1])!;from.RemoveAt(from.Count-1);return true;}
}
public static class EditorActions
{
    public static string IndentParagraphs(string text)=>Regex.Replace(text,@"(?m)^[\t \u3000]*(?=[^\r\n\t \u3000])","　　");
    public static string CleanPunctuation(string text)=>Regex.Replace(text,@"(?<=[\u4e00-\u9fff])\.{2,6}(?=[\u4e00-\u9fff])","……").Replace("\u200b","").Replace("\ufeff","");
}
public static class CheckShortcut
{
    public const string Default="Primary+Enter";
    public static string Format(string value,bool mac)=>value.Replace("Primary",mac?"⌘":"Ctrl").Replace("Control","Ctrl").Replace("Alt",mac?"⌥":"Alt").Replace("Shift",mac?"⇧":"Shift").Replace("+"," + ");
    public static bool Valid(string value)
    {
        if(string.IsNullOrWhiteSpace(value))return false;var p=value.Split('+');if(p.Distinct().Count()!=p.Length)return false;string key=p[^1];
        if(!Regex.IsMatch(key,@"^(Enter|Space|[A-Z]|[0-9]|F([1-9]|1[0-2]))$"))return false;
        if(p[..^1].Any(x=>x is not ("Primary" or "Control" or "Alt" or "Shift")))return false;
        if(key=="F11"||(p.Length==1&&!key.StartsWith('F')))return false;
        if(p.Length==2&&(p[0] is "Primary" or "Control")&&"ACFHMNOPQSVWXYZ".Contains(key))return false;
        if(value is "Primary+Shift+C" or "Control+Shift+C" or "Alt+F4" or "Primary+Space" or "Primary+Alt+D" or "Primary+Alt+O" or "Control+Alt+D" or "Control+Alt+O")return false;
        return true;
    }
}
