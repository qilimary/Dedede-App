using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;
using System.Security.Cryptography;

namespace Dedede.Core;

public interface IModelRuntime : IDisposable
{
    float[] Forward(long[] ids, bool[] mask, CancellationToken cancellationToken);
}

public sealed class ModelRuntime : IModelRuntime
{
    public const string ModelHash="15f0af5c03857ac2b049ac9f02cfe1dde2fba11ea639e191ca6453cb9a6e75cc";
    public const string TokenizerHash="bed4387895500314ffba9608340c56069ca6df8635029535b9becdef8ce7ddf0";
    private readonly InferenceSession session;
    public ModelRuntime(string path,int threads)
    {
        Verify(path,ModelHash);
        using var options=new SessionOptions { IntraOpNumThreads=threads, InterOpNumThreads=1, GraphOptimizationLevel=GraphOptimizationLevel.ORT_ENABLE_ALL, ExecutionMode=ExecutionMode.ORT_SEQUENTIAL };
        options.AddSessionConfigEntry("session.intra_op.allow_spinning","0");
        session=new InferenceSession(path,options);
        if(!session.InputMetadata.ContainsKey("input_ids")||!session.InputMetadata.ContainsKey("mask_positions")||!session.OutputMetadata.ContainsKey("logits"))throw new InvalidDataException("模型接口不匹配。");
    }
    public static void Verify(string path,string hash)
    {
        using var stream=File.OpenRead(path);
        if(!Convert.ToHexString(SHA256.HashData(stream)).Equals(hash,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException($"资源校验失败：{Path.GetFileName(path)}。请重新解压完整安装包。");
    }
    public float[] Forward(long[] ids,bool[] mask,CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if(ids.Length==0||ids.Length!=mask.Length||ids.Length>1248)throw new ArgumentException("模型输入长度错误。");
        var inputs=new[]{NamedOnnxValue.CreateFromTensor("input_ids",new DenseTensor<long>(ids,[1,ids.Length])),NamedOnnxValue.CreateFromTensor("mask_positions",new DenseTensor<bool>(mask,[1,ids.Length]))};
        using var run=new RunOptions();using var registration=cancellationToken.Register(()=>run.Terminate=true);
        try
        {
            using var result=session.Run(inputs,["logits"],run);var output=result.First().AsTensor<float>();
            if(output.Rank!=3 || output.Dimensions[0]!=1 || output.Dimensions[1]!=ids.Length || output.Dimensions[2]!=5)throw new InvalidDataException("模型输出形状错误。");
            var values=output.ToArray();if(values.Any(x=>!float.IsFinite(x)))throw new InvalidDataException("模型输出不是有限数字。");return values;
        }
        catch(OnnxRuntimeException) when(cancellationToken.IsCancellationRequested){throw new OperationCanceledException(cancellationToken);}
    }
    public void Dispose()=>session.Dispose();
}

public sealed record Prediction(int Position,int Label,float Confidence);
public sealed class FiveCharInference
{
    public const string Labels="的地得做作";
    public static bool IsTarget(char c)=>Labels.Contains(c);
    public static (List<Prediction> Predictions,int Calls,int Reviews) Predict(string text,bool[] ignored,HcamTokenizer tokenizer,IModelRuntime model,CheckSettings settings,CancellationToken ct)
    {
        var enc=tokenizer.Encode(text);int n=enc.Ids.Length;var mask=new bool[n];bool active=false;
        for(int i=0;i<n;i++){int p=enc.Starts[i];mask[i]=enc.Ends[i]==p+1&&IsTarget(text[p]);active|=mask[i]&&!ignored[p];}
        if(!active)return([],0,0);
        var first=model.Forward(enc.Ids,mask,ct);int calls=1,reviews=0;var predictions=new List<Prediction>();
        for(int i=0;i<n;i++)
        {
            ct.ThrowIfCancellationRequested();int p=enc.Starts[i];if(!mask[i]||ignored[p])continue;
            int group=Labels.IndexOf(text[p])<3?0:3,count=group==0?3:2;var raw=Softmax(first,i*5+group,count,1);var scores=first;
            int left=p,right=p;while(left>0&&IsTarget(text[left-1]))left--;while(right+1<text.Length&&IsTarget(text[right+1]))right++;
            // Match Android 4.1: raw (temperature=1) confidence decides review; do not cross groups.
            if(settings.DenseReview&&right-left+1>=2&&raw.Max()<.78f){var single=new bool[n];single[i]=true;scores=model.Forward(enc.Ids,single,ct);calls++;reviews++;}
            var prob=Softmax(scores,i*5+group,count,settings.Temperature);int best=Array.IndexOf(prob,prob.Max());predictions.Add(new(p,group+best,prob[best]));
        }
        return(predictions,calls,reviews);
    }
    public static float[] Softmax(float[] values,int offset,int count,float temperature)
    {
        double max=double.NegativeInfinity;for(int i=0;i<count;i++)max=Math.Max(max,values[offset+i]/(double)temperature);
        var p=new float[count];double sum=0;for(int i=0;i<count;i++){p[i]=(float)Math.Exp(values[offset+i]/temperature-max);sum+=p[i];}for(int i=0;i<count;i++)p[i]/=(float)sum;return p;
    }
}
