using System.Text.Json;
using System.Text.RegularExpressions;

namespace Dedede.Core;

public sealed record GrammarRule(Regex Pattern,string?[][] Options,bool ProfessionalOnly);
public sealed class RuleSet
{
    public List<GrammarRule> Grammar { get; }=[];
    public List<Regex> Protection { get; }=[];
    public string[] IgnoreWords { get; }
    public Dictionary<char,(string Primary,string Allowed)> Quantifiers { get; }=[];
    public RuleSet(string path)
    {
        using var doc=JsonDocument.Parse(File.ReadAllText(path));var root=doc.RootElement;
        foreach(var r in root.GetProperty("rules").EnumerateArray())
        {
            var options=r.GetProperty("options").EnumerateArray().Select(a=>a.EnumerateArray().Select(v=>v.ValueKind==JsonValueKind.Null?null:v.GetString()).ToArray()).ToArray();
            Grammar.Add(new(CreateRegex(r.GetProperty("pattern").GetString()!),options,r.GetProperty("professionalOnly").GetBoolean()));
        }
        foreach(var r in root.GetProperty("protectedPatterns").EnumerateArray())Protection.Add(CreateRegex(r.GetString()!));
        IgnoreWords=root.GetProperty("ignoreWords").EnumerateArray().Select(x=>x.GetString()!).ToArray();
        foreach(var q in root.GetProperty("quantifiers").EnumerateObject())Quantifiers.Add(q.Name[0],(q.Value[0].GetString()!,q.Value[1].GetString()!));
    }
    // Java and .NET both support the imported constructs. Timeout bounds pathological input.
    private static Regex CreateRegex(string pattern)=>new(pattern,RegexOptions.CultureInvariant,TimeSpan.FromSeconds(2));
    public void MarkProtected(string text,bool[] ignored)
    {
        foreach(var word in IgnoreWords)
        {
            for(int at=text.IndexOf(word,StringComparison.Ordinal);at>=0;at=text.IndexOf(word,at+1,StringComparison.Ordinal)) Array.Fill(ignored,true,at,word.Length);
        }
        foreach(var regex in Protection)foreach(Match m in regex.Matches(text))
        {
            if(m.Groups.Count>1&&m.Groups[1].Success&&m.Groups[1].Length>0)ignored[m.Groups[1].Index]=true;
        }
    }
}

public sealed record WordRule(string Source,string Replacement,string[] Exclusions,bool Custom);
public sealed class WordIndex
{
    private sealed class Node { public Dictionary<char,Node> Children { get; }=[]; public WordRule? Rule; }
    private readonly Node root=new();
    private int maxLength;
    public int Count {get;private set;}
    public WordIndex(IEnumerable<WordRule> words)
    {
        foreach(var w in words)
        {
            if(w.Source.Length==0)continue;var node=root;
            foreach(char c in w.Source){if(!node.Children.TryGetValue(c,out var next))node.Children[c]=next=new();node=next;}
            if(node.Rule==null)Count++;node.Rule=w;maxLength=Math.Max(maxLength,w.Source.Length);
        }
    }
    public static WordIndex Load(string path)
    {
        var all=new Dictionary<string,WordRule>(StringComparer.Ordinal);
        foreach(var raw in File.ReadLines(path))
        {
            string line=raw.Trim().TrimStart('\ufeff');if(line.Length==0)continue;
            var f=Regex.Split(line,@"\s+",RegexOptions.CultureInvariant,TimeSpan.FromSeconds(1));if(f.Length<2||f[0]==f[1])continue;
            var except=new List<string>();if(f.Length>2&&f[2].StartsWith("n=")){except.Add(f[2][2..]);except.AddRange(f.Skip(3));}
            if(f[0]=="妨照"&&f[1]=="仿照")except.Add("不妨照");
            if(f[0]=="换界"&&f[1]=="换届")except.Add("换界面");
            if(f[0]=="做数"&&f[1]=="作数")except.AddRange(["做数学","做数据","做数值","做数理","做数独","做数字","做数量","做数组"]);
            all[f[0]]=new(f[0],f[1],except.Where(x=>x.Length>0).Distinct().ToArray(),false);
        }
        foreach(string word in new[]{"舒的","怎的","能的","您的"})all[word]=new(word,word,[],false);
        return new(all.Values);
    }
    private static bool Excluded(string text,int start,WordRule rule)
    {
        int end=start+rule.Source.Length;
        foreach(string word in rule.Exclusions)
        {
            int at=text.IndexOf(word,Math.Max(0,end-word.Length),StringComparison.Ordinal);
            if(at>=0&&at<=start&&at+word.Length>=end)return true;
        }
        return false;
    }
    private static bool FalsePositive(string text,int start,string source)
    {
        if(source[0] is '做' or '作')
        {
            if(start>0&&"创去要在该想会能可来把给多没不曾刚才将正就爱肯敢配帮替让叫使令".Contains(text[start-1]))return true;
            if(start+source.Length<text.Length&&"扇筝联山发牙眼肢手脚衣裤帽鞋饭菜汤了".Contains(text[start+source.Length]))return true;
        }
        return false;
    }
    public WordRule? Find(string text,int start)
    {
        var node=root;var candidates=new List<WordRule>();
        for(int i=start;i<text.Length&&node.Children.TryGetValue(text[i],out node!);i++) if(node.Rule!=null)candidates.Add(node.Rule);
        for(int i=candidates.Count-1;i>=0;i--)
        {
            var rule=candidates[i];if(!rule.Custom&&FalsePositive(text,start,rule.Source))continue;
            if(Excluded(text,start,rule))return rule with { Replacement=rule.Source };
            if(!rule.Custom&&rule.Source!=rule.Replacement&&Conflicts(text,start,rule))continue;
            return rule;
        }
        return null;
    }
    private bool Conflicts(string text,int start,WordRule rule)
    {
        string simulated=text[..start]+rule.Replacement+text[(start+rule.Source.Length)..];int end=start+rule.Replacement.Length;
        for(int at=Math.Max(0,start-maxLength+1);at<end;at++)
        {
            var node=root;
            for(int p=at;p<simulated.Length&&node.Children.TryGetValue(simulated[p],out node!);p++)
            {
                var w=node.Rule;if(w!=null&&((at<start&&p+1>start)||p+1>end)&&w.Source!=w.Replacement&&!Excluded(simulated,at,w))return true;
            }
        }
        return false;
    }
}
