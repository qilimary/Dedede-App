using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace Dedede.Core;

public sealed class CorrectionEngine : IDisposable
{
    private readonly string assets;
    private readonly SemaphoreSlim gate=new(1,1);
    private RuleSet? rules;
    private WordIndex? dictionary;
    private HcamTokenizer? tokenizer;
    private IModelRuntime? model;
    private int threads;
    private DateTime lastUse=DateTime.MinValue;
    private readonly Func<int,IModelRuntime>? factory;
    public CorrectionEngine(string assets,Func<int,IModelRuntime>? modelFactory=null){this.assets=assets;factory=modelFactory;}
    public bool IsModelLoaded => model!=null;
    private void LoadModel(int requestedThreads)
    {
        if(model!=null&&threads==requestedThreads)return;
        model?.Dispose();model=null;
        string tokenizerPath=Path.Combine(assets,"models","tokenizer.json");ModelRuntime.Verify(tokenizerPath,ModelRuntime.TokenizerHash);
        tokenizer ??= new HcamTokenizer(tokenizerPath);
        model=factory?.Invoke(requestedThreads)??new ModelRuntime(Path.Combine(assets,"models","HCAM_V2_5CHAR_INT8_PT.onnx"),requestedThreads);threads=requestedThreads;
    }
    public async Task<CheckResult> CheckAsync(string text,CheckSettings settings,IReadOnlyDictionary<string,string>? custom=null,IProgress<CheckProgress>? progress=null,CancellationToken ct=default)
    {
        settings=settings.Snapshot();settings.Validate();var customSnapshot=custom?.ToDictionary(x=>x.Key,x=>x.Value,StringComparer.Ordinal)??[];
        await gate.WaitAsync(ct).ConfigureAwait(false);
        try { return await Task.Run(()=>Check(text,settings,customSnapshot,progress,ct),ct).ConfigureAwait(false); }
        finally { lastUse=DateTime.UtcNow;gate.Release(); }
    }
    private sealed class Unit(int start,string original,string current,string kind="",string explanation="")
    {
        public int Start=start;
        public string Original=original, Current=current, Kind=kind, Explanation=explanation;
        public float? Confidence;
    }
    private CheckResult Check(string text,CheckSettings settings,Dictionary<string,string> custom,IProgress<CheckProgress>? progress,CancellationToken ct)
    {
        if(text.Length>300_000)throw new ArgumentException("单篇文本上限为 30 万字，请拆分后或使用批处理。");
        ct.ThrowIfCancellationRequested();var watch=Stopwatch.StartNew();rules??=new RuleSet(Path.Combine(assets,"android-rules.json"));
        if(settings.Dictionary)dictionary??=WordIndex.Load(Path.Combine(assets,"typos.txt"));
        var userIndex=new WordIndex(custom.Select(x=>new WordRule(x.Key,x.Value,[],true)));
        var segments=TextSegments.Split(text);var result=new CheckResult{Original=text,Mode=settings.Professional?"专业":"极速"};
        for(int si=0;si<segments.Count;si++)
        {
            ct.ThrowIfCancellationRequested();var segment=segments[si];string sentence=segment.Text;
            var protectedCustom=new bool[sentence.Length];
            foreach(var word in custom.Keys)
                for(int at=sentence.IndexOf(word,StringComparison.Ordinal);at>=0;at=sentence.IndexOf(word,at+1,StringComparison.Ordinal))Array.Fill(protectedCustom,true,at,word.Length);
            var hits=new (GrammarRule Rule,Match Match)?[sentence.Length];
            if(settings.Grammar)foreach(var rule in rules.Grammar)
            {
                if(!settings.Professional&&rule.ProfessionalOnly)continue;
                int at=0;
                while(at<sentence.Length)
                {
                    var m=rule.Pattern.Match(sentence,at);if(!m.Success)break;
                    if(m.Length>0&&hits[m.Index]==null&&!protectedCustom.AsSpan(m.Index,m.Length).Contains(true))hits[m.Index]=(rule,m);
                    at=m.Index+1;
                }
            }
            var units=new List<Unit>();
            void Plain(int start,string value)
            {
                int at=0;
                for(int i=0;i<value.Length;i++)if(FiveCharInference.IsTarget(value[i]))
                {
                    if(i>at)units.Add(new(start+at,value[at..i],value[at..i]));units.Add(new(start+i,value[i].ToString(),value[i].ToString()));at=i+1;
                }
                if(at<value.Length)units.Add(new(start+at,value[at..],value[at..]));
            }
            for(int p=0;p<sentence.Length;)
            {
                ct.ThrowIfCancellationRequested();var word=userIndex.Find(sentence,p);
                if(word==null&&settings.Dictionary&&!protectedCustom[p])
                {
                    word=dictionary!.Find(sentence,p);
                    if(word!=null&&protectedCustom.AsSpan(p,word.Source.Length).Contains(true))word=null;
                }
                if(word!=null){units.Add(new(segment.Start+p,word.Source,word.Replacement,word.Custom?"自定义":"错词库"));p+=word.Source.Length;continue;}
                if(hits[p] is {} hit)
                {
                    var m=hit.Match;var opt=hit.Rule.Options[0]; // Stable choice: the same input always produces the same suggestion.
                    string g1=m.Groups[1].Value,g2=m.Groups[2].Value,g3=m.Groups[3].Value;
                    string r1=opt[0]??g1,r3=opt.Length>1?opt[1]??g3:g3,exp=opt.Length>2?opt[2]??"语法建议":"语法建议";
                    if(g3=="个"&&r3=="个"&&m.Index+m.Length>0&&hits[m.Index+m.Length-1] is {} computer&&computer.Match.Groups[1].Value=="个"&&computer.Match.Groups[3].Value=="电脑")r3="台";
                    bool punctuation=exp=="标点多余"&&g2.Length==0&&((Regex.IsMatch(g1,"^[，、]+$")&&"。；：".Contains(g3))||("。；：".Contains(g1)&&Regex.IsMatch(g3,"^[，、]+$")));
                    if(punctuation){string keep=Regex.IsMatch(g1,"^[，、]+$")?g3:g1;units.Add(new(segment.Start+p,m.Value,keep,"标点",exp));p+=m.Length;continue;}
                    int cursor=m.Index;
                    for(int gi=1;gi<=3;gi++)
                    {
                        var g=m.Groups[gi];if(!g.Success)continue;
                        if(g.Index>cursor)units.Add(new(segment.Start+cursor,sentence[cursor..g.Index],"","语法",exp));
                        string replacement=gi==1?r1:gi==3?r3:g2;
                        if(replacement!=g.Value)units.Add(new(segment.Start+g.Index,g.Value,replacement,"语法",exp));else Plain(segment.Start+g.Index,g.Value);
                        cursor=g.Index+g.Length;
                    }
                    if(cursor<m.Index+m.Length)units.Add(new(segment.Start+cursor,sentence[cursor..(m.Index+m.Length)],"","语法",exp));
                    p+=m.Length;continue;
                }
                if(settings.Grammar&&!protectedCustom[p]&&p>0&&p+1<sentence.Length&&"个只条头匹辆部台口尾座把本名位".Contains(sentence[p])&&"一二两三四五六七八九十百千万这那几某".Contains(sentence[p-1])&&rules.Quantifiers.TryGetValue(sentence[p+1],out var q)&&!q.Allowed.Contains(sentence[p]))
                {
                    char next=p+2<sentence.Length?sentence[p+2]:'\0';
                    if(next<'\u4e00'||next>'\u9fff'||"的了着过是在被把让给对和与同或就也都还很太真会能可要想走跑跳吃喝咬叫哭笑我看你他她它们这那\n".Contains(next))
                    {units.Add(new(segment.Start+p,sentence[p].ToString(),q.Primary,"量词","量词搭配"));p++;continue;}
                }
                Plain(segment.Start+p,sentence[p].ToString());p++;
            }
            if(settings.Professional)
            {
                string infer=string.Concat(units.Select(u=>u.Current));var ignored=new bool[infer.Length];var mapping=new Unit[infer.Length];int pos=0;
                foreach(var u in units){Array.Fill(mapping,u,pos,u.Current.Length);if(u.Kind.Length>0)Array.Fill(ignored,true,pos,u.Current.Length);pos+=u.Current.Length;}
                if(settings.Protection)rules.MarkProtected(infer,ignored);
                bool active=Enumerable.Range(0,infer.Length).Any(i=>!ignored[i]&&FiveCharInference.IsTarget(infer[i]));
                if(active)
                {
                    progress?.Report(new(si,segments.Count,result.Changes.Count,model==null?"正在加载本地模型":"正在检查"));LoadModel(settings.Threads);
                    var prediction=FiveCharInference.Predict(infer,ignored,tokenizer!,model!,settings,ct);result.ModelCalls+=prediction.Calls;result.ReviewCalls+=prediction.Reviews;
                    foreach(var pr in prediction.Predictions)
                    {
                        char replacement=FiveCharInference.Labels[pr.Label];if(infer[pr.Position]==replacement||pr.Confidence<settings.Thresholds[pr.Label])continue;
                        var u=mapping[pr.Position];if(u.Original.Length!=1||u.Kind.Length!=0)continue;
                        u.Current=replacement.ToString();u.Kind="模型";u.Confidence=pr.Confidence;u.Explanation="HCAM V2 根据上下文预测；仅在同组字之间选择。";
                    }
                }
            }
            foreach(var u in units)if(u.Original!=u.Current)result.Changes.Add(new(){Start=u.Start,Original=u.Original,Replacement=u.Current,Kind=u.Kind,Explanation=u.Explanation,Confidence=u.Confidence});
            progress?.Report(new(si+1,segments.Count,result.Changes.Count,"正在检查"));
        }
        ct.ThrowIfCancellationRequested();result.ElapsedMs=watch.ElapsedMilliseconds;_ = result.Corrected;return result;
    }
    public async Task ReleaseIfIdleAsync(TimeSpan idle)
    {
        if(!await gate.WaitAsync(0))return;
        try{if(DateTime.UtcNow-lastUse>=idle){model?.Dispose();model=null;}}finally{gate.Release();}
    }
    public void Dispose(){gate.Wait();try{model?.Dispose();model=null;}finally{gate.Release();}}
}
