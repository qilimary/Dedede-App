using System.Text;
using System.Text.Json;

namespace Dedede.Core;

public sealed class LocalStore
{
    public string Root { get; }
    public string? RecoveryMessage { get; private set; }
    public static readonly JsonSerializerOptions JsonOptions=new(){WriteIndented=true,PropertyNameCaseInsensitive=true,Encoder=System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping};
    public LocalStore(string? root=null)
    {
        Root=root??(OperatingSystem.IsMacOS()?Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),"Library","Application Support","Dedede"):Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Dedede"));Directory.CreateDirectory(Root);
    }
    public T Load<T>(string name,Func<T> fallback)
    {
        string path=Path.Combine(Root,name);if(!File.Exists(path))return fallback();
        try{return JsonSerializer.Deserialize<T>(File.ReadAllText(path),JsonOptions)??fallback();}
        catch(Exception e) when(e is JsonException or IOException)
        {
            RecoveryMessage=$"{name} 无法读取，已保留损坏文件并恢复默认值。";
            try{File.Copy(path,path+".damaged-"+DateTime.Now.ToString("yyyyMMddHHmmss"),true);}catch(IOException){}
            return fallback();
        }
    }
    public void Save<T>(string name,T data)=>AtomicWrite(Path.Combine(Root,name),JsonSerializer.Serialize(data,JsonOptions));
    public string LoadDraft()=>Load("draft.json",()=>"");
    public void SaveDraft(string text)=>Save("draft.json",text);
    public WorkspaceState LoadWorkspace()
    {
        var saved=Load<WorkspaceState?>("workspace.json",()=>null);
        if(saved!=null)try{saved.Validate();return saved;}catch(Exception e) when(e is InvalidDataException or ArgumentException or NullReferenceException){RecoveryMessage="修订记录无法读取，已保留文件。";}
        var fallback=new WorkspaceState{Source=LoadDraft()};fallback.Result=History().FirstOrDefault(x=>x.Original==fallback.Source);
        try{fallback.Validate();}catch{fallback.Result=null;}return fallback;
    }
    public void SaveWorkspace(WorkspaceState state){state.Validate();Save("workspace.json",state);}
    public void ClearWorkspace(){Delete("workspace.json");Delete("draft.json");}
    public List<CheckResult> History()=>Load("history.json",()=>new List<CheckResult>());
    public void AddHistory(CheckResult result)
    {
        var history=History();history.Insert(0,result);
        // Bound disk usage as well as entry count. Full current result remains exportable.
        int budget=0;var bounded=history.Take(50).TakeWhile(r=>(budget+=r.Original.Length)<=2_000_000).ToList();Save("history.json",bounded);
    }
    public void Delete(string name){string path=Path.Combine(Root,name);if(File.Exists(path))File.Delete(path);}
    public static void AtomicWrite(string path,string text)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try{File.WriteAllText(temp,text,new UTF8Encoding(false));File.Move(temp,path,true);}finally{if(File.Exists(temp))File.Delete(temp);}
    }
    public static Dictionary<string,string> ParseCustomRules(string text)
    {
        if(text.TrimStart().StartsWith('{'))return JsonSerializer.Deserialize<Dictionary<string,string>>(text)??[];
        var result=new Dictionary<string,string>(StringComparer.Ordinal);
        foreach(string line in text.Split('\n'))
        {
            string trimmed=line.Trim();if(trimmed.Length==0||trimmed.StartsWith('#'))continue;
            var parts=trimmed.Split('\t',2);if(parts.Length==1)parts=trimmed.Split("=>",2,StringSplitOptions.None);
            if(parts.Length==1)parts=trimmed.Split("→",2,StringSplitOptions.None);
            string source=parts[0].Trim();if(source.Length==0)continue;result[source]=parts.Length==1?source:parts[1].Trim();
        }
        if(result.Any(x=>x.Key.Length>300||x.Value.Length>300))throw new InvalidDataException("每条规则最多 300 字。");return result;
    }
}
