using System.Globalization;
using System.Text;
using System.Text.Json;

namespace Dedede.Core;

public sealed class HcamTokenizer
{
    private readonly Dictionary<string,int> vocab=new(StringComparer.Ordinal), ranks=new(StringComparer.Ordinal);
    private readonly HashSet<string> latinVocab=new(StringComparer.Ordinal);
    public record Encoded(long[] Ids, int[] Starts, int[] Ends);
    public HcamTokenizer(string path)
    {
        using var doc=JsonDocument.Parse(File.ReadAllText(path));var root=doc.RootElement;
        if(root.GetProperty("format").GetString()!="HCAM-character-latin-bpe-tokenizer" || root.GetProperty("version").GetInt32()!=6 || root.GetProperty("latin_case_policy").GetString()!="selective_v1") throw new InvalidDataException("分词器格式与 HCAM V2 不匹配。");
        var pieces=root.GetProperty("pieces").EnumerateArray().Select(x=>x.GetString()!).ToArray();
        if(pieces.Length!=23000) throw new InvalidDataException("分词器词表大小错误。");
        for(int i=0;i<pieces.Length;i++) vocab.Add(pieces[i],i);
        string[] special=["<unk>","<pad>","<bos>","<eos>","<用户>","<助手>","<换行>","<段落>"];
        for(int i=0;i<special.Length;i++) if(pieces[i]!=special[i])throw new InvalidDataException("特殊 token 错误。");
        int[] expected=[472,510,561,724,496];for(int i=0;i<5;i++)if(Id("的地得做作"[i].ToString())!=expected[i])throw new InvalidDataException("目标字 ID 错误。");
        using var bpe=JsonDocument.Parse(root.GetProperty("latin_bpe_json").GetString()!); var model=bpe.RootElement.GetProperty("model");
        foreach(var p in model.GetProperty("vocab").EnumerateObject())latinVocab.Add(p.Name);
        int rank=0;foreach(var p in model.GetProperty("merges").EnumerateArray()) ranks.Add(p[0].GetString()+"\0"+p[1].GetString(),rank++);
    }
    private int Id(string piece)=>vocab.GetValueOrDefault(piece,0);
    private static bool Newline(char c)=>c is '\r' or '\n' or '\u2028' or '\u2029';
    private static bool Mark(Rune r)=>Rune.GetUnicodeCategory(r) is UnicodeCategory.NonSpacingMark or UnicodeCategory.SpacingCombiningMark or UnicodeCategory.EnclosingMark;
    private static bool Latin(Rune r)=>LatinScript.Contains(r.Value);
    public static string NormalizeLatin(string word)
    {
        var cased=word.EnumerateRunes().Where(r=>LatinScript.IsCased(r.Value)).ToArray();
        bool upper=cased.Any(Rune.IsUpper),lower=cased.Any(Rune.IsLower),title=cased.Length>0&&Rune.IsUpper(cased[0])&&cased.Skip(1).All(Rune.IsLower);
        if(cased.Length==1&&upper || upper&&!lower || upper&&lower&&!title)return word;
        var output=new StringBuilder();foreach(var r in word.EnumerateRunes())
        {
            // U+0130 lowercases to two code points under Unicode full lowercase; Android keeps it unchanged.
            var lo=r.Value==0x0130 ? r : Rune.ToLowerInvariant(r);output.Append(lo.Utf16SequenceLength==r.Utf16SequenceLength?lo:r);
        }
        return output.ToString();
    }
    private void EncodeLatin(string original,int offset,List<long> ids,List<int> starts,List<int> ends)
    {
        string word=NormalizeLatin(original);var parts=word.EnumerateRunes().Select(r=>r.ToString()).ToList();
        bool fallback=parts.Count>128||parts.Any(p=>!latinVocab.Contains(p));
        if(!fallback)
        {
            while(parts.Count>1)
            {
                int best=-1,bestRank=int.MaxValue;
                for(int i=0;i+1<parts.Count;i++) if(ranks.TryGetValue(parts[i]+"\0"+parts[i+1],out int rank)&&rank<bestRank){best=i;bestRank=rank;}
                if(best<0)break;parts[best]+=parts[best+1];parts.RemoveAt(best+1);
            }
            fallback=parts.Any(p=>!vocab.ContainsKey(p));
        }
        if(fallback)parts=word.EnumerateRunes().Select(r=>r.ToString()).ToList();
        int at=offset;foreach(var piece in parts){ids.Add(Id(piece));starts.Add(at);at+=piece.Length;ends.Add(at);}
    }
    public Encoded Encode(string text)
    {
        var ids=new List<long>();var starts=new List<int>();var ends=new List<int>();
        for(int p=0;p<text.Length;)
        {
            int start=p,id;
            if(text.AsSpan(p).StartsWith("<用户>")||text.AsSpan(p).StartsWith("<助手>")){id=text[p+1]=='用'?4:5;p+=4;}
            else if(Newline(text[p])){int count=0;while(p<text.Length&&Newline(text[p])){if(text[p++]=='\r'&&p<text.Length&&text[p]=='\n')p++;count++;}id=count>=2?7:6;}
            else
            {
                Rune r=Rune.GetRuneAt(text,p);
                if(Latin(r))
                {
                    p+=r.Utf16SequenceLength;
                    while(p<text.Length){var next=Rune.GetRuneAt(text,p);if(!Latin(next)&&!Mark(next))break;p+=next.Utf16SequenceLength;}
                    EncodeLatin(text[start..p],start,ids,starts,ends);continue;
                }
                p+=r.Utf16SequenceLength;id=r.Value is >=0xe000 and <=0xe003?4+r.Value-0xe000:Id(text[start..p]);
            }
            ids.Add(id);starts.Add(start);ends.Add(p);
        }
        return new(ids.ToArray(),starts.ToArray(),ends.ToArray());
    }
}
