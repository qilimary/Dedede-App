using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using UglyToad.PdfPig;
using UglyToad.PdfPig.DocumentLayoutAnalysis.TextExtractor;

namespace Dedede.Core;

public static class Documents
{
    public static readonly string[] ImageExtensions=[".png",".jpg",".jpeg",".bmp",".tif",".tiff",".webp"];
    public static string ReadText(string path)
    {
        if(new FileInfo(path).Length>64*1024*1024)throw new IOException("文件超过 64 MiB，请拆分后导入。");
        string ext=Path.GetExtension(path).ToLowerInvariant();string text;
        if(ext is ".docx" or ".pptx")text=ReadOffice(path,ext);
        else if(ext==".pdf")
        {
            using var pdf=PdfDocument.Open(path);var output=new StringBuilder();
            foreach(var page in pdf.GetPages()){output.AppendLine(ContentOrderTextExtractor.GetText(page));if(output.Length>300_000)throw new IOException("PDF 文字超过 30 万字。");}
            text=output.ToString();if(string.IsNullOrWhiteSpace(text))throw new InvalidDataException("这是扫描型或无文字层 PDF。请将需要的页面另存为图片后使用图片 OCR。");
        }
        else if(ext is ".txt" or ".md" or ".csv" or ".log" or ".srt")text=Decode(File.ReadAllBytes(path));
        else throw new NotSupportedException("不支持此格式。可导入 TXT、MD、DOCX、PPTX、文字型 PDF 或图片。");
        if(text.Length>300_000)throw new IOException("文字超过 30 万字，请拆分后导入。");return text;
    }
    public static string Decode(byte[] bytes)
    {
        if(bytes.Length>=2&&bytes[0]==0xff&&bytes[1]==0xfe)return Encoding.Unicode.GetString(bytes,2,bytes.Length-2);
        if(bytes.Length>=2&&bytes[0]==0xfe&&bytes[1]==0xff)return Encoding.BigEndianUnicode.GetString(bytes,2,bytes.Length-2);
        int start=bytes.Length>=3&&bytes[0]==0xef&&bytes[1]==0xbb&&bytes[2]==0xbf?3:0;
        try{return new UTF8Encoding(false,true).GetString(bytes,start,bytes.Length-start);}
        catch(DecoderFallbackException){Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);return Encoding.GetEncoding("GB18030",EncoderFallback.ExceptionFallback,DecoderFallback.ExceptionFallback).GetString(bytes);}
    }
    private static XDocument Xml(Stream stream)
    {
        using var reader=XmlReader.Create(stream,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=64*1024*1024});return XDocument.Load(reader);
    }
    private static string ReadOffice(string path,string extension)
    {
        using var zip=ZipFile.OpenRead(path);
        if(zip.Entries.Sum(x=>x.Length)>256L*1024*1024)throw new InvalidDataException("解压后的文档过大。");
        var output=new StringBuilder();
        if(extension==".docx")
        {
            var entry=zip.GetEntry("word/document.xml")??throw new InvalidDataException("DOCX 缺少正文。");using var stream=entry.Open();var xml=Xml(stream);XNamespace w="http://schemas.openxmlformats.org/wordprocessingml/2006/main";
            foreach(var p in xml.Descendants(w+"p"))
            {
                foreach(var e in p.Descendants()){if(e.Name==w+"t")output.Append(e.Value);else if(e.Name==w+"tab")output.Append('\t');else if(e.Name==w+"br"||e.Name==w+"cr")output.Append('\n');}output.AppendLine();
            }
        }
        else
        {
            var entries=zip.Entries.Where(x=>Regex.IsMatch(x.FullName,@"^ppt/slides/slide\d+\.xml$")).OrderBy(x=>int.Parse(Regex.Match(x.FullName,@"\d+").Value));XNamespace a="http://schemas.openxmlformats.org/drawingml/2006/main";
            foreach(var entry in entries){using var stream=entry.Open();foreach(var p in Xml(stream).Descendants(a+"p"))output.AppendLine(string.Concat(p.Descendants(a+"t").Select(x=>x.Value)));output.AppendLine();}
        }
        return output.ToString();
    }
    public static void ExportDocx(string path,string text)
    {
        XNamespace w="http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        var body=new XElement(w+"body");
        foreach(var line in text.Replace("\r\n","\n").Replace('\r','\n').Split('\n'))body.Add(new XElement(w+"p",new XElement(w+"r",new XElement(w+"t",new XAttribute(XNamespace.Xml+"space","preserve"),line))));
        string temp=path+"."+Guid.NewGuid().ToString("N")+".tmp";
        try
        {
            using(var zip=ZipFile.Open(temp,ZipArchiveMode.Create))
            {
                Add("[Content_Types].xml","<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
                Add("_rels/.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
                Add("word/document.xml",new XDocument(new XElement(w+"document",new XAttribute(XNamespace.Xmlns+"w",w),body)).ToString());
                void Add(string name,string content){using var stream=zip.CreateEntry(name).Open();using var writer=new StreamWriter(stream,new UTF8Encoding(false));writer.Write(content);}
            }
            File.Move(temp,path,true);
        }
        finally{if(File.Exists(temp))File.Delete(temp);}
    }
    public static string UniqueOutput(string directory,string source,string suffix)
    {
        string stem=Path.GetFileNameWithoutExtension(source),path=Path.Combine(directory,stem+suffix);int i=2;
        while(File.Exists(path))path=Path.Combine(directory,stem+$" ({i++})"+suffix);return path;
    }
}
