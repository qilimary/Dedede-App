using Dedede.Core;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Clipboard=System.Windows.Clipboard;
using MessageBox=System.Windows.MessageBox;
using SaveFileDialog=Microsoft.Win32.SaveFileDialog;

namespace Dedede.Windows;
public sealed class DraftWindow : Window
{
    public DraftWindow(string initial,double fontSize)
    {
        Title="纠错 Pro · 编辑成稿";Width=960;Height=760;MinWidth=600;MinHeight=440;WindowStartupLocation=WindowStartupLocation.CenterOwner;
        var layout=new DockPanel{Margin=new Thickness(18)};Content=layout;var bar=new WrapPanel{Margin=new(0,0,0,14)};DockPanel.SetDock(bar,Dock.Top);layout.Children.Add(bar);
        var editor=new TextBox{Text=initial,AcceptsReturn=true,AcceptsTab=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,FontSize=fontSize,VerticalContentAlignment=VerticalAlignment.Top};
        string saved=initial;
        void Button(string name,Action action){var button=new Button{Content=name};button.Click+=(_,_)=>{try{action();}catch(Exception ex){MessageBox.Show(this,ex.Message,"纠错 Pro");}};bar.Children.Add(button);}
        Button("撤销",()=>editor.Undo());Button("重做",()=>editor.Redo());Button("首行缩进",()=>
        {
            string text=string.Join(Environment.NewLine,editor.Text.Replace("\r\n","\n").Split('\n').Select(l=>string.IsNullOrWhiteSpace(l)?l:"　　"+l.TrimStart(' ','　')));
            editor.SelectAll();editor.SelectedText=text;
        });
        Button("复制全文",()=>Clipboard.SetText(editor.Text));Button("保存成稿",Save);layout.Children.Add(editor);
        PreviewKeyDown+=(_,e)=>{if(Keyboard.Modifiers==ModifierKeys.Control&&e.Key==Key.S){Save();e.Handled=true;}};
        Closing+=(_,e)=>{if(editor.Text!=saved&&MessageBox.Show(this,"成稿尚未保存。直接关闭？","纠错 Pro",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)e.Cancel=true;};
        void Save()
        {
            var dialog=new SaveFileDialog{FileName="成稿",Filter="纯文本|*.txt|Markdown|*.md|Word 正文|*.docx"};if(dialog.ShowDialog(this)!=true)return;
            try{if(Path.GetExtension(dialog.FileName).Equals(".docx",StringComparison.OrdinalIgnoreCase))Documents.ExportDocx(dialog.FileName,editor.Text);else LocalStore.AtomicWrite(dialog.FileName,editor.Text);saved=editor.Text;Title="纠错 Pro · 已保存成稿";}catch(Exception ex){MessageBox.Show(this,ex.Message,"保存失败");}
        }
    }
}
