using Dedede.Core;
using System.Windows;
using System.Windows.Controls;
using Clipboard=System.Windows.Clipboard;
using MessageBox=System.Windows.MessageBox;

namespace Dedede.Windows;
public sealed class MiniWindow : Window
{
    private CancellationTokenSource? task;
    private readonly TextBox input=new(){AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,FontSize=16,Height=140};
    private readonly TextBox output=new(){AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,IsReadOnly=true,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,FontSize=16,Height=170};
    public MiniWindow(CorrectionEngine engine,CheckSettings settings,Dictionary<string,string> custom,Action<string> openMain)
    {
        Title="纠错 Pro · 迷你窗口";Width=460;Height=510;MinWidth=360;MinHeight=480;Topmost=true;WindowStartupLocation=WindowStartupLocation.CenterScreen;
        var layout=new StackPanel{Margin=new Thickness(16)};Content=layout;
        layout.Children.Add(new TextBlock{Text="随手检查，继续写作",FontSize=20,FontWeight=FontWeights.Bold,Margin=new(0,0,0,12)});layout.Children.Add(input);
        var buttons=new WrapPanel{Margin=new(0,10,0,10)};layout.Children.Add(buttons);var check=new Button{Content="检查",Style=(Style)FindResource("PrimaryButton")};buttons.Children.Add(check);
        var paste=new Button{Content="粘贴"};paste.Click+=(_,_)=>{try{if(Clipboard.ContainsText())input.Text=Clipboard.GetText();}catch(Exception ex){MessageBox.Show(ex.Message);}};buttons.Children.Add(paste);
        var copy=new Button{Content="复制结果"};copy.Click+=(_,_)=>{try{if(output.Text.Length>0)Clipboard.SetText(output.Text);}catch(Exception ex){MessageBox.Show(ex.Message);}};buttons.Children.Add(copy);
        var stop=new Button{Content="停止"};stop.Click+=(_,_)=>task?.Cancel();buttons.Children.Add(stop);layout.Children.Add(output);
        var main=new Button{Content="送到主工作台",Margin=new(0,12,0,0)};main.Click+=(_,_)=>openMain(input.Text);layout.Children.Add(main);
        var status=new TextBlock{Margin=new(0,10,0,0),Text="置顶窗口 · 所有处理均在本地",TextWrapping=TextWrapping.Wrap};layout.Children.Add(status);
        input.TextChanged+=(_,_)=>{task?.Cancel();status.Text=output.Text.Length>0?"原文已变化，请重新检查。":"准备好了。";};
        check.Click+=async(_,_)=>
        {
            if(task!=null)return;using var current=new CancellationTokenSource();task=current;check.IsEnabled=false;status.Text="正在检查…";
            try{var result=await engine.CheckAsync(input.Text,settings,custom,null,current.Token);if(!current.IsCancellationRequested){output.Text=result.Corrected;status.Text=$"{result.Changes.Count} 条建议 · {result.ElapsedMs/1000.0:F2}s；逐条复核请使用主工作台。";}}
            catch(OperationCanceledException){status.Text="已取消。";}catch(Exception ex){status.Text=ex.Message;}finally{task=null;check.IsEnabled=true;}
        };
        Closed+=(_,_)=>task?.Cancel();
    }
}
