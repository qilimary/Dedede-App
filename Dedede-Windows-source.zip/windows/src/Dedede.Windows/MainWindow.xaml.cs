using Dedede.Core;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Application=System.Windows.Application;
using Clipboard=System.Windows.Clipboard;
using MessageBox=System.Windows.MessageBox;
using OpenFileDialog=Microsoft.Win32.OpenFileDialog;
using SaveFileDialog=Microsoft.Win32.SaveFileDialog;

namespace Dedede.Windows;

public partial class MainWindow : Window
{
    private readonly LocalStore store;
    private AppSettings settings;
    private readonly CorrectionEngine engine;
    private CheckResult? result;
    private CancellationTokenSource? work;
    private DesktopIntegration? desktop;
    private bool initialized,checkingSource,quitting,focusMode,syncing;
    private readonly DispatcherTimer draftTimer=new(){Interval=TimeSpan.FromMilliseconds(900)};
    private readonly DispatcherTimer idleTimer=new(){Interval=TimeSpan.FromMinutes(1)};
    private readonly ObservableCollection<BatchRow> batch=[];
    private string? batchOutput;
    private MiniWindow? mini;
    private static readonly string[] ThemeNames=["system","light","dark"],AccentNames=["blue","green","purple","apricot"];
    public MainWindow(LocalStore store)
    {
        this.store=store;settings=store.Load("settings.json",()=>new AppSettings());
        settings.Check??=new();settings.CustomRules??=[];try{settings.Check.Validate();}catch{settings.Check=new();}
        InitializeComponent();engine=new(App.Assets);BatchGrid.ItemsSource=batch;
        LoadSettingsControls();SourceBox.Text=settings.SaveDraft?store.LoadDraft():"";initialized=true;UpdateCounts();ApplyAppearance();RefreshRules();RefreshHistory();
        draftTimer.Tick+=(_,_)=>{draftTimer.Stop();try{if(settings.SaveDraft)store.SaveDraft(SourceBox.Text);}catch(Exception ex){Status("草稿保存失败："+ex.Message);}};
        idleTimer.Tick+=async(_,_)=>{try{await engine.ReleaseIfIdleAsync(TimeSpan.FromMinutes(10));}catch(Exception ex){Status(ex.Message);}};idleTimer.Start();
        Loaded+=(_,_)=>{desktop=new(this);var message=desktop.SetHotkeys(settings.Hotkeys);if(message.Length>0)Status(message);};
        BeforeBox.AddHandler(ScrollViewer.ScrollChangedEvent,new ScrollChangedEventHandler(SyncComparisonScroll));AfterBox.AddHandler(ScrollViewer.ScrollChangedEvent,new ScrollChangedEventHandler(SyncComparisonScroll));
        DiagnosticsText.Text=Diagnostics();
        OutputBox.Document=Document("在这里查看修订结果。\n\n开始检查后，可以点击彩色标记，逐条复核建议。");
    }
    private void Status(string text)=>StatusText.Text=text;
    private void Error(Exception ex){Status(ex.Message);MessageBox.Show(this,ex.Message,"纠错 Pro",MessageBoxButton.OK,MessageBoxImage.Information);}
    private bool Confirm(string text)=>MessageBox.Show(this,text,"纠错 Pro",MessageBoxButton.YesNo,MessageBoxImage.Question)==MessageBoxResult.Yes;
    private bool Busy=>work!=null;
    private CheckSettings ReadCheckSettings()
    {
        var c=settings.Check.Snapshot();c.Professional=ModeBox.SelectedIndex==0;
        if(c.Professional)
        {
            if(!float.TryParse(TemperatureBox.Text,NumberStyles.Float,CultureInfo.InvariantCulture,out var temp))throw new ArgumentException("请输入有效温度。");c.Temperature=temp;
            var boxes=new[]{T0,T1,T2,T3,T4};for(int i=0;i<5;i++){if(!float.TryParse(boxes[i].Text,NumberStyles.Float,CultureInfo.InvariantCulture,out float value))throw new ArgumentException("请输入有效修改阈值。");c.Thresholds[i]=value;}
        }
        c.Validate();settings.Check=c;return c.Snapshot();
    }
    private void SetBusy(bool busy)
    {
        CheckButton.IsEnabled=!busy;StopButton.IsEnabled=busy;WorkProgress.IsIndeterminate=busy;WorkProgress.Value=0;SourceBox.IsReadOnly=busy&&!checkingSource;
    }
    private async void StartCheck(object? sender,RoutedEventArgs e)=>await CheckAsync();
    private async Task CheckAsync()
    {
        if(Busy){Status("正在处理，请先停止当前任务。");return;}
        string snapshot=SourceBox.Text;if(string.IsNullOrWhiteSpace(snapshot)){Status("先输入一些文字吧。");return;}
        CancellationTokenSource? task=null;
        try
        {
            var config=ReadCheckSettings();store.Save("settings.json",settings);task=new();work=task;checkingSource=true;SetBusy(true);Status("正在检查…");
            var progress=new Progress<CheckProgress>(p=>{if(work!=task||task.IsCancellationRequested)return;WorkProgress.IsIndeterminate=false;WorkProgress.Value=p.Total==0?0:100.0*p.Completed/p.Total;Status($"{p.Stage} · {p.Completed}/{p.Total} 段 · {p.Changes} 条建议");});
            var checkedResult=await engine.CheckAsync(snapshot,config,settings.CustomRules,progress,task.Token);
            if(task.IsCancellationRequested||snapshot!=SourceBox.Text)return;
            result=checkedResult;RenderResult();if(settings.KeepHistory)store.AddHistory(result);RefreshHistory();
            Status($"检查完成 · {result.Changes.Count} 条建议 · {result.ElapsedMs/1000.0:F2} 秒 · 模型调用 {result.ModelCalls} 次（复查 {result.ReviewCalls} 次）");
        }
        catch(OperationCanceledException){Status("检查已停止，已有结果仍可查看。");}
        catch(Exception ex){Error(ex);}
        finally{if(work==task){work=null;checkingSource=false;SetBusy(false);}task?.Dispose();}
    }
    private void CancelWork(object? sender,RoutedEventArgs e){work?.Cancel();Status("正在停止… OCR 会在当前图片识别结束后取消。");}
    private void SourceChanged(object sender,TextChangedEventArgs e)
    {
        if(!initialized)return;if(checkingSource)work?.Cancel();UpdateCounts();draftTimer.Stop();if(settings.SaveDraft)draftTimer.Start();
        StaleWarning.Visibility=result!=null&&result.Original!=SourceBox.Text?Visibility.Visible:Visibility.Collapsed;
    }
    private void UpdateCounts()=>InputCount.Text=$"{SourceBox.Text.Length:N0} 字符";
    private void ModeChanged(object sender,SelectionChangedEventArgs e)
    {
        if(T0==null)return;bool enabled=ModeBox.SelectedIndex==0;TemperatureBox.IsEnabled=enabled;foreach(var box in new[]{T0,T1,T2,T3,T4})box.IsEnabled=enabled;
    }
    private FlowDocument Document(string text)
    {
        var doc=new FlowDocument(new Paragraph(new Run(text))){PagePadding=new Thickness(0),FontFamily=SourceBox.FontFamily,FontSize=settings.FontSize,LineHeight=settings.FontSize*1.85};return doc;
    }
    private FlowDocument DiffDocument(string mode)
    {
        var paragraph=new Paragraph{Margin=new Thickness(0)};var doc=new FlowDocument(paragraph){PagePadding=new Thickness(0),FontSize=settings.FontSize,FontFamily=SourceBox.FontFamily,LineHeight=settings.FontSize*1.85};if(result==null)return doc;
        int at=0;
        foreach(var change in result.Changes.OrderBy(c=>c.Start))
        {
            paragraph.Inlines.Add(new Run(result.Original[at..change.Start]));
            if(mode=="before")AddMark(change.Original,change,"BadBrush",false);
            else if(!change.Accepted)paragraph.Inlines.Add(new Run(change.Original));
            else if(mode=="inline") {AddMark(change.Original,change,"BadBrush",true);if(change.Replacement.Length>0)AddMark(change.Replacement,change,"GoodBrush",false);}
            else if(change.Replacement.Length>0) AddMark(change.Replacement,change,"GoodBrush",false);
            at=change.End;
        }
        paragraph.Inlines.Add(new Run(result.Original[at..]));return doc;
        void AddMark(string text,Change c,string brush,bool strike)
        {
            var run=new Run(text);if(strike)run.TextDecorations=TextDecorations.Strikethrough;
            var link=new Hyperlink(run){Background=(Brush)FindResource(brush),Foreground=(Brush)FindResource("TextBrush"),TextDecorations=null,ToolTip=c.Label+"\n"+c.Detail};
            link.Click+=(_,_)=>SelectChange(c);paragraph.Inlines.Add(link);
        }
    }
    private void RenderResult()
    {
        if(result==null)return;
        OutputBox.Document=DiffDocument("after");BeforeBox.Document=DiffDocument("before");AfterBox.Document=DiffDocument("after");InlineBox.Document=DiffDocument("inline");
        RefreshSuggestions();StaleWarning.Visibility=result.Original==SourceBox.Text?Visibility.Collapsed:Visibility.Visible;
        if(settings.KeepHistory)
        {
            var history=store.History();int at=history.FindIndex(x=>x.Created==result.Created);
            if(at>=0){history[at]=result;store.Save("history.json",history);}
        }
    }
    private void RefreshSuggestions()
    {
        var selected=Suggestions.SelectedItem as Change;string filter=(FilterBox.SelectedItem as ComboBoxItem)?.Content?.ToString()??"全部来源";
        Suggestions.ItemsSource=result?.Changes.Where(c=>filter=="全部来源" || filter=="已忽略"&&!c.Accepted || filter==c.Kind || filter=="语法"&&c.Kind is "量词" or "标点").ToList();
        SuggestionCount.Text=result==null?"开始检查后在这里逐条复核":$"{result.Changes.Count} 条建议 · 已采纳 {result.Changes.Count(c=>c.Accepted)} 条";
        if(selected!=null)Suggestions.SelectedItem=selected;
    }
    private void SelectChange(Change change){FilterBox.SelectedIndex=0;Suggestions.SelectedItem=change;Suggestions.ScrollIntoView(change);}
    private void SuggestionSelected(object sender,SelectionChangedEventArgs e)
    {
        if(Suggestions.SelectedItem is not Change change){ChangeTools.Visibility=Visibility.Collapsed;return;}
        ChangeTools.Visibility=Visibility.Visible;ReplacementBox.Text=change.Replacement;ChangeExplanation.Text=$"第 {change.Start+1} 字 · "+change.Explanation;ToggleChangeButton.Content=change.Accepted?"忽略本条":"采纳本条";
        if(result!=null&&SourceBox.Text==result.Original){SourceBox.Select(change.Start,change.Original.Length);int line=SourceBox.GetLineIndexFromCharacterIndex(change.Start);if(line>=0)SourceBox.ScrollToLine(line);}
        ScrollToChange(OutputBox,change);ScrollToChange(AfterBox,change);ScrollToChange(BeforeBox,change);
    }
    private static void ScrollToChange(RichTextBox box,Change change)
    {
        foreach(var p in box.Document.Blocks.OfType<Paragraph>())foreach(var l in p.Inlines.OfType<Hyperlink>())if(l.ToolTip?.ToString()?.StartsWith(change.Label+"\n")==true){l.BringIntoView();return;}
    }
    private void FilterChanged(object sender,SelectionChangedEventArgs e){if(initialized)RefreshSuggestions();}
    private void ToggleChange(object sender,RoutedEventArgs e){if(Suggestions.SelectedItem is Change c){c.Accepted=!c.Accepted;RenderResult();SelectChange(c);}}
    private void EditChange(object sender,RoutedEventArgs e){if(Suggestions.SelectedItem is Change c){c.Replacement=ReplacementBox.Text;c.Accepted=true;RenderResult();SelectChange(c);}}
    private void AcceptAll(object sender,RoutedEventArgs e){if(result==null)return;result.Changes.ForEach(c=>c.Accepted=true);RenderResult();}
    private void RejectAll(object sender,RoutedEventArgs e){if(result==null)return;result.Changes.ForEach(c=>c.Accepted=false);RenderResult();}
    private void WhitelistChange(object sender,RoutedEventArgs e)
    {
        if(Suggestions.SelectedItem is not Change c)return;MainTabs.SelectedIndex=3;
        RuleSource.Text=SourceBox.SelectionLength>1?SourceBox.SelectedText:c.Original;RuleReplacement.Clear();RuleSource.Focus();Status("请填写要保护的完整词语或短语，再点击添加。");
    }
    private void CopyResult(object? sender,RoutedEventArgs e){if(result==null){Status("尚无纠错结果。");return;}try{Clipboard.SetText(result.Corrected);Status(result.Original==SourceBox.Text?"已复制修订后的全文。":"已复制旧结果；原文已发生变化。");}catch(Exception ex){Error(ex);}}
    private void ExportResult(object? sender,RoutedEventArgs e)
    {
        if(result==null){Status("先完成一次检查，再导出结果。");return;}
        var dialog=new SaveFileDialog{FileName="修订文本",Filter="纯文本 (*.txt)|*.txt|Markdown (*.md)|*.md|Word 正文 (*.docx)|*.docx|全文对比报告 (*.html)|*.html|修改清单 (*.csv)|*.csv",AddExtension=true,OverwritePrompt=true};
        if(dialog.ShowDialog(this)!=true)return;
        try
        {
            string ext=Path.GetExtension(dialog.FileName).ToLowerInvariant();if(ext==".docx")Documents.ExportDocx(dialog.FileName,result.Corrected);else LocalStore.AtomicWrite(dialog.FileName,ext==".html"?Reports.Html(result):ext==".csv"?"\ufeff"+Reports.Csv(result):result.Corrected);
            Status("已导出："+dialog.FileName);
        }
        catch(Exception ex){Error(ex);}
    }
    private static OpenFileDialog FilePicker(bool multiple=true)=>new(){Multiselect=multiple,Filter="支持的文档与图片|*.txt;*.md;*.docx;*.pptx;*.pdf;*.csv;*.log;*.srt;*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp|所有文件|*.*"};
    private async void ImportFiles(object? sender,RoutedEventArgs e){var d=FilePicker();if(d.ShowDialog(this)==true)await ImportPathsAsync(d.FileNames);}
    public async Task ImportPathsAsync(string[] paths)
    {
        if(paths.Length==0)return;if(Busy){Status("请先停止正在运行的任务。");return;}
        if(paths.Length>1){AddBatchPaths(paths);MainTabs.SelectedIndex=1;Status($"已将 {paths.Length} 个文件加入批量队列。");return;}
        if(!ConfirmReplace())return;using var task=new CancellationTokenSource();work=task;SetBusy(true);
        try{string text=await ReadFileAsync(paths[0],task.Token);task.Token.ThrowIfCancellationRequested();SetSource(text);Status("已导入："+Path.GetFileName(paths[0])+"。文档仅提取正文。");}
        catch(OperationCanceledException){Status("导入已取消。");}catch(Exception ex){Error(ex);}finally{work=null;SetBusy(false);}
    }
    private bool ConfirmReplace()=>SourceBox.Text.Length==0||Confirm("用新内容替换当前输入？现有纠错结果会保留，原文可用 Ctrl+Z 撤销。");
    private void SetSource(string text)
    {
        if(text.Length>300_000)throw new InvalidDataException("单篇文本最多 30 万字。");SourceBox.BeginChange();SourceBox.SelectAll();SourceBox.SelectedText=text;SourceBox.Select(0,0);SourceBox.EndChange();MainTabs.SelectedIndex=0;DocumentTabs.SelectedIndex=0;SourceBox.Focus();
    }
    private static async Task<string> ReadFileAsync(string path,CancellationToken ct)
    {
        if(Documents.ImageExtensions.Contains(Path.GetExtension(path).ToLowerInvariant()))return await OcrService.RecognizeFileAsync(path,ct);
        return await Task.Run(()=>{ct.ThrowIfCancellationRequested();var text=Documents.ReadText(path);ct.ThrowIfCancellationRequested();return text;},ct);
    }
    private void PasteText(object sender,RoutedEventArgs e)=>OpenClipboardText();
    public void OpenClipboardText()
    {
        RestoreWindow();if(Busy){Status("当前任务仍在运行，请先停止。");return;}
        try{if(!Clipboard.ContainsText()){Status("剪贴板没有文字。");return;}if(ConfirmReplace())SetSource(Clipboard.GetText());}catch(Exception ex){Error(ex);}
    }
    private async void ImportImage(object sender,RoutedEventArgs e){var d=new OpenFileDialog{Filter="图片|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.webp"};if(d.ShowDialog(this)==true)await ImportPathsAsync([d.FileName]);}
    private void ClipboardOcr(object sender,RoutedEventArgs e)=>OpenClipboardImage();
    public async void OpenClipboardImage()
    {
        RestoreWindow();if(Busy){Status("当前任务仍在运行，请先停止。");return;}
        try{if(!Clipboard.ContainsImage()){Status("剪贴板没有图片。先用 Win+Shift+S 截图。");return;}if(!ConfirmReplace())return;var image=Clipboard.GetImage();if(image!=null)await RecognizeImageAsync(OcrService.Png(image));}catch(Exception ex){Error(ex);}
    }
    private async Task RecognizeImageAsync(byte[] png)
    {
        using var task=new CancellationTokenSource();work=task;SetBusy(true);Status("正在本地识别图片…");
        try{var text=await OcrService.RecognizeBytesAsync(png,task.Token);SetSource(text);Status("识别完成，请核对文字后再开始纠错。");}catch(OperationCanceledException){Status("识别已取消。");}catch(Exception ex){Error(ex);}finally{work=null;SetBusy(false);}
    }
    private async void ScreenOcr(object sender,RoutedEventArgs e)
    {
        if(Busy||!ConfirmReplace())return;using var task=new CancellationTokenSource();work=task;SetBusy(true);uint sequence=DesktopIntegration.GetClipboardSequenceNumber();
        try
        {
            WindowState=WindowState.Minimized;Process.Start(new ProcessStartInfo("ms-screenclip:"){UseShellExecute=true});
            byte[]? png=null;var timeout=Stopwatch.StartNew();
            while(timeout.Elapsed<TimeSpan.FromSeconds(75))
            {
                await Task.Delay(250,task.Token);
                if(sequence!=DesktopIntegration.GetClipboardSequenceNumber()&&Clipboard.ContainsImage()){var image=Clipboard.GetImage();if(image!=null){png=OcrService.Png(image);break;}}
            }
            RestoreWindow();if(png==null){Status("未收到本次截图。也可以用 Win+Shift+S 后点击剪贴板 OCR。");return;}
            Status("正在本地识别截图…");SetSource(await OcrService.RecognizeBytesAsync(png,task.Token));Status("截图识别完成，请核对后纠错。");
        }
        catch(OperationCanceledException){RestoreWindow();Status("截图已取消。");}catch(Exception ex){RestoreWindow();Error(ex);}finally{work=null;SetBusy(false);}
    }
    private async void WindowDrop(object sender,System.Windows.DragEventArgs e){if(e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop)){e.Handled=true;await ImportPathsAsync((string[])e.Data.GetData(System.Windows.DataFormats.FileDrop));}}
    private void WindowDragOver(object sender,System.Windows.DragEventArgs e){if(e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop)){e.Effects=System.Windows.DragDropEffects.Copy;e.Handled=true;}}
    private void LoadExample(object sender,RoutedEventArgs e)
    {
        if(Busy||!ConfirmReplace())return;SetSource("他认真得检查了这份报告，又把遗漏地细节补充完整。\n\n她高兴的跑进温室，看到植物长的很好，便小心地记录下叶片的变化。\n\n这项工作大约持续了三天左右。我们会在下周继续做实验，并根据实际结果作出调整。\n\n他做的作业已经交了。地理老师说，这张地图画得很清楚。");Status("示例已载入，点击开始纠错查看真实模型结果。");
    }
    private void ToggleFind(object? sender,RoutedEventArgs e){FindBar.Visibility=FindBar.Visibility==Visibility.Visible?Visibility.Collapsed:Visibility.Visible;if(FindBar.IsVisible)FindText.Focus();}
    private void FindNext(object sender,RoutedEventArgs e)
    {
        if(FindText.Text.Length==0)return;int start=Math.Min(SourceBox.Text.Length,SourceBox.SelectionStart+Math.Max(1,SourceBox.SelectionLength));int at=SourceBox.Text.IndexOf(FindText.Text,start,StringComparison.Ordinal);if(at<0)at=SourceBox.Text.IndexOf(FindText.Text,StringComparison.Ordinal);
        if(at<0){Status("没有找到匹配文字。");return;}SourceBox.Select(at,FindText.Text.Length);SourceBox.ScrollToLine(SourceBox.GetLineIndexFromCharacterIndex(at));SourceBox.Focus();
    }
    private void ReplaceAll(object sender,RoutedEventArgs e)
    {
        if(Busy&&!checkingSource)return;
        if(FindText.Text.Length==0)return;string changed=SourceBox.Text.Replace(FindText.Text,ReplaceText.Text,StringComparison.Ordinal);if(changed==SourceBox.Text){Status("没有需要替换的文字。");return;}try{SetSource(changed);Status("替换完成，可用 Ctrl+Z 撤销。");}catch(Exception ex){Error(ex);}
    }
    private void CleanPunctuation(object sender,RoutedEventArgs e)
    {
        if(Busy&&!checkingSource)return;
        string text=SourceBox.Text;string clean=Regex.Replace(text,@"(?<=[\u4e00-\u9fff])\.{2,6}(?=[\u4e00-\u9fff])","……").Replace("\u200b","").Replace("\ufeff","");
        if(text==clean){Status("未发现可整理的复制残留标记。");return;}if(Confirm("将中文句中连续英文句点整理为省略号，并删除零宽空格和 BOM。可以用 Ctrl+Z 撤销，是否继续？"))SetSource(clean);
    }
    private void SyncComparisonScroll(object sender,ScrollChangedEventArgs e)
    {
        if(syncing||!settings.SyncScroll||e.VerticalChange==0)return;syncing=true;
        try{var from=(RichTextBox)sender;var target=ReferenceEquals(from,BeforeBox)?AfterBox:BeforeBox;double height=Math.Max(0,from.ExtentHeight-from.ViewportHeight);double ratio=height>0?from.VerticalOffset/height:0;target.ScrollToVerticalOffset(ratio*Math.Max(0,target.ExtentHeight-target.ViewportHeight));}finally{syncing=false;}
    }
    private async void WindowKeyDown(object sender,System.Windows.Input.KeyEventArgs e)
    {
        var mods=Keyboard.Modifiers;
        if(e.Key==Key.Escape){work?.Cancel();e.Handled=true;}
        else if(e.Key==Key.F11){ToggleFocus(this,new());e.Handled=true;}
        else if(mods==ModifierKeys.Control&&e.Key==Key.Enter){await CheckAsync();e.Handled=true;}
        else if(mods==ModifierKeys.Control&&e.Key==Key.O){ImportFiles(this,new());e.Handled=true;}
        else if(mods==ModifierKeys.Control&&e.Key==Key.S){ExportResult(this,new());e.Handled=true;}
        else if(mods==ModifierKeys.Control&&e.Key==Key.F){MainTabs.SelectedIndex=0;ToggleFind(this,new());e.Handled=true;}
        else if(mods==(ModifierKeys.Control|ModifierKeys.Shift)&&e.Key==Key.C){CopyResult(this,new());e.Handled=true;}
    }
    private void ToggleFocus(object sender,RoutedEventArgs e){focusMode=!focusMode;SuggestionsPanel.Visibility=focusMode?Visibility.Collapsed:Visibility.Visible;SuggestionColumn.Width=focusMode?new GridLength(0):new GridLength(292);WindowState=focusMode?WindowState.Maximized:WindowState.Normal;}
    public void RestoreWindow(){Show();if(WindowState==WindowState.Minimized)WindowState=WindowState.Normal;Activate();}
    private void HideToTray(object sender,RoutedEventArgs e)=>Hide();
    private void OpenMini(object sender,RoutedEventArgs e)
    {
        if(mini!=null){mini.Activate();return;}
        try{mini=new MiniWindow(engine,ReadCheckSettings(),new(settings.CustomRules),text=>{RestoreWindow();if(ConfirmReplace())SetSource(text);});mini.Closed+=(_,_)=>mini=null;mini.Show();}catch(Exception ex){Error(ex);}
    }
    private void EditDraft(object sender,RoutedEventArgs e)
    {
        new DraftWindow(result?.Corrected??SourceBox.Text,settings.FontSize){Owner=this}.Show();
    }
    private void WindowClosing(object? sender,CancelEventArgs e)
    {
        if(!quitting&&settings.CloseToTray){e.Cancel=true;Hide();return;}
        if(!quitting){e.Cancel=true;Quit();}
    }
    public async void Quit()
    {
        if(quitting)return;
        foreach(var draft in OwnedWindows.OfType<DraftWindow>().ToArray()){draft.Close();if(draft.IsVisible)return;}
        quitting=true;work?.Cancel();mini?.Close();draftTimer.Stop();idleTimer.Stop();
        try{if(settings.SaveDraft)store.SaveDraft(SourceBox.Text);store.Save("settings.json",settings);}catch(Exception ex){MessageBox.Show("本机状态保存失败："+ex.Message,"纠错 Pro");}
        desktop?.Dispose();await Task.Run(engine.Dispose);Application.Current.Shutdown();
    }
    private void ExitApp(object sender,RoutedEventArgs e)=>Quit();
}
