using Dedede.Core;
using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Application=System.Windows.Application;
using Clipboard=System.Windows.Clipboard;
using OpenFileDialog=Microsoft.Win32.OpenFileDialog;
using SaveFileDialog=Microsoft.Win32.SaveFileDialog;

namespace Dedede.Windows;
public partial class MainWindow
{
    public sealed class BatchRow(string path) : INotifyPropertyChanged
    {
        public string Path {get;}=path;
        public string Name=>System.IO.Path.GetFileName(Path);
        public string Status {get;private set;}="等待处理";
        public string Count {get;private set;}="—";
        public string Time {get;private set;}="—";
        public event PropertyChangedEventHandler? PropertyChanged;
        public void Update(string status,int? count=null,long? milliseconds=null){Status=status;Count=count?.ToString()??"—";Time=milliseconds.HasValue?$"{milliseconds/1000.0:F2}s":"—";PropertyChanged?.Invoke(this,new(null));}
    }
    private void AddBatch(object sender,RoutedEventArgs e){if(Busy)return;var d=FilePicker();if(d.ShowDialog(this)==true)AddBatchPaths(d.FileNames);}
    private void AddBatchPaths(IEnumerable<string> paths)
    {
        foreach(var path in paths.Where(File.Exists))if(!batch.Any(x=>x.Path.Equals(path,StringComparison.OrdinalIgnoreCase)))batch.Add(new(path));
    }
    private void RemoveBatch(object sender,RoutedEventArgs e){if(Busy)return;foreach(var row in BatchGrid.SelectedItems.Cast<BatchRow>().ToArray())batch.Remove(row);}
    private async void StartBatch(object sender,RoutedEventArgs e)
    {
        if(Busy||batch.Count==0){Status("请添加文件，或等待当前任务完成。");return;}
        var picker=new OpenFolderDialog{Title="选择修订文件的输出文件夹"};if(picker.ShowDialog(this)!=true)return;
        CheckSettings config;try{config=ReadCheckSettings();}catch(Exception ex){Error(ex);return;}
        batchOutput=picker.FolderName;var custom=new Dictionary<string,string>(settings.CustomRules);using var task=new CancellationTokenSource();work=task;SetBusy(true);WorkProgress.IsIndeterminate=false;
        int completed=0,failed=0;var jobs=batch.ToArray();
        try
        {
            foreach(var row in jobs)
            {
                task.Token.ThrowIfCancellationRequested();row.Update("正在读取 / OCR");var timer=Stopwatch.StartNew();
                try
                {
                    string text=await ReadFileAsync(row.Path,task.Token);row.Update("正在检查");var check=await engine.CheckAsync(text,config,custom,null,task.Token);task.Token.ThrowIfCancellationRequested();
                    string textPath=Documents.UniqueOutput(batchOutput,row.Path,".checked.txt"),reportPath=Documents.UniqueOutput(batchOutput,row.Path,".report.html");
                    // CreateNew prevents overwriting even if another application writes the chosen filename concurrently.
                    await using(var output=new FileStream(textPath,FileMode.CreateNew,FileAccess.Write,FileShare.None))await output.WriteAsync(System.Text.Encoding.UTF8.GetBytes(check.Corrected));
                    await using(var report=new FileStream(reportPath,FileMode.CreateNew,FileAccess.Write,FileShare.None))await report.WriteAsync(System.Text.Encoding.UTF8.GetBytes(Reports.Html(check)));
                    row.Update("完成",check.Changes.Count,timer.ElapsedMilliseconds);completed++;
                }
                catch(OperationCanceledException){row.Update("已取消");throw;}
                catch(Exception ex){row.Update("失败："+ex.Message);failed++;}
                WorkProgress.Value=100.0*(completed+failed)/jobs.Length;BatchSummary.Text=$"完成 {completed} 份 · 失败 {failed} 份 · 输出到 {batchOutput}";
            }
            Status($"批量处理结束：完成 {completed} 份，失败 {failed} 份。");
        }
        catch(OperationCanceledException){Status($"批量处理已停止，已完成的 {completed} 份文件保留。");}
        finally{work=null;SetBusy(false);}
    }
    private void OpenBatchFolder(object sender,RoutedEventArgs e){if(batchOutput!=null)OpenFolder(batchOutput);}
    private void RefreshHistory()=>HistoryList.ItemsSource=store.History();
    private void ReloadHistory(object sender,RoutedEventArgs e)=>RefreshHistory();
    private void RestoreHistory(object sender,RoutedEventArgs e)
    {
        if(Busy||HistoryList.SelectedItem is not CheckResult selected||!ConfirmReplace())return;
        SetSource(selected.Original);result=selected;RenderResult();MainTabs.SelectedIndex=0;Status("已恢复历史原文和逐条修改状态。");
    }
    private void DeleteHistory(object sender,RoutedEventArgs e)
    {
        if(HistoryList.SelectedItem is not CheckResult selected)return;var history=store.History();history.RemoveAll(x=>x.Created==selected.Created);store.Save("history.json",history);RefreshHistory();
    }
    private void ClearHistory(object sender,RoutedEventArgs e){if(Confirm("清空本机全部纠错历史？此操作不能撤销。")){store.Delete("history.json");RefreshHistory();}}
    private void RefreshRules()
    {
        string query=RuleSearch.Text;RulesGrid.ItemsSource=settings.CustomRules.Where(x=>x.Key.Contains(query,StringComparison.OrdinalIgnoreCase)||x.Value.Contains(query,StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x.Key,StringComparer.Ordinal).ToList();
    }
    private void RuleSearchChanged(object sender,TextChangedEventArgs e){if(initialized)RefreshRules();}
    private void RuleSelected(object sender,SelectionChangedEventArgs e){if(RulesGrid.SelectedItem is KeyValuePair<string,string> pair){RuleSource.Text=pair.Key;RuleReplacement.Text=pair.Key==pair.Value?"":pair.Value;}}
    private void SaveRule(object sender,RoutedEventArgs e)
    {
        string source=RuleSource.Text.Trim(),replacement=RuleReplacement.Text.Trim();if(source.Length==0){Status("请填写要保护或替换的原文。");return;}
        if(source.Length==1&&replacement.Length==0&&!Confirm("单字白名单会屏蔽所有同字位置。仍然保存？"))return;
        settings.CustomRules[source]=replacement.Length==0?source:replacement;store.Save("settings.json",settings);RefreshRules();Status("规则已保存，下次检查生效。");
    }
    private void DeleteRule(object sender,RoutedEventArgs e){if(RulesGrid.SelectedItem is KeyValuePair<string,string> pair){settings.CustomRules.Remove(pair.Key);store.Save("settings.json",settings);RefreshRules();}}
    private void ImportRules(object sender,RoutedEventArgs e)
    {
        var dialog=new OpenFileDialog{Filter="自定义规则 (*.json;*.txt)|*.json;*.txt"};if(dialog.ShowDialog(this)!=true)return;
        try
        {
            if(new FileInfo(dialog.FileName).Length>4*1024*1024)throw new IOException("规则文件超过 4 MiB。");
            var imported=LocalStore.ParseCustomRules(Documents.Decode(File.ReadAllBytes(dialog.FileName)));if(imported.Any(x=>x.Key.Length==0||x.Value==null||x.Key.Length>300||x.Value.Length>300))throw new InvalidDataException("规则不能为空，且每条不能超过 300 字。");
            if(!Confirm($"合并 {imported.Count} 条规则？同名原文使用导入文件中的写法。"))return;
            foreach(var pair in imported)settings.CustomRules[pair.Key]=pair.Value;store.Save("settings.json",settings);RefreshRules();Status($"已导入 {imported.Count} 条规则。");
        }
        catch(Exception ex){Error(ex);}
    }
    private void ExportRules(object sender,RoutedEventArgs e){var d=new SaveFileDialog{FileName="纠错自定义规则.json",Filter="JSON|*.json"};if(d.ShowDialog(this)==true)try{LocalStore.AtomicWrite(d.FileName,JsonSerializer.Serialize(settings.CustomRules,LocalStore.JsonOptions));}catch(Exception ex){Error(ex);}}
    private void LoadSettingsControls()
    {
        ModeBox.SelectedIndex=settings.Check.Professional?0:1;TemperatureBox.Text=settings.Check.Temperature.ToString("0.0#",CultureInfo.InvariantCulture);
        var boxes=new[]{T0,T1,T2,T3,T4};for(int i=0;i<5;i++)boxes[i].Text=settings.Check.Thresholds[i].ToString("0.00",CultureInfo.InvariantCulture);
        ThemeBox.SelectedIndex=Math.Max(0,Array.IndexOf(ThemeNames,settings.Theme));AccentBox.SelectedIndex=Math.Max(0,Array.IndexOf(AccentNames,settings.Accent));FontSlider.Value=Math.Clamp(settings.FontSize,14,30);
        DictionaryCheck.IsChecked=settings.Check.Dictionary;GrammarCheck.IsChecked=settings.Check.Grammar;ProtectionCheck.IsChecked=settings.Check.Protection;ReviewCheck.IsChecked=settings.Check.DenseReview;ThreadsBox.Text=settings.Check.Threads.ToString();
        HistoryCheck.IsChecked=settings.KeepHistory;DraftCheck.IsChecked=settings.SaveDraft;TrayCheck.IsChecked=settings.CloseToTray;HotkeyCheck.IsChecked=settings.Hotkeys;SyncCheck.IsChecked=settings.SyncScroll;
    }
    private void SaveSettings(object sender,RoutedEventArgs e)
    {
        try
        {
            var check=ReadCheckSettings();if(!int.TryParse(ThreadsBox.Text,out int threads))throw new ArgumentException("线程数必须为整数。");check.Threads=threads;check.Dictionary=DictionaryCheck.IsChecked==true;check.Grammar=GrammarCheck.IsChecked==true;check.Protection=ProtectionCheck.IsChecked==true;check.DenseReview=ReviewCheck.IsChecked==true;check.Validate();settings.Check=check;
            settings.Theme=ThemeNames[Math.Max(0,ThemeBox.SelectedIndex)];settings.Accent=AccentNames[Math.Max(0,AccentBox.SelectedIndex)];settings.FontSize=FontSlider.Value;settings.KeepHistory=HistoryCheck.IsChecked==true;settings.SaveDraft=DraftCheck.IsChecked==true;settings.CloseToTray=TrayCheck.IsChecked==true;settings.Hotkeys=HotkeyCheck.IsChecked==true;settings.SyncScroll=SyncCheck.IsChecked==true;
            if(!settings.SaveDraft){draftTimer.Stop();store.Delete("draft.json");}store.Save("settings.json",settings);ApplyAppearance();if(result!=null)RenderResult();string message=desktop?.SetHotkeys(settings.Hotkeys)??"";Status(message.Length>0?message:"设置已保存。");
        }
        catch(Exception ex){Error(ex);}
    }
    private void ResetSettings(object sender,RoutedEventArgs e)
    {
        var custom=settings.CustomRules;settings=new(){CustomRules=custom};LoadSettingsControls();store.Save("settings.json",settings);ApplyAppearance();desktop?.SetHotkeys(settings.Hotkeys);if(result!=null)RenderResult();Status("已恢复默认设置，自定义词库保留。");
    }
    private void ApplyAppearance()
    {
        bool dark=settings.Theme=="dark";
        if(settings.Theme=="system")try{dark=Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize","AppsUseLightTheme",1) is int v&&v==0;}catch{}
        void Set(string name,string value)=>Application.Current.Resources[name]=new SolidColorBrush((Color)ColorConverter.ConvertFromString(value));
        Set("PageBrush",dark?"#141D2B":"#F3F6FA");Set("PanelBrush",dark?"#1D293B":"#FFFFFF");Set("TextBrush",dark?"#E5ECF5":"#243249");Set("MutedBrush",dark?"#A0B0C6":"#758399");Set("LineBrush",dark?"#344359":"#E0E7F0");Set("SoftBrush",dark?"#273A59":"#EAF0FD");Set("GoodBrush",dark?"#254D44":"#DFF3E9");Set("BadBrush",dark?"#643841":"#FCE5E8");Set("AccentBrush",settings.Accent switch{"green"=>"#318870","purple"=>"#8460C6","apricot"=>"#B47735",_=>"#4979DC"});
        SourceBox.FontSize=settings.FontSize;foreach(var box in new[]{OutputBox,BeforeBox,AfterBox,InlineBox})box.FontSize=settings.FontSize;
    }
    private void ClearDraft(object sender,RoutedEventArgs e){if(Busy)return;if(Confirm("清空当前草稿和自动保存的草稿？")){SourceBox.Clear();draftTimer.Stop();store.Delete("draft.json");Status("草稿已清空。");}}
    private static void OpenFolder(string path)=>Process.Start(new ProcessStartInfo(path){UseShellExecute=true});
    private void OpenDataFolder(object sender,RoutedEventArgs e)=>OpenFolder(store.Root);
    private string Diagnostics()=>$"Windows: {Environment.OSVersion}\nProcess: {System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture}\n.NET: {Environment.Version}\nONNX Runtime: 1.31.0 / CPU\nHCAM V2: INT8 per-tensor / 5 classes\nModel SHA256: {ModelRuntime.ModelHash}\nTokenizer: v6 / 23,000 tokens\nCPU logical processors: {Environment.ProcessorCount}\nData: {store.Root}";
    private void CopyDiagnostics(object sender,RoutedEventArgs e){Clipboard.SetText(Diagnostics());Status("已复制诊断信息（不含正文）。");}
    private void OpenReadme(object sender,RoutedEventArgs e)
    {
        string path=Path.Combine(AppContext.BaseDirectory,"使用说明.html");if(File.Exists(path))OpenFolder(path);else Status("请查看源码包中的 README.md 与 docs/迁移说明.md。");
    }
}
