using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;

namespace Dedede.Windows;
public static class Program
{
    private static string LogPath=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Dedede","startup.log");
    [STAThread] public static int Main(string[] args)
    {
        try
        {
            Log("Starting "+Environment.OSVersion+" / "+System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture+" / .NET "+Environment.Version);
            AppDomain.CurrentDomain.UnhandledException+=(_,e)=>Log(e.ExceptionObject.ToString()??"Unhandled error");
            if(args.Contains("--safe-render"))RenderOptions.ProcessRenderMode=RenderMode.SoftwareOnly;
            var app=new App();
            app.DispatcherUnhandledException+=(_,e)=>{Report(e.Exception);e.Handled=true;};
            app.InitializeComponent();return app.Run();
        }
        catch(Exception ex){Report(ex);return 1;}
    }
    public static void Log(string text)
    {
        try{Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);if(File.Exists(LogPath)&&new FileInfo(LogPath).Length>2_000_000)File.Move(LogPath,LogPath+".previous",true);File.AppendAllText(LogPath,DateTimeOffset.Now.ToString("O")+" "+text+Environment.NewLine);}catch{}
    }
    public static void Report(Exception ex)
    {
        Log(ex.ToString());System.Windows.MessageBox.Show("程序遇到问题："+ex.Message+"\n\n启动记录："+LogPath+"\n如果是窗口显示问题，可从开始菜单选择“纠错 Pro（兼容启动）”。","纠错 Pro",MessageBoxButton.OK,MessageBoxImage.Error);
    }
    public static void Ready()
    {
        var args=Environment.GetCommandLineArgs();int at=Array.IndexOf(args,"--startup-ready");
        if(at<0||at+1>=args.Length||!args[at+1].StartsWith("Local\\DededeReady-",StringComparison.Ordinal))return;
        try{using var signal=EventWaitHandle.OpenExisting(args[at+1]);signal.Set();}catch(WaitHandleCannotBeOpenedException){}
    }
}
