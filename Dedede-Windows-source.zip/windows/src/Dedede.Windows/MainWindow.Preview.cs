using Dedede.Core;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Dedede.Windows;
public partial class MainWindow
{
    // Run on Windows only. These are actual WPF renders, distinct from the HTML layout preview.
    public async Task CapturePreviewsAsync(string directory)
    {
        Directory.CreateDirectory(directory);Width=1440;Height=900;
        settings.KeepHistory=false;settings.SaveDraft=false;settings.CloseToTray=false;settings.Theme="light";ApplyAppearance();
        SourceBox.Text="他认真得检查了这份报告，又把遗漏地细节补充完整。\n\n她高兴的跑进温室，看到植物长的很好，便小心地记录下叶片的变化。\n\n这项工作大约持续了三天左右。我们会在下周继续做实验，并根据实际结果作出调整。\n\n他做的作业已经交了。地理老师说，这张地图画得很清楚。";
        await CheckAsync();if(result==null)throw new InvalidOperationException("Preview inference did not finish.");
        await Save("01-workspace.png");DocumentTabs.SelectedIndex=1;await Save("02-side-by-side.png");DocumentTabs.SelectedIndex=2;await Save("03-inline-diff.png");
        MainTabs.SelectedIndex=1;await Save("04-batch.png");MainTabs.SelectedIndex=3;await Save("05-rules.png");MainTabs.SelectedIndex=4;await Save("06-settings.png");
        MainTabs.SelectedIndex=0;DocumentTabs.SelectedIndex=0;settings.Theme="dark";ApplyAppearance();RenderResult();await Save("07-dark.png");
        LocalStore.AtomicWrite(Path.Combine(directory,"preview-result.json"),JsonSerializer.Serialize(result,LocalStore.JsonOptions));
        async Task Save(string filename)
        {
            await Dispatcher.InvokeAsync(()=>{},DispatcherPriority.ApplicationIdle);UpdateLayout();await Task.Delay(200);
            var bitmap=new RenderTargetBitmap((int)ActualWidth,(int)ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(this);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using var output=File.Create(Path.Combine(directory,filename));png.Save(output);
        }
    }
}
