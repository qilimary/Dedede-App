using Dedede.Core;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Dedede.Windows;
public partial class MainWindow
{
    // Run on Windows only. These are actual WPF renders, distinct from the HTML layout preview.
    public async Task CapturePreviewsAsync(string directory)
    {
        Directory.CreateDirectory(directory);Width=1440;Height=900;
        settings.KeepHistory=false;settings.SaveDraft=false;settings.CloseToTray=false;settings.Theme="light";ApplyAppearance();
        SourceBox.Text="他认真得检查了这份报告，又把遗漏地细节补充完整。\n\n她高兴的跑进温室，看到植物长的很好，便小心地记录下叶片的变化。\n\n这项工作大约持续了三天左右。我们会在下周继续做实验，并根据实际结果作出调整。\n\n他做的作业已经交了。地理老师说，这张地图画得很清楚。";
        await CheckAsync();if(result==null)throw new InvalidOperationException("Preview inference did not finish.");
        string previewText=SourceBox.Text;await VerifyDesktopAsync(directory);SetSource(previewText);await CheckAsync();
        await Save("01-workspace.png");DocumentTabs.SelectedIndex=1;await Save("02-side-by-side.png");MainTabs.SelectedIndex=5;await Save("03-help.png");
        MainTabs.SelectedIndex=1;await Save("04-batch.png");MainTabs.SelectedIndex=3;await Save("05-rules.png");MainTabs.SelectedIndex=4;await Save("06-settings.png");
        MainTabs.SelectedIndex=0;DocumentTabs.SelectedIndex=0;settings.Theme="dark";ApplyAppearance();RenderResult();await Save("07-dark.png");
        LocalStore.AtomicWrite(Path.Combine(directory,"preview-result.json"),JsonSerializer.Serialize(result,LocalStore.JsonOptions));
        async Task Save(string filename)
        {
            await Dispatcher.InvokeAsync(()=>{},DispatcherPriority.ApplicationIdle);UpdateLayout();await Task.Delay(200);
            var bitmap=new RenderTargetBitmap((int)ActualWidth,(int)ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(this);var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using var output=File.Create(Path.Combine(directory,filename));png.Save(output);
        }
    }
    private async Task VerifyDesktopAsync(string directory)
    {
        int passed=0;void Assert(bool ok,string name){if(!ok)throw new InvalidOperationException(name);passed++;}
        Assert(DocumentTabs.Items.Count==2,"two result views");Assert(result is {Changes.Count:>0},"real UI result");Assert(new System.Windows.Documents.TextRange(OutputBox.Document.ContentStart,OutputBox.Document.ContentEnd).Text.Contains("置信度"),"confidence in annotated document");
        var change=result!.Changes.First();SelectChange(change);ToggleChange(this,new());Assert(!change.Accepted,"restore original");UndoRevision(this,new());Assert(result.Changes.First().Accepted,"undo decision");RedoRevision(this,new());Assert(!result.Changes.First().Accepted,"redo decision");
        SetSource("第一段\r\n\r\n第二段");IndentText(this,new());Assert(SourceBox.Text=="　　第一段\r\n\r\n　　第二段","paragraph indentation");UndoText(this,new());Assert(SourceBox.Text=="第一段\r\n\r\n第二段","text undo");RedoText(this,new());Assert(SourceBox.Text.StartsWith("　　"),"text redo");
        settings.SaveDraft=true;SaveWorkspace();var state=store.LoadWorkspace();Assert(state.Source==SourceBox.Text&&state.Result?.Corrected==result.Corrected,"workspace saved");settings.SaveDraft=false;DraftCheck.IsChecked=false;
        ShortcutBox.Tag="Primary+Shift+Enter";UiFontSlider.Value=16;FontSlider.Value=22;SaveSettings(this,new());Assert(settings.CheckShortcut=="Primary+Shift+Enter"&&CheckButton.Content.ToString()!.Contains("Shift"),"custom shortcut");Assert(SourceBox.FontSize==22&&FontSize==16,"independent font sizes");ShortcutBox.Tag=CheckShortcut.Default;UiFontSlider.Value=14;FontSlider.Value=18;SaveSettings(this,new());
        SetSource(new string('\n',50)+"他高兴的跳了起来。");await CheckAsync();UpdateLayout();SelectChange(result!.Changes.Last());await Dispatcher.InvokeAsync(()=>{},DispatcherPriority.ApplicationIdle);Assert(OutputBox.VerticalOffset>0,"number scrolls to passage");
        LocalStore.AtomicWrite(Path.Combine(directory,"ui-checks.json"),JsonSerializer.Serialize(new{passed}));
    }
}
