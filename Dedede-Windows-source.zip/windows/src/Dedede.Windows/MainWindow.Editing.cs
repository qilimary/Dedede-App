using Dedede.Core;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
namespace Dedede.Windows;
public partial class MainWindow
{
    private void SaveWorkspace(){if(settings.SaveDraft)store.SaveWorkspace(new(){Source=SourceBox.Text,Result=result,View=DocumentTabs.SelectedIndex});}
    private void SaveHistoryState(){if(!settings.KeepHistory||result==null)return;try{var history=store.History();int at=history.FindIndex(x=>x.Created==result.Created);if(at>=0){history[at]=result;store.Save("history.json",history);}}catch(Exception ex){Status("历史保存失败："+ex.Message);}}
    private void ScheduleSave(){if(!initialized||quitting)return;draftTimer.Stop();if(settings.SaveDraft)draftTimer.Start();}
    private void ScheduleWarmup(){if(!initialized||quitting)return;warmTimer.Stop();if(settings.Check.Professional)warmTimer.Start();}
    private void JumpNumber(object sender,RoutedEventArgs e){if((sender as FrameworkElement)?.DataContext is Change c){SelectChange(c);e.Handled=true;}}
    private void UndoText(object sender,RoutedEventArgs e){SourceBox.Undo();SourceBox.Focus();}
    private void RedoText(object sender,RoutedEventArgs e){SourceBox.Redo();SourceBox.Focus();}
    private void IndentText(object sender,RoutedEventArgs e){if(!Busy)SetSource(EditorActions.IndentParagraphs(SourceBox.Text));}
    private void ClearInput(object sender,RoutedEventArgs e){if(!Busy&&ConfirmReplace()){SourceBox.SelectAll();SourceBox.SelectedText="";ClearResult();ScheduleSave();}}
    private void ContinueEditing(object sender,RoutedEventArgs e){if(result!=null&&!Busy&&ConfirmReplace()){SetSource(result.Corrected);Status("已放回原文继续编辑，可撤销此次替换。");}}
    private void ClearResult(){result=null;revisions.Clear();OutputBox.Document=Document("");BeforeBox.Document=Document("");AfterBox.Document=Document("");RefreshSuggestions();StaleWarning.Visibility=Visibility.Collapsed;ChangeTools.Visibility=Visibility.Collapsed;}
    private void UndoRevision(object sender,RoutedEventArgs e)=>ApplyRevisionUndo(false);
    private void RedoRevision(object sender,RoutedEventArgs e)=>ApplyRevisionUndo(true);
    private void ApplyRevisionUndo(bool forward){if(result==null)return;int at=(Suggestions.SelectedItem as Change)?.Number??1;if(revisions.Apply(result,forward)){RenderResult();if(result.Changes.Count>0)SelectChange(result.Changes[Math.Clamp(at-1,0,result.Changes.Count-1)]);}}
    private static string? ShortcutFromKey(KeyEventArgs e){var key=e.Key==Key.System?e.SystemKey:e.Key;string name=key.ToString();if(name=="Return")name="Enter";if(name.Length==2&&name[0]=='D'&&char.IsDigit(name[1]))name=name[1..];var mods=Keyboard.Modifiers;if(mods.HasFlag(ModifierKeys.Windows))return null;var p=new List<string>();if(mods.HasFlag(ModifierKeys.Control))p.Add("Primary");if(mods.HasFlag(ModifierKeys.Alt))p.Add("Alt");if(mods.HasFlag(ModifierKeys.Shift))p.Add("Shift");p.Add(name);string value=string.Join('+',p);return CheckShortcut.Valid(value)?value:null;}
    private void CaptureShortcut(object sender,KeyEventArgs e){if(e.Key==Key.Tab)return;e.Handled=true;var value=ShortcutFromKey(e);if(value==null){Status("请使用 Ctrl / Alt 组合键或功能键，避开编辑和系统快捷键。");return;}ShortcutBox.Tag=value;ShortcutBox.Text=CheckShortcut.Format(value,false);Status("点击保存设置后生效。");}
    private void ResetShortcut(object sender,RoutedEventArgs e){ShortcutBox.Tag=CheckShortcut.Default;ShortcutBox.Text=CheckShortcut.Format(CheckShortcut.Default,false);}
}
