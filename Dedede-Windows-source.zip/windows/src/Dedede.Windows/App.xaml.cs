using System.IO.Pipes;
using System.Text.Json;
using System.Windows;
using Dedede.Core;
using Application=System.Windows.Application;
using MessageBox=System.Windows.MessageBox;

namespace Dedede.Windows;
public partial class App : Application
{
    private Mutex? mutex;
    private bool ownsMutex;
    private readonly CancellationTokenSource shutdown=new();
    public static string Assets=>Path.Combine(AppContext.BaseDirectory,"assets");
    public LocalStore Store {get;}=new();
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException+=(s,args)=>{try{LocalStore.AtomicWrite(Path.Combine(Store.Root,"last-error.log"),args.Exception.ToString());}catch{} MessageBox.Show("操作失败："+args.Exception.Message,"纠错 Pro");args.Handled=true;};
        if(e.Args.Contains("--smoke-test"))
        {
            string output=e.Args.SkipWhile(x=>x!="--smoke-test").Skip(1).FirstOrDefault()??Path.Combine(Store.Root,"smoke-test.json");
            try
            {
                using var engine=new CorrectionEngine(Assets);var result=await engine.CheckAsync("他认真地完成了作业，开心得笑了起来。",new CheckSettings());
                string ocr=await OcrService.RecognizeFileAsync(Path.Combine(Assets,"ocr-test.png"),CancellationToken.None);
                if(!ocr.Contains("DEDEDE",StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("OCR 冒烟测试失败：没有识别到样例单词。");
                LocalStore.AtomicWrite(output,JsonSerializer.Serialize(new{passed=true,result.Corrected,result.ModelCalls,ocr,runtime=Environment.Version.ToString()},LocalStore.JsonOptions));Shutdown(0);
            }
            catch(Exception ex){LocalStore.AtomicWrite(output,JsonSerializer.Serialize(new{passed=false,error=ex.ToString()},LocalStore.JsonOptions));Shutdown(1);}return;
        }
        string key="Dedede-"+Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(Environment.UserDomainName+"\\"+Environment.UserName)))[..16];
        mutex=new Mutex(true,"Local\\"+key,out ownsMutex);
        if(!ownsMutex)
        {
            try{using var client=new NamedPipeClientStream(".",key,PipeDirection.Out);await client.ConnectAsync(2500);using var writer=new StreamWriter(client);await writer.WriteLineAsync(JsonSerializer.Serialize(e.Args));}
            catch(Exception ex){MessageBox.Show("程序已运行，但未能唤醒。请从系统托盘打开。\n"+ex.Message,"纠错 Pro");}Shutdown();return;
        }
        bool preview=e.Args.Contains("--render-preview");
        var window=new MainWindow(preview?new LocalStore(Path.Combine(Path.GetTempPath(),"DededePreview-"+Guid.NewGuid().ToString("N"))):Store);MainWindow=window;window.Show();
        if(preview)
        {
            try{string directory=e.Args.SkipWhile(x=>x!="--render-preview").Skip(1).FirstOrDefault()??"previews";await window.CapturePreviewsAsync(directory);window.Quit();}
            catch(Exception ex){LocalStore.AtomicWrite("preview-error.log",ex.ToString());Shutdown(1);}return;
        }
        _=ListenAsync(key,window,shutdown.Token);
        if(e.Args.Length>0)await window.ImportPathsAsync(e.Args.Where(File.Exists).ToArray());
        if(Store.RecoveryMessage!=null)MessageBox.Show(Store.RecoveryMessage,"纠错 Pro");
    }
    private async Task ListenAsync(string key,MainWindow window,CancellationToken ct)
    {
        while(!ct.IsCancellationRequested)
        {
            try
            {
                using var server=new NamedPipeServerStream(key,PipeDirection.In,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous|PipeOptions.CurrentUserOnly);
                await server.WaitForConnectionAsync(ct);using var reader=new StreamReader(server);string? line=await reader.ReadLineAsync(ct);
                var paths=JsonSerializer.Deserialize<string[]>(line??"[]")??[];
                await Dispatcher.InvokeAsync(async()=>{window.RestoreWindow();await window.ImportPathsAsync(paths.Where(File.Exists).ToArray());});
            }
            catch(OperationCanceledException){break;}catch(IOException){await Task.Delay(500,ct).ConfigureAwait(false);}catch(JsonException){}
        }
    }
    protected override void OnExit(ExitEventArgs e){shutdown.Cancel();if(ownsMutex)mutex?.ReleaseMutex();mutex?.Dispose();base.OnExit(e);}
}
