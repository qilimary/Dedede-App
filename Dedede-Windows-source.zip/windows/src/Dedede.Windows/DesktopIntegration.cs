using System.Runtime.InteropServices;
using System.Windows.Interop;
using System.Windows;
using Forms=System.Windows.Forms;

namespace Dedede.Windows;
public sealed class DesktopIntegration : IDisposable
{
    [DllImport("user32.dll",SetLastError=true)]private static extern bool RegisterHotKey(IntPtr hwnd,int id,uint modifiers,uint key);
    [DllImport("user32.dll")]private static extern bool UnregisterHotKey(IntPtr hwnd,int id);
    [DllImport("user32.dll")]public static extern uint GetClipboardSequenceNumber();
    private readonly MainWindow owner;
    private readonly Forms.NotifyIcon tray;
    private HwndSource? source;
    private IntPtr handle;
    public DesktopIntegration(MainWindow window)
    {
        owner=window;var menu=new Forms.ContextMenuStrip();menu.Items.Add("打开工作台",null,(_,_)=>owner.Dispatcher.Invoke(owner.RestoreWindow));menu.Items.Add("检查剪贴板文字",null,(_,_)=>owner.Dispatcher.InvokeAsync(owner.OpenClipboardText));menu.Items.Add("识别剪贴板图片",null,(_,_)=>owner.Dispatcher.InvokeAsync(owner.OpenClipboardImage));menu.Items.Add(new Forms.ToolStripSeparator());menu.Items.Add("退出",null,(_,_)=>owner.Dispatcher.Invoke(owner.Quit));
        tray=new Forms.NotifyIcon{Text="纠错 Pro · 本地中文纠错",Icon=new System.Drawing.Icon(Path.Combine(App.Assets,"app.ico")),ContextMenuStrip=menu,Visible=false};tray.DoubleClick+=(_,_)=>owner.RestoreWindow();
        handle=new WindowInteropHelper(owner).Handle;source=HwndSource.FromHwnd(handle);source?.AddHook(Hook);
    }
    public void SetTrayVisible(bool enabled)=>tray.Visible=enabled;
    public string SetHotkeys(bool enabled)
    {
        UnregisterHotKey(handle,1);UnregisterHotKey(handle,2);if(!enabled)return "";
        bool text=RegisterHotKey(handle,1,0x0002|0x0001|0x4000,0x44),ocr=RegisterHotKey(handle,2,0x0002|0x0001|0x4000,0x4f);
        return text&&ocr?"":"部分全局快捷键被其他程序占用；仍可使用托盘菜单。";
    }
    private IntPtr Hook(IntPtr h,int msg,IntPtr w,IntPtr l,ref bool handled)
    {
        if(msg==0x0312){handled=true;if(w.ToInt32()==1)owner.OpenClipboardText();else if(w.ToInt32()==2)owner.OpenClipboardImage();}return IntPtr.Zero;
    }
    public void Dispose(){UnregisterHotKey(handle,1);UnregisterHotKey(handle,2);source?.RemoveHook(Hook);tray.Visible=false;tray.Icon?.Dispose();tray.Dispose();}
}
