using System.Windows.Media.Imaging;
using Tesseract;

namespace Dedede.Windows;
public static class OcrService
{
    private static readonly SemaphoreSlim Gate=new(1,1);
    public static async Task<string> RecognizeFileAsync(string path,CancellationToken ct)
    {
        if(new FileInfo(path).Length>64*1024*1024)throw new IOException("图片超过 64 MiB。");
        return await RecognizeBytesAsync(await File.ReadAllBytesAsync(path,ct),ct);
    }
    public static byte[] Png(BitmapSource bitmap)
    {
        var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(bitmap));using var stream=new MemoryStream();encoder.Save(stream);return stream.ToArray();
    }
    public static async Task<string> RecognizeBytesAsync(byte[] bytes,CancellationToken ct)
    {
        await Gate.WaitAsync(ct);
        try
        {
            return await Task.Run(()=>
            {
                ct.ThrowIfCancellationRequested();
                using var input=new MemoryStream(bytes);var decoder=BitmapDecoder.Create(input,BitmapCreateOptions.PreservePixelFormat,BitmapCacheOption.OnDemand);var frame=decoder.Frames[0];
                if((long)frame.PixelWidth*frame.PixelHeight>20_000_000)throw new IOException("图片超过 2000 万像素，请先裁剪或缩小。");
                byte[] png=Png(frame);
                using var engine=new TesseractEngine(Path.Combine(App.Assets,"tessdata"),"chi_sim+eng",EngineMode.LstmOnly);
                engine.SetVariable("preserve_interword_spaces","1");using var image=Pix.LoadFromMemory(png);
                ct.ThrowIfCancellationRequested();using var page=engine.Process(image,PageSegMode.Auto);string text=page.GetText();ct.ThrowIfCancellationRequested();
                if(string.IsNullOrWhiteSpace(text))throw new InvalidDataException("没有识别到文字。请使用更清晰的图片。");return text;
            },ct);
        }
        catch(DllNotFoundException ex){throw new InvalidOperationException("OCR 缺少微软 VC++ x64 运行库，请运行安装包中 prerequisites/vc_redist.x64.exe。",ex);}
        catch(NotSupportedException ex){throw new InvalidOperationException("本机图片解码器不支持此格式。请先转换为 PNG 或 JPG 后再识别。",ex);}
        finally{Gate.Release();}
    }
}
