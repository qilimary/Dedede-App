"""Unicode script/full-casing tables: runtime remains independent of Python."""
import regex
from pathlib import Path
chars=''.join(map(chr,range(0x110000)))
latin=[(m.start(),m.end()-1) for m in regex.finditer(r'\p{Latin}+',chars)]
cased=[]
for a,b in latin:
    for i in range(a,b+1):
        x=chr(i)
        if x.lower()==x.upper():continue
        if cased and cased[-1][1]==i-1:cased[-1]=(cased[-1][0],i)
        else:cased.append((i,i))
def array(items):return '['+','.join(f'(0x{a:x},0x{b:x})' for a,b in items)+']'
code='namespace Dedede.Core;\ninternal static class LatinScript\n{\n'
code+='    private static readonly (int Start,int End)[] Ranges = '+array(latin)+';\n'
code+='    private static readonly (int Start,int End)[] Cased = '+array(cased)+';\n'
code+='    public static bool Contains(int cp) => Ranges.Any(r=>cp>=r.Start&&cp<=r.End);\n'
code+='    public static bool IsCased(int cp) => Cased.Any(r=>cp>=r.Start&&cp<=r.End);\n}\n'
(Path(__file__).resolve().parents[1]/'src/Dedede.Core/LatinScript.cs').write_text(code)
