@echo off
cd /d "%~dp0"
start "" "%~dp0Dedede-Launcher.exe" --safe-render %*
