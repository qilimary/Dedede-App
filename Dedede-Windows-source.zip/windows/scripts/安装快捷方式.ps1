﻿$ErrorActionPreference = 'Stop'
$appDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$executable = Join-Path $appDirectory 'Dedede-Launcher.exe'
if (-not (Test-Path $executable)) { throw '请在完整解压后的运行包中执行此脚本。' }
$shellObject = New-Object -ComObject WScript.Shell
$desktopPath = [Environment]::GetFolderPath('Desktop')
$sendToPath = [Environment]::GetFolderPath('SendTo')
foreach ($path in @((Join-Path $desktopPath '纠错 Pro.lnk'), (Join-Path $sendToPath '纠错 Pro.lnk'))) {
  $shortcut = $shellObject.CreateShortcut($path)
  $shortcut.TargetPath = $executable
  $shortcut.WorkingDirectory = $appDirectory
  $shortcut.IconLocation = (Join-Path $appDirectory 'assets/app.ico') + ',0'
  $shortcut.Save()
}
Write-Host '已添加桌面快捷方式和右键“发送到 → 纠错 Pro”。移动程序文件夹后请重新运行此脚本。'
