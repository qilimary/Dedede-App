@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%SystemRoot%\System32\vcruntime140.dll" goto install
if not exist "%SystemRoot%\System32\msvcp140.dll" goto install
if not exist "%SystemRoot%\System32\msvcp140_1.dll" goto install
if not exist "%SystemRoot%\System32\vcruntime140_1.dll" goto install
goto launch
:install
echo 本机需要安装微软 VC++ x64 运行库。安装完成后将打开纠错 Pro。
if not exist "prerequisites\vc_redist.x64.exe" (
  echo 找不到运行库安装程序，请重新解压完整安装包。
  pause
  exit /b 1
)
start /wait "" "prerequisites\vc_redist.x64.exe" /install /passive /norestart
if errorlevel 3011 goto failed
if errorlevel 3010 goto launch
if errorlevel 1 goto failed
:launch
start "" "Dedede.exe" %*
exit /b 0
:failed
echo 运行库安装未完成。可手动运行 prerequisites\vc_redist.x64.exe 后再启动。
pause
exit /b 1
