@echo off
cd /d "%~dp0"
if not exist "Dedede-Launcher.exe" (
 echo Launcher is missing. Please reinstall the complete application.
 pause
 exit /b 1
)
start "" "%~dp0Dedede-Launcher.exe" %*
