"""Extract the current Android grammar/protection definitions without executing its build.
Usage: python scripts/import_android_rules.py /path/to/extracted/MainActivity.java
The resulting JSON is committed; users do not need Android tools to build Windows.
"""
import json, re, sys, hashlib
from pathlib import Path

src = Path(sys.argv[1]); text = src.read_text(encoding='utf-8')
section = text[text.index('    public static synchronized void ensureRulesLoaded()'):text.index('    public static final String NUMS')]
variables = {}; rules = []; protections = []
literal = r'"(?:\\.|[^"\\])*"'
token = re.compile(literal + r'|[A-Za-z_]\w*(?:\[\w+\])?|\d+')
def expr(raw):
    values=[]
    for m in token.finditer(raw):
        s=m.group()
        if s.startswith('"'): values.append(json.loads(s))
        elif s.isdigit(): values.append(int(s))
        elif '[' in s:
            name,key=s[:-1].split('['); values.append(variables[name][variables[key]])
        else: values.append(variables[s])
    return ''.join(map(str,values))
def add(line):
    m=re.match(r'add(Professional)?Rule\((.*?), new String\[\]\[\]\{(.*)\}\);',line)
    if m:
        opts=[]
        for pair in re.findall(r'\{([^{}]*)\}',m[3]):
            opts.append([None if t=='null' else expr(t) for t in re.findall(literal+r'|null|\w+\[\w+\]',pair)])
        rules.append({'pattern':expr(m[2]),'options':opts,'professionalOnly':bool(m[1])}); return
    m=re.match(r'addProtectedTargetPattern\((.*)\);',line)
    if m: protections.append(expr(m[1])); return
    raise ValueError(line)
for line in section.splitlines():
    line=line.strip()
    if line.startswith('String '):
        m=re.match(r'String (\w+) = (.*);',line); variables[m[1]]=expr(m[2])
    elif line.startswith('String[] '):
        m=re.match(r'String\[\] (\w+) = \{(.*)\};',line); variables[m[1]]=[json.loads(s) for s in re.findall(literal,m[2])]
    elif line.startswith('add'): add(line)
    elif line.startswith('for (int i'):
        m=re.match(r'for \(int i = (\d+); i <= (\d+); i\+\+\) (.*)',line)
        for i in range(int(m[1]),int(m[2])+1):variables['i']=i;add(m[3])
ignore=re.search(r'IGNORE_WORDS = \{(.*?)\};',text,re.S)[1]
quants=re.findall(r"quantRules.put\('(.)', new QuantifierRule\(("+literal+'), ('+literal+r')\)\);',section)
data={'sourceCommit':'10baa0cb64edc2dcb8add1ac46b22ab234398ff4','sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'rules':rules,'protectedPatterns':protections,'ignoreWords':[json.loads(s) for s in re.findall(literal,ignore)],'quantifiers':{a:[json.loads(b),json.loads(c)] for a,b,c in quants}}
out=Path(__file__).resolve().parents[1]/'assets/android-rules.json';out.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print('Grammar',len(rules),'protected patterns',len(protections),'ignored terms',len(data['ignoreWords']),'quantifiers',len(quants))
