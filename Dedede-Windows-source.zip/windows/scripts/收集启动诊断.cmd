@echo off
set "DededeDiagnostic=%LOCALAPPDATA%\Dedede"
if not exist "%DededeDiagnostic%" mkdir "%DededeDiagnostic%"
(ver & echo PROCESSOR_ARCHITECTURE=%PROCESSOR_ARCHITECTURE% & echo "APP=%~dp0" & dir "%~dp0Dedede*.exe" & dir "%SystemRoot%\System32\*vcp140*.dll" & dir "%SystemRoot%\System32\vcruntime140*.dll") > "%DededeDiagnostic%\environment.txt" 2>&1
start "" explorer.exe "%DededeDiagnostic%"
