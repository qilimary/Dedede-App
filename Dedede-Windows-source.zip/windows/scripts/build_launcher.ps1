param([Parameter(Mandatory=$true)][string]$OutputDirectory)
$ErrorActionPreference='Stop'
$out=[IO.Path]::GetFullPath($OutputDirectory)
$native=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../native'))
New-Item -ItemType Directory $out -Force | Out-Null
$vswhere="${env:ProgramFiles(x86)}/Microsoft Visual Studio/Installer/vswhere.exe"
$vs=if(Test-Path $vswhere){& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath}
if($vs){
 $build=Join-Path $out 'compile-launcher.cmd'
 $commands=@"
@echo off
chcp 65001 >nul
call "$vs\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "$native"
rc /nologo /fo "$out\launcher.res" launcher.rc
if errorlevel 1 exit /b 1
cl /nologo /O2 /W4 /MT /utf-8 /DUNICODE /D_UNICODE launcher.c /Fo"$out\launcher.obj" /Fe"$out\Dedede-Launcher.exe" "$out\launcher.res" /link /SUBSYSTEM:WINDOWS /MANIFEST:NO user32.lib shell32.lib gdi32.lib
exit /b %errorlevel%
"@
 [IO.File]::WriteAllText($build,$commands,[Text.UTF8Encoding]::new($false))
 & cmd /c $build
 if($LASTEXITCODE -ne 0){throw 'Native launcher build failed.'}
}else{
 $expected=(Get-Content "$native/launcher.sha256" -Raw).Trim()
 if((Get-FileHash "$native/Dedede-Launcher.exe").Hash -ne $expected){throw 'Bundled launcher checksum mismatch.'}
 Copy-Item "$native/Dedede-Launcher.exe" $out -Force
}
