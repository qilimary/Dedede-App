"""Build-time model download. The installed application never downloads a model."""
from pathlib import Path
import hashlib, sys

root=Path(__file__).resolve().parents[1]
resources=[('HCAM_V2_5CHAR_INT8_PT.onnx','1RApK3KpMDIWG6fkro6c8YhVwpcooB-d3','15f0af5c03857ac2b049ac9f02cfe1dde2fba11ea639e191ca6453cb9a6e75cc',122647221),('tokenizer.json','11ixL7TOQfKEfwnVhQmHK_z_cEe5VIeso','bed4387895500314ffba9608340c56069ca6df8635029535b9becdef8ce7ddf0',327784)]
def valid(path,sha,size):return path.is_file() and path.stat().st_size==size and hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==sha
for name,fileid,sha,size in resources:
    dest=root/'assets/models'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    if valid(dest,sha,size):print(name,'verified');continue
    try:import gdown
    except ImportError:sys.exit('Install build-time downloader: python -m pip install gdown==5.2.0')
    temp=dest.with_suffix(dest.suffix+'.download');gdown.download(id=fileid,output=str(temp),quiet=False,use_cookies=False)
    if not valid(temp,sha,size):sys.exit('Model integrity check failed: '+name)
    temp.replace(dest);print(name,'downloaded and verified')
