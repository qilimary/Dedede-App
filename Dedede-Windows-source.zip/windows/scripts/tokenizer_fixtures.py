"""Independent Hugging Face Tokenizers BPE oracle for .NET tokenizer parity."""
import json, regex, random
from pathlib import Path
from tokenizers import Tokenizer
root=Path(__file__).resolve().parents[1]
j=json.loads((root/'assets/models/tokenizer.json').read_text());vocab={s:i for i,s in enumerate(j['pieces'])};bpe=Tokenizer.from_str(j['latin_bpe_json'])
def utf16(s):return len(s.encode('utf-16-le'))//2
def norm(word):
    c=[x for x in word if x.lower()!=x.upper()];upper=any(x.isupper() for x in c);lower=any(x.islower() for x in c);title=bool(c) and c[0].isupper() and all(x.islower() for x in c[1:])
    if (len(c)==1 and upper) or (upper and not lower) or (upper and lower and not title):return word
    return ''.join(x.lower() if len(x.lower())==1 and utf16(x.lower())==utf16(x) else x for x in word)
def encode(text):
    ids=[];starts=[];ends=[];p=0
    while p<len(text):
        start=p
        if text.startswith(('<用户>','<助手>'),p):pieces=[text[p:p+4]];p+=4
        elif text[p] in '\r\n\u2028\u2029':
            count=0
            while p<len(text) and text[p] in '\r\n\u2028\u2029':
                old=text[p];p+=1
                if old=='\r' and p<len(text) and text[p]=='\n':p+=1
                count+=1
            pieces=['<段落>' if count>=2 else '<换行>']
        else:
            m=regex.match(r'\p{Latin}[\p{Latin}\p{M}]*',text[p:])
            if m:
                original=m[0];word=norm(original);p+=len(original)
                if len(word)>128 or any(c not in bpe.get_vocab() for c in word):pieces=list(word)
                else:
                    pieces=bpe.encode(word,add_special_tokens=False).tokens
                    if any(t not in vocab for t in pieces):pieces=list(word)
                offset=utf16(text[:start])
                for piece in pieces:ids.append(vocab.get(piece,0));starts.append(offset);offset+=utf16(piece);ends.append(offset)
                continue
            else:pieces=[text[p]];p+=1
        piece=pieces[0];ids.append(4+ord(piece)-0xe000 if len(piece)==1 and 0xe000<=ord(piece)<=0xe003 else vocab.get(piece,0));starts.append(utf16(text[:start]));ends.append(utf16(text[:p]))
    return {'text':text,'ids':ids,'starts':starts,'ends':ends}
samples=['','他做的作业。','English english NASA OpenAI ChatGPT iPhone XMLHttpRequest','École Straße İSTANBUL İstanbul Ångström naïve Cafe\u0301','A a I AI Aa aA','\r\n\r\n\n的😀地𠀀得','<用户>做什么？<助手>记录植物。','\ue000的\ue001地\ue002做\ue003作','a'*129,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','ǅ Ǆ ǆ Æ Ł Þ ﬀ ɑ ᴀ Ᵽ Ɦ','123 3.14\tCamelCase 你好']
rng=random.Random(17);parts=['他','的','地','得','做','作','NASA','Hello','Windows','iPhone','GPU','Apple','openai','ChatGPT','école','Straße','İstanbul','😀','𠀀','\r\n','\n\n','。','，',' ',':','\t','123']
samples += [''.join(rng.choices(parts,k=rng.randrange(1,50))) for _ in range(240)]
dest=root/'tests/tokenizer-fixtures.json';dest.write_text(json.dumps([encode(s) for s in samples],ensure_ascii=False),encoding='utf-8');print(len(samples),'tokenizer fixtures')
