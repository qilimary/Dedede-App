"""Wrap a finished installer for sharing without changing the installer bytes."""
from pathlib import Path
import hashlib
import os
import sys
import zipfile


def package(installer: Path) -> Path:
    installer = installer.resolve(strict=True)
    if installer.suffix.lower() not in (".exe", ".dmg") or installer.stat().st_size == 0:
        raise ValueError("Expected a nonempty EXE or DMG installer.")
    output = installer.with_suffix(".zip")
    temporary = output.with_name(output.name + ".tmp")
    steps = ("双击安装程序，按提示完成安装。" if installer.suffix.lower() == ".exe"
             else "打开 DMG，将“纠错 Pro”拖入 Applications。")
    guide = ("纠错 Pro · 安装说明\n\n"
             "1. 将此 ZIP 解压到一个文件夹。\n"
             f"2. 打开 {installer.name}。{steps}\n\n"
             "压缩包内是完整安装程序，包含离线模型。\n"
             "不要从 ZIP 内直接运行；先解压，再打开安装程序。\n")
    try:
        # EXE/DMG payloads are already compressed; storing avoids costly recompression.
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_STORED) as archive:
            archive.write(installer, installer.name)
            archive.writestr("README.txt", guide.encode("utf-8-sig"))
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError("ZIP integrity check failed.")
            with archive.open(installer.name) as payload, installer.open("rb") as source:
                if hashlib.file_digest(payload, "sha256").digest() != hashlib.file_digest(source, "sha256").digest():
                    raise ValueError("ZIP payload differs from the installer.")
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return output


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python package_installer.py <installer.exe|installer.dmg>")
    print(package(Path(sys.argv[1])))
