"""Create the single source upload expected by .github/workflows/windows.yml."""
from pathlib import Path
import hashlib,json,zipfile,sys
root=Path(__file__).resolve().parents[2]
output=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'Dedede-Windows-source.zip'
files={}
for folder in ('windows','macos'):
 for p in sorted((root/folder).rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or p.is_symlink() or any(x in ('bin','obj','dist','prerequisites','__pycache__') or x.startswith('.package.') for x in rel.parts):continue
  if p.suffix in ('.onnx','.pyc','.pdb') or p.name.endswith('.log'):continue
  files[rel.as_posix()]=p.read_bytes()
manifest={'format':1,'files':{n:hashlib.sha256(v).hexdigest() for n,v in files.items()}}
output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in files.items():z.writestr(name,data)
 z.writestr('SOURCE-SHA256.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'file':str(output),'files':len(files),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
