param([switch]$SkipTests,[switch]$Portable,[switch]$Installer)
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 if(-not(Get-Command dotnet -ErrorAction SilentlyContinue)){throw 'Install .NET 10 SDK 10.0.401+ first.'}
 if(-not(Test-Path 'assets/models/HCAM_V2_5CHAR_INT8_PT.onnx')){
  python -m pip install gdown==5.2.0
  if($LASTEXITCODE -ne 0){throw 'Downloader setup failed.'}
  python scripts/fetch_model.py
  if($LASTEXITCODE -ne 0){throw 'Model download failed.'}
 }
 if((Get-FileHash 'assets/models/HCAM_V2_5CHAR_INT8_PT.onnx').Hash -ne '15f0af5c03857ac2b049ac9f02cfe1dde2fba11ea639e191ca6453cb9a6e75cc'){throw 'Model checksum mismatch.'}
 if((Get-FileHash 'assets/models/tokenizer.json').Hash -ne 'bed4387895500314ffba9608340c56069ca6df8635029535b9becdef8ce7ddf0'){throw 'Tokenizer checksum mismatch.'}
 if(-not $SkipTests){dotnet run --project tests/Dedede.Tests/Dedede.Tests.csproj -c Release -- .;if($LASTEXITCODE -ne 0){throw 'Core tests failed.'}}
 dotnet restore src/Dedede.Windows/Dedede.Windows.csproj --locked-mode
 if($LASTEXITCODE -ne 0){throw 'Locked restore failed.'}
 $publish=Join-Path $PSScriptRoot 'dist/Dedede-Windows-x64'
 dotnet publish src/Dedede.Windows/Dedede.Windows.csproj -c Release --no-restore -o $publish
 if($LASTEXITCODE -ne 0){throw 'Publish failed.'}
 $native=Join-Path $PSScriptRoot 'obj/native'
 & scripts/build_launcher.ps1 -OutputDirectory $native
 Copy-Item "$native/Dedede-Launcher.exe" $publish -Force
 Copy-Item 'docs/使用说明.html','THIRD-PARTY-NOTICES.txt' $publish -Force
 Copy-Item 'scripts/收集启动诊断.cmd','scripts/安装快捷方式.ps1','scripts/添加快捷方式.cmd' $publish -Force
 New-Item -ItemType Directory "$publish/prerequisites",'prerequisites' -Force | Out-Null
 if(-not(Test-Path 'prerequisites/vc_redist.x64.exe')){Invoke-WebRequest 'https://aka.ms/vc14/vc_redist.x64.exe' -OutFile 'prerequisites/vc_redist.x64.exe'}
 $signature=Get-AuthenticodeSignature 'prerequisites/vc_redist.x64.exe'
 if($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft Corporation'){throw 'Microsoft VC++ signature verification failed.'}
 Copy-Item 'prerequisites/vc_redist.x64.exe' "$publish/prerequisites/" -Force
 if(Test-Path "$publish/x86"){Remove-Item "$publish/x86" -Recurse -Force}
 if(-not $SkipTests){
  $report=Join-Path $PSScriptRoot 'dist/smoke-test.json'
  $p=Start-Process "$publish/Dedede.exe" -ArgumentList '--smoke-test',('"'+$report+'"') -PassThru
  if(-not $p.WaitForExit(180000)){Stop-Process -Id $p.Id -Force;throw 'Windows smoke test timed out.'}
  if($p.ExitCode -ne 0 -or -not(Test-Path $report) -or -not((Get-Content $report -Raw|ConvertFrom-Json).passed)){throw 'Windows model/OCR smoke test failed.'}
 }
 if($Installer){
  $iscc=@('C:/Program Files/Inno Setup 7/ISCC.exe','C:/Program Files (x86)/Inno Setup 7/ISCC.exe','C:/Program Files (x86)/Inno Setup 6/ISCC.exe','C:/Program Files/Inno Setup 6/ISCC.exe')|Where-Object{Test-Path $_}|Select-Object -First 1
  if(-not $iscc){$iscc=(Get-Command ISCC -ErrorAction Stop).Source}
  $vc=(Get-Item 'prerequisites/vc_redist.x64.exe').VersionInfo
  $minimum="$($vc.ProductMajorPart).$($vc.ProductMinorPart).$($vc.ProductBuildPart).$($vc.ProductPrivatePart)"
  & $iscc "/DVCMinimumVersion=$minimum" installer/Dedede.iss
  if($LASTEXITCODE -ne 0){throw 'Installer compilation failed.'}
  python scripts/package_installer.py 'dist/Dedede-Windows-Setup.exe'
  if($LASTEXITCODE -ne 0){throw 'Installer ZIP verification failed.'}
 }
 if($Portable){Compress-Archive -Path $publish -DestinationPath 'dist/Dedede-Windows-x64.zip' -Force}
 Write-Host "Ready: $publish"
} finally {Pop-Location}
