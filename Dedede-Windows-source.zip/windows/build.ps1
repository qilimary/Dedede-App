﻿param([switch]$SkipTests)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw 'Please install .NET 10 SDK (10.0.401 or a later 10.0.4xx patch).' }
if (-not (Test-Path 'assets/models/HCAM_V2_5CHAR_INT8_PT.onnx')) {
  if (-not (Get-Command python -ErrorAction SilentlyContinue)) { throw 'Model missing. Use GitHub Actions or install Python 3.11+ for the build-time downloader.' }
  python -m pip install gdown==5.2.0
  if ($LASTEXITCODE -ne 0) { throw 'Downloader installation failed.' }
  python scripts/fetch_model.py
  if ($LASTEXITCODE -ne 0) { throw 'Model download failed.' }
}
$modelHash = (Get-FileHash 'assets/models/HCAM_V2_5CHAR_INT8_PT.onnx' -Algorithm SHA256).Hash
if ($modelHash -ne '15f0af5c03857ac2b049ac9f02cfe1dde2fba11ea639e191ca6453cb9a6e75cc') { throw 'Model SHA256 mismatch.' }
$tokenizerHash = (Get-FileHash 'assets/models/tokenizer.json' -Algorithm SHA256).Hash
if ($tokenizerHash -ne 'bed4387895500314ffba9608340c56069ca6df8635029535b9becdef8ce7ddf0') { throw 'Tokenizer SHA256 mismatch.' }
if (-not $SkipTests) {
  dotnet run --project tests/Dedede.Tests/Dedede.Tests.csproj -c Release -- .
  if ($LASTEXITCODE -ne 0) { throw 'Core checks failed.' }
}
dotnet restore src/Dedede.Windows/Dedede.Windows.csproj --locked-mode
if ($LASTEXITCODE -ne 0) { throw 'Locked dependency restore failed.' }
dotnet publish src/Dedede.Windows/Dedede.Windows.csproj -c Release --no-restore -o dist/Dedede-Windows-x64
if ($LASTEXITCODE -ne 0) { throw 'Publish failed.' }
Copy-Item 'docs/使用说明.html' 'dist/Dedede-Windows-x64/使用说明.html' -Force
Copy-Item 'THIRD-PARTY-NOTICES.txt' 'dist/Dedede-Windows-x64/' -Force
New-Item -ItemType Directory -Path 'dist/Dedede-Windows-x64/prerequisites' -Force | Out-Null
if (-not (Test-Path 'prerequisites/vc_redist.x64.exe')) {
  New-Item -ItemType Directory -Path prerequisites -Force | Out-Null
  Invoke-WebRequest 'https://aka.ms/vs/17/release/vc_redist.x64.exe' -OutFile 'prerequisites/vc_redist.x64.exe'
}
$signature = Get-AuthenticodeSignature 'prerequisites/vc_redist.x64.exe'
if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'Microsoft Corporation') { throw 'Microsoft VC++ installer signature verification failed.' }
Copy-Item 'prerequisites/vc_redist.x64.exe' 'dist/Dedede-Windows-x64/prerequisites/' -Force
if (Test-Path 'dist/Dedede-Windows-x64/x86') { Remove-Item 'dist/Dedede-Windows-x64/x86' -Recurse -Force }
Copy-Item 'scripts/启动纠错.cmd' 'dist/Dedede-Windows-x64/启动纠错.cmd' -Force
Copy-Item 'scripts/安装快捷方式.ps1', 'scripts/添加快捷方式.cmd' 'dist/Dedede-Windows-x64/' -Force
if (-not $SkipTests) {
  $smoke = Start-Process 'dist/Dedede-Windows-x64/Dedede.exe' -ArgumentList '--smoke-test', 'smoke-test.json' -Wait -PassThru
  if ($smoke.ExitCode -ne 0) { throw 'Windows model/OCR runtime check failed. See smoke-test.json.' }
}
Compress-Archive -Path 'dist/Dedede-Windows-x64' -DestinationPath 'dist/Dedede-Windows-x64.zip' -Force
Write-Host 'Ready: windows/dist/Dedede-Windows-x64.zip'
