#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <wchar.h>
#include <stdio.h>
static WCHAR base[MAX_PATH],logfile[MAX_PATH],command[32768],eventname[128];
static HANDLE ready,child;static HWND status;
static ULONGLONG start;
static void logline(const WCHAR *text){
 HANDLE f=CreateFileW(logfile,FILE_APPEND_DATA,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE)return;
 char buf[8192];SYSTEMTIME now;GetLocalTime(&now);WCHAR line[3500];
 swprintf(line,3500,L"%04u-%02u-%02u %02u:%02u:%02u %ls\r\n",now.wYear,now.wMonth,now.wDay,now.wHour,now.wMinute,now.wSecond,text);
 int n=WideCharToMultiByte(CP_UTF8,0,line,-1,buf,sizeof(buf),NULL,NULL);DWORD wrote;if(n>0)WriteFile(f,buf,(DWORD)n-1,&wrote,NULL);CloseHandle(f);
}
static void fail(const WCHAR *message,DWORD code){
 WCHAR system[512]=L"",body[3000];if(code)FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,NULL,code,0,system,512,NULL);
 swprintf(body,3000,L"%ls\n\n错误码：0x%08lX %ls\n\n记录：%ls\n可尝试重新安装，或从开始菜单选择兼容启动。",message,code,system,logfile);
 logline(body);MessageBoxW(NULL,body,L"纠错 Pro · 启动诊断",MB_OK|MB_ICONERROR);
}
static BOOL runtime_ok(void){
 const WCHAR *names[]={L"vcruntime140.dll",L"vcruntime140_1.dll",L"msvcp140.dll",L"msvcp140_1.dll"};
 for(unsigned i=0;i<4;i++){HMODULE m=LoadLibraryExW(names[i],NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);if(!m)return FALSE;FreeLibrary(m);}return TRUE;
}
static BOOL append_arg(const WCHAR *value){
 size_t at=wcslen(command);if(at+wcslen(value)*2+5>=32768)return FALSE;
 if(at)command[at++]=L' ';command[at++]=L'"';
 unsigned slashes=0;
 for(;*value;value++){
  if(*value==L'\\'){slashes++;continue;}
  if(*value==L'"'){for(unsigned i=0;i<slashes*2+1;i++)command[at++]=L'\\';}
  else for(unsigned i=0;i<slashes;i++)command[at++]=L'\\';
  slashes=0;command[at++]=*value;
 }
 for(unsigned i=0;i<slashes*2;i++)command[at++]=L'\\';command[at++]=L'"';command[at]=0;return TRUE;
}
static LRESULT CALLBACK windowproc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 if(m==WM_TIMER){
  if(WaitForSingleObject(ready,0)==WAIT_OBJECT_0){logline(L"Window ready");DestroyWindow(w);return 0;}
  if(WaitForSingleObject(child,0)==WAIT_OBJECT_0){DWORD code=0;GetExitCodeProcess(child,&code);KillTimer(w,1);fail(L"程序在窗口显示前已退出。",code);DestroyWindow(w);return 0;}
  if(GetTickCount64()-start>8000&&!IsWindowVisible(w))ShowWindow(w,SW_SHOWNOACTIVATE);
  if(GetTickCount64()-start>30000)SetWindowTextW(status,L"首次启动较慢，请稍候。\n关闭此提示不会关闭正在启动的程序。");return 0;
 }
 if(m==WM_DESTROY){PostQuitMessage(0);return 0;}return DefWindowProcW(w,m,wp,lp);
}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE previous,PWSTR raw,int show){
 (void)previous;(void)raw;(void)show;
 if(!GetModuleFileNameW(NULL,base,MAX_PATH))return 1;WCHAR *last=wcsrchr(base,L'\\');if(!last)return 1;*last=0;
 WCHAR local[MAX_PATH];if(FAILED(SHGetFolderPathW(NULL,CSIDL_LOCAL_APPDATA,NULL,0,local)))GetTempPathW(MAX_PATH,local);
 if(wcslen(local)>MAX_PATH-40)return 1;swprintf(logfile,MAX_PATH,L"%ls\\Dedede",local);CreateDirectoryW(logfile,NULL);wcscat(logfile,L"\\launcher.log");
 WIN32_FILE_ATTRIBUTE_DATA info;if(GetFileAttributesExW(logfile,GetFileExInfoStandard,&info)&&info.nFileSizeLow>2000000){WCHAR old[MAX_PATH];swprintf(old,MAX_PATH,L"%ls.previous",logfile);MoveFileExW(logfile,old,MOVEFILE_REPLACE_EXISTING);}
 int argc=0;LPWSTR *argv=CommandLineToArgvW(GetCommandLineW(),&argc);BOOL verification=FALSE;
 for(int i=1;i<argc;i++)if(!wcscmp(argv[i],L"--smoke-test")||!wcscmp(argv[i],L"--render-preview"))verification=TRUE;
 if(argc==2&&!wcscmp(argv[1],L"--check-runtime")){LocalFree(argv);return runtime_ok()?0:12;}
 logline(L"Launcher started");
 const WCHAR *files[]={L"Dedede.exe",L"Dedede.dll",L"Dedede.runtimeconfig.json",L"coreclr.dll",L"hostfxr.dll",L"hostpolicy.dll",L"PresentationFramework.dll",L"assets\\models\\HCAM_V2_5CHAR_INT8_PT.onnx",L"assets\\models\\tokenizer.json"};
 for(unsigned i=0;i<sizeof(files)/sizeof(files[0]);i++){WCHAR p[MAX_PATH];if(wcslen(base)+wcslen(files[i])+2>=MAX_PATH){fail(L"安装路径过长，请使用默认安装位置。",0);return 1;}swprintf(p,MAX_PATH,L"%ls\\%ls",base,files[i]);if(GetFileAttributesW(p)==INVALID_FILE_ATTRIBUTES){fail(p,GetLastError());return 1;}}
 if(!runtime_ok()){fail(L"微软 VC++ x64 运行库缺失或无法加载。请运行安装程序修复，或运行安装目录内 prerequisites\\vc_redist.x64.exe。",0);return 12;}
 WCHAR exe[MAX_PATH];swprintf(exe,MAX_PATH,L"%ls\\Dedede.exe",base);append_arg(exe);
 swprintf(eventname,128,L"Local\\DededeReady-%lu-%llu",GetCurrentProcessId(),GetTickCount64());ready=CreateEventW(NULL,TRUE,FALSE,eventname);if(!ready){fail(L"无法创建启动信号。",GetLastError());return 1;}
 append_arg(L"--startup-ready");append_arg(eventname);for(int i=1;i<argc;i++)if(!append_arg(argv[i])){fail(L"启动参数过长。",0);return 1;}LocalFree(argv);
 STARTUPINFOW si={0};PROCESS_INFORMATION pi={0};si.cb=sizeof(si);
 if(!CreateProcessW(exe,command,NULL,NULL,FALSE,CREATE_NO_WINDOW,NULL,base,&si,&pi)){fail(L"无法启动程序。",GetLastError());CloseHandle(ready);return 1;}
 child=pi.hProcess;CloseHandle(pi.hThread);start=GetTickCount64();
 if(verification){DWORD code=1;WaitForSingleObject(child,INFINITE);GetExitCodeProcess(child,&code);CloseHandle(child);CloseHandle(ready);return (int)code;}
 WNDCLASSW wc={0};wc.lpfnWndProc=windowproc;wc.hInstance=instance;wc.lpszClassName=L"DededeLauncher";wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);wc.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(1));RegisterClassW(&wc);
 HWND w=CreateWindowW(wc.lpszClassName,L"纠错 Pro",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,(GetSystemMetrics(SM_CXSCREEN)-470)/2,(GetSystemMetrics(SM_CYSCREEN)-150)/2,470,150,NULL,NULL,instance,NULL);
 if(w){status=CreateWindowW(L"STATIC",L"正在启动，请稍候…",WS_CHILD|WS_VISIBLE,24,30,420,70,w,NULL,instance,NULL);SendMessageW(status,WM_SETFONT,(WPARAM)GetStockObject(DEFAULT_GUI_FONT),TRUE);SetTimer(w,1,100,NULL);MSG msg;while(GetMessageW(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}}
 CloseHandle(child);CloseHandle(ready);return 0;
}
