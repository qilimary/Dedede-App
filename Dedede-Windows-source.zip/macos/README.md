# 纠错 Pro · Mac 1.2

适用于 macOS 14 或更新系统。Apple 芯片下载 AppleSilicon；Intel 芯片下载 Intel。打开 DMG，将“纠错 Pro”拖到 Applications 后启动。

此构建默认采用本机签名，尚无 Apple Developer ID 签名与公证。系统可能阻止首次运行；核对下载来源后，可按系统“隐私与安全性”中的“仍要打开”操作。构建脚本不会关闭安全保护或清除隔离标记。正式对外发布建议配置 Developer ID 与公证。

功能：专业与极速纠错、温度与五字阈值、置信度、逐条采纳/还原/手动编辑、修订标注与全文对比、序号跳转、导入与拖放、批量处理、TXT/Markdown/DOCX/HTML/CSV 导出、查找替换、标点整理、成稿编辑、历史、保护词与替换词、主题、独立正文/界面字号、自定义开始纠错快捷键、撤销与重做、首行缩进、原文与结果恢复、同步滚动、菜单栏与迷你窗口。

OCR 使用 macOS Vision，在本机处理，支持图片、剪贴板与截图。截图权限由系统管理；扫描型 PDF 请先另存为图片。不承诺复杂排版、艺术字与手写字准确识别。

默认 ⌘ Enter 开始，可在偏好设置修改；Esc 停止；⌘ O 导入；⌘ S 导出；⌘ F 查找；⌘ ⇧ C 复制；⌘ , 设置。全局 ⌘ ⌥ D 粘贴文字，⌘ ⌥ O 识别图片；若与其他软件冲突，可关闭。

数据目录：~/Library/Application Support/Dedede。启动异常写入 startup.log。正文不上传，程序不自动联网检查或更新。关闭至菜单栏可在设置中启用；真正退出可从菜单栏选择退出。

## 构建

在仓库根目录解压 Dedede-Windows-source.zip，保留 windows 与 macos 两个目录；Mac 共用 windows/src/Dedede.Core 和模型资源。安装 .NET 10 SDK（global.json 指定补丁系列）及 Xcode 命令行工具，执行 bash macos/build.sh。构建时下载模型，安装后的程序离线运行。

构建脚本生成独立架构 DMG，自带 .NET；不要求用户安装 Python、.NET 或额外 OCR 模型。需要签名时设置 DEDEDE_SIGN_IDENTITY；需要公证时设置本机钥匙串已有的 DEDEDE_NOTARY_PROFILE。证书、密码和钥匙串凭据不放入源码包。

当前交付已完成 Linux 环境下的编译、真实推理和界面集成测试；Swift 系统组件与原生 DMG 安装需由 GitHub macOS runner 构建验证。Apple 芯片与 Intel 两个原生构建都设有推理和 OCR 检查。未来系统版本仍需验证，不能承诺永久零维护。

1.2 同步了 Windows 的两栏界面、后台预热与相同输入缓存。详细改动和验证边界见 windows/README.md 与 windows/docs/桌面版1.2验证.md。
