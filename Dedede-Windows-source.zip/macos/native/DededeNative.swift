import Foundation
import AppKit
import Vision
import ImageIO
import UniformTypeIdentifiers
import Carbon

func fail(_ text: String, _ code: Int32 = 1) -> Never {
    FileHandle.standardError.write((text + "\n").data(using: .utf8)!)
    exit(code)
}
func image(_ source: CGImageSource) -> CGImage {
    guard let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
          let width = properties[kCGImagePropertyPixelWidth] as? Int,
          let height = properties[kCGImagePropertyPixelHeight] as? Int,
          width > 0, height > 0, width <= 20000, height <= 20000, width * height <= 20000000 else {
        fail("图片尺寸过大或内容无效，请使用不超过 2000 万像素的图片。")
    }
    guard let result = CGImageSourceCreateImageAtIndex(source, 0, nil) else { fail("无法读取图片。") }
    return result
}
func recognize(_ path: String) throws {
    let url = URL(fileURLWithPath: path)
    let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
    guard size > 0 && size <= 64 * 1024 * 1024 else { fail("图片文件上限为 64 MiB。") }
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { fail("不支持此图片格式。") }
    let request = VNRecognizeTextRequest()
    request.recognitionLevel = .accurate
    request.usesLanguageCorrection = true
    request.automaticallyDetectsLanguage = true
    let supported = try request.supportedRecognitionLanguages()
    request.recognitionLanguages = ["zh-Hans", "zh-Hant", "en-US"].filter { supported.contains($0) }
    try VNImageRequestHandler(cgImage: image(source), options: [:]).perform([request])
    print((request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n"))
}
func clipboard(_ path: String) {
    let pasteboard = NSPasteboard.general
    guard let data = pasteboard.data(forType: .png) ?? pasteboard.data(forType: .tiff), data.count <= 64 * 1024 * 1024,
          let source = CGImageSourceCreateWithData(data as CFData, nil) else { fail("剪贴板没有可识别的图片。") }
    let cg = image(source)
    guard let destination = CGImageDestinationCreateWithURL(URL(fileURLWithPath: path) as CFURL, UTType.png.identifier as CFString, 1, nil) else { fail("无法保存临时图片。") }
    CGImageDestinationAddImage(destination, cg, nil)
    guard CGImageDestinationFinalize(destination) else { fail("无法写入临时图片。") }
}
func screenshot(_ path: String) throws {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: "/usr/sbin/screencapture")
    process.arguments = ["-i", "-s", "-x", path]
    try process.run(); process.waitUntilExit()
    guard process.terminationStatus == 0 && FileManager.default.fileExists(atPath: path) else {
        fail("截图已取消或未获系统权限。请在系统设置的隐私与安全性中允许屏幕录制。", 20)
    }
}
func hotkeys() {
    var type = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
    let handler: EventHandlerUPP = { _, event, _ in
        guard let event = event else { return OSStatus(eventNotHandledErr) }
        var key = EventHotKeyID()
        let result = GetEventParameter(event, EventParamName(kEventParamDirectObject), EventParamType(typeEventHotKeyID), nil, ByteCount(MemoryLayout<EventHotKeyID>.size), nil, &key)
        if result == noErr { print(key.id == 1 ? "text" : "image"); fflush(stdout) }
        return noErr
    }
    guard InstallEventHandler(GetApplicationEventTarget(), handler, 1, &type, nil, nil) == noErr else { fail("无法注册全局快捷键。") }
    var first: EventHotKeyRef?; var second: EventHotKeyRef?
    let modifiers = UInt32(cmdKey | optionKey)
    guard RegisterEventHotKey(2, modifiers, EventHotKeyID(signature: 0x44444445, id: 1), GetApplicationEventTarget(), 0, &first) == noErr else { fail("⌘ ⌥ D 已被其他程序占用。") }
    guard RegisterEventHotKey(31, modifiers, EventHotKeyID(signature: 0x44444445, id: 2), GetApplicationEventTarget(), 0, &second) == noErr else { if let first = first { UnregisterEventHotKey(first) }; fail("⌘ ⌥ O 已被其他程序占用。") }
    RunApplicationEventLoop()
}
let arguments = CommandLine.arguments
 do {
    guard arguments.count >= 2 else { fail("缺少操作参数。") }
    if arguments[1] == "hotkeys" { hotkeys() }
    else {
        guard arguments.count == 3 else { fail("缺少文件路径。") }
        switch arguments[1] {
        case "ocr": try recognize(arguments[2])
        case "clipboard": clipboard(arguments[2])
        case "screenshot": try screenshot(arguments[2])
        default: fail("未知操作。")
        }
    }
 } catch { fail(error.localizedDescription) }
