using Avalonia;
using Avalonia.Threading;
using Dedede.Core;
using System.IO.Pipes;
using System.Text;
using System.Text.Json;

namespace Dedede.Mac;
public static class Program
{
    public static string Assets=>Path.Combine(AppContext.BaseDirectory,"assets");
    private static readonly string Key="DededeMac-"+Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Encoding.UTF8.GetBytes(Environment.UserName)))[..16];
    private static readonly CancellationTokenSource Shutdown=new();
    [STAThread] public static int Main(string[] args)
    {
        try
        {
            if(args.Contains("--smoke-test")){SmokeAsync(args.Last()).GetAwaiter().GetResult();return 0;}
            using var mutex=new Mutex(true,Key,out bool owner);
            if(!owner){using var client=new NamedPipeClientStream(".",Key,PipeDirection.Out);client.Connect(3000);using var writer=new StreamWriter(client);writer.WriteLine(JsonSerializer.Serialize(args));return 0;}
            try{return BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);}finally{Shutdown.Cancel();mutex.ReleaseMutex();}
        }
        catch(Exception ex){Log(ex.ToString());if(OperatingSystem.IsMacOS()){try{using var p=System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("/usr/bin/osascript"){ArgumentList={"-e","display alert \"纠错 Pro 启动失败\" message \"请查看 ~/Library/Application Support/Dedede/startup.log 中的记录。\" as critical"}});p?.WaitForExit();}catch{}}return 1;}
    }
    public static AppBuilder BuildAvaloniaApp()=>AppBuilder.Configure<App>().UsePlatformDetect().LogToTrace();
    public static void Log(string text){try{var s=new LocalStore();var path=Path.Combine(s.Root,"startup.log");if(File.Exists(path)&&new FileInfo(path).Length>2_000_000)File.Move(path,path+".previous",true);File.AppendAllText(path,DateTimeOffset.Now.ToString("O")+" "+text+Environment.NewLine);}catch{}}
    internal static void Listen(MainWindow window)=>_=Task.Run(async()=>
    {
        while(!Shutdown.IsCancellationRequested)
        {
            try{using var server=new NamedPipeServerStream(Key,PipeDirection.In,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous|PipeOptions.CurrentUserOnly);await server.WaitForConnectionAsync(Shutdown.Token);using var reader=new StreamReader(server);string? line=await reader.ReadLineAsync(Shutdown.Token);if(line?.Length>100_000)continue;var paths=JsonSerializer.Deserialize<string[]>(line??"[]")??[];Dispatcher.UIThread.Post(async()=>{window.RestoreWindow();await window.ImportPathsAsync(paths.Where(File.Exists).ToArray());});}
            catch(OperationCanceledException){break;}catch(Exception ex){Log(ex.Message);try{await Task.Delay(500,Shutdown.Token);}catch(OperationCanceledException){break;}}
        }
    });
    private static async Task SmokeAsync(string output)
    {
        try{using var engine=new CorrectionEngine(Assets);var r=await engine.CheckAsync("他认真得检查了这份报告，又把遗漏地细节补充完整。",new());if(r.ModelCalls==0||!r.Corrected.Contains("遗漏的"))throw new Exception("Model smoke failed");string ocr=await MacServices.OcrAsync(Path.Combine(Assets,"ocr-test.png"),CancellationToken.None);if(!ocr.Contains("DEDEDE",StringComparison.OrdinalIgnoreCase))throw new Exception("OCR smoke failed");LocalStore.AtomicWrite(output,JsonSerializer.Serialize(new{passed=true,r.Corrected,r.ModelCalls,ocr},LocalStore.JsonOptions));}
        catch(Exception ex){LocalStore.AtomicWrite(output,JsonSerializer.Serialize(new{passed=false,error=ex.ToString()},LocalStore.JsonOptions));throw;}
    }
}
