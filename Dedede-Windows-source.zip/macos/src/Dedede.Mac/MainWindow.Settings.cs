using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Input.Platform;
using Avalonia.Media;
using Avalonia.Styling;
using Dedede.Core;
using System.Globalization;

namespace Dedede.Mac;
public partial class MainWindow
{
    private static readonly string[] Themes=["system","light","dark"],Accents=["blue","green","purple","apricot"];
    private void LoadSettings()
    {
        mode.SelectedIndex=settings.Check.Professional?0:1;temperature.Text=settings.Check.Temperature.ToString(CultureInfo.InvariantCulture);for(int i=0;i<5;i++)thresholds[i].Text=settings.Check.Thresholds[i].ToString("F2",CultureInfo.InvariantCulture);
        theme.SelectedIndex=Math.Max(0,Array.IndexOf(Themes,settings.Theme));accent.SelectedIndex=Math.Max(0,Array.IndexOf(Accents,settings.Accent));font.Value=Math.Clamp(settings.FontSize,14,30);
        sync.IsChecked=settings.SyncScroll;traySetting.IsChecked=settings.CloseToTray;hotkeySetting.IsChecked=settings.Hotkeys;uiFont.Value=Math.Clamp(settings.UiFontSize,12,18);SetShortcut(settings.CheckShortcut);threads.Text=settings.Check.Threads.ToString();keepHistory.IsChecked=settings.KeepHistory;saveDraft.IsChecked=settings.SaveDraft;
    }
    private void SaveSettings()
    {
        try{var c=ReadConfig();c.Threads=int.Parse(threads.Text??"");c.Dictionary=c.Grammar=c.Protection=c.DenseReview=true;c.Validate();settings.Check=c;settings.Theme=Themes[Math.Max(0,theme.SelectedIndex)];settings.Accent=Accents[Math.Max(0,accent.SelectedIndex)];settings.FontSize=font.Value;settings.UiFontSize=uiFont.Value;settings.CheckShortcut=shortcut.Tag as string??CheckShortcut.Default;settings.SyncScroll=sync.IsChecked==true;settings.CloseToTray=traySetting.IsChecked==true;settings.Hotkeys=hotkeySetting.IsChecked==true;settings.KeepHistory=keepHistory.IsChecked==true;settings.SaveDraft=saveDraft.IsChecked==true;if(!settings.SaveDraft){draftTimer.Stop();store.ClearWorkspace();}store.Save("settings.json",settings);ApplyAppearance();ConfigureDesktop();ScheduleSave();ScheduleWarmup();Status("设置已保存。");}catch(Exception ex){ShowError(ex);}
    }
    private void ApplyAppearance()
    {
        Application.Current!.RequestedThemeVariant=settings.Theme=="dark"?ThemeVariant.Dark:settings.Theme=="light"?ThemeVariant.Light:ThemeVariant.Default;
        FontSize=settings.UiFontSize;Application.Current!.Resources["UiFontSize"]=settings.UiFontSize;ApplyTypography();check.Content="开始纠错  "+CheckShortcut.Format(settings.CheckShortcut,true);help.Text=DesktopHelp.Text(CheckShortcut.Format(settings.CheckShortcut,true),true);
        source.FontSize=settings.FontSize;source.LineHeight=settings.FontSize*1.85;foreach(var t in new[]{output,before,after}){t.FontSize=settings.FontSize;t.LineHeight=settings.FontSize*1.85;}ApplyPalette();
    }
    private void ApplyPalette()
    {
        bool dark=ActualThemeVariant==ThemeVariant.Dark;var r=Application.Current!.Resources;r["Canvas"]=Brush.Parse(dark?"#151C27":"#F3F6FA");r["Panel"]=Brush.Parse(dark?"#202A39":"#FFFFFF");r["Line"]=Brush.Parse(dark?"#354359":"#DEE5EF");r["Ink"]=Brush.Parse(dark?"#E5ECF5":"#263449");r["Soft"]=Brush.Parse(dark?"#273A59":"#EAF0FD");r["Muted"]=Brush.Parse(dark?"#B1BED0":"#65758A");r["Accent"]=Brush.Parse(settings.Accent switch{"green"=>"#277E64","purple"=>"#7955B7","apricot"=>"#A76636",_=>"#326BDB"});Array.Fill(dirty,true);RenderVisible();
    }
    private async Task ResetSettingsAsync(){if(await Dialogs.Confirm(this,"恢复默认设置？自定义词库会保留。")){settings=new(){CustomRules=settings.CustomRules};LoadSettings();SaveSettings();}}
    private void TrySaveDraft(){try{if(settings.SaveDraft)store.SaveWorkspace(new(){Source=source.Text??"",Result=result,View=documents.SelectedIndex});}catch(Exception ex){Status("草稿保存失败："+ex.Message);}}
    private async Task ClearDraftAsync(){if(await Dialogs.Confirm(this,"清空本机草稿与当前输入？")){source.Clear();ClearResult();draftTimer.Stop();store.ClearWorkspace();}}
    private async Task CopyDiagnosticsAsync(){if(Clipboard!=null)await Clipboard.SetTextAsync($"纠错 Pro Mac 1.2.1\n{System.Runtime.InteropServices.RuntimeInformation.OSDescription}\n{System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture}\n.NET {Environment.Version}\nData: {store.Root}\nModel: {File.Exists(Path.Combine(Program.Assets,"models","HCAM_V2_5CHAR_INT8_PT.onnx"))}\nNative helper: {File.Exists(MacServices.Helper)}");Status("已复制诊断信息，不含正文。");}
    private void ConfigureDesktop()
    {
        if(preview||App.Testing)return;
        if(!settings.CloseToTray&&!settings.Hotkeys){tray?.Dispose();tray=null;TrayIcon.SetIcons(Application.Current!,new TrayIcons());}
        if(tray==null&&(settings.CloseToTray||settings.Hotkeys))
        {
            var menu=new NativeMenu();void Item(string text,Action action){var i=new NativeMenuItem(text);i.Click+=(_,_)=>action();menu.Add(i);}Item("打开工作台",RestoreWindow);Item("迷你窗口",OpenMini);Item("退出纠错 Pro",()=>Run(QuitAsync));
            tray=new TrayIcon{Icon=Icon,ToolTipText="纠错 Pro",Menu=menu,IsVisible=true};tray.Clicked+=(_,_)=>RestoreWindow();TrayIcon.SetIcons(Application.Current!,new TrayIcons{tray});
        }
        hotkeys?.Dispose();hotkeys=null;if(settings.Hotkeys)hotkeys=new MacServices.Hotkeys(kind=>Run(kind=="text"?PasteAsync:ClipboardOcrAsync),Status);
    }
    private void OpenMini()
    {
        if(mini!=null){mini.Show();mini.Activate();return;}
        mini=new MiniWindow(engine,()=>settings.Check.Snapshot(),()=>new Dictionary<string,string>(settings.CustomRules),async text=>{RestoreWindow();if(!Busy&&await ConfirmReplaceAsync())SetSource(text);});mini.Closed+=(_,_)=>mini=null;mini.Show();
    }
    private void OpenDraft(){if(result==null){Status("请先完成一次检查。");return;}var d=new DraftWindow(result.Corrected);drafts.Add(d);d.Closed+=(_,_)=>drafts.Remove(d);d.Show();}
    public async Task QuitAsync()
    {
        if(Quitting||quitInProgress)return;quitInProgress=true;
        try
        {
            foreach(var d in drafts.ToArray())if(!await d.CanCloseAsync())return;
            Quitting=true;work?.Cancel();lifetime.Cancel();warmTimer.Stop();mini?.Cancel();hotkeys?.Dispose();draftTimer.Stop();historyTimer.Stop();idleTimer.Stop();TrySaveDraft();SaveHistoryState();tray?.Dispose();foreach(var d in drafts.ToArray())d.ForceClose();mini?.Close();
            await Task.Run(engine.Dispose);Close();if(Application.Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)desktop.Shutdown();
        }
        finally{quitInProgress=false;}
    }
}
