using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Controls.Documents;
using Avalonia.Input;
using Avalonia.Input.Platform;
using Avalonia.Interactivity;
using Avalonia.Media;
using Avalonia.Styling;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using Dedede.Core;
using System.Collections.ObjectModel;
using System.Globalization;

namespace Dedede.Mac;
public partial class MainWindow : Window
{
    private readonly LocalStore store;
    private AppSettings settings;
    private readonly CorrectionEngine engine=new(Program.Assets);
    private CheckResult? result;
    private CancellationTokenSource? work;
    private readonly DispatcherTimer draftTimer=new(){Interval=TimeSpan.FromMilliseconds(900)},historyTimer=new(){Interval=TimeSpan.FromMilliseconds(600)},idleTimer=new(){Interval=TimeSpan.FromMinutes(1)};
    private readonly ObservableCollection<BatchItem> batch=[];
    private readonly List<DraftWindow> drafts=[];
    private readonly bool preview;
    private bool initialized,syncing,focus,quitInProgress,checkingSource;
    private readonly bool[] dirty=[true,true];
    private readonly RevisionUndo revisions=new();
    private readonly CancellationTokenSource lifetime=new();
    private readonly DispatcherTimer warmTimer=new(){Interval=TimeSpan.FromMilliseconds(450)};
    private TrayIcon? tray;private MacServices.Hotkeys? hotkeys;private MiniWindow? mini;
    private string? outputFolder,activeSnapshot;
    public bool Quitting{get;private set;}
    private bool Busy=>work!=null;
    public MainWindow():this(new LocalStore()){}
    public MainWindow(LocalStore store,bool preview=false)
    {
        this.store=store;this.preview=preview;settings=store.Load("settings.json",()=>new AppSettings());settings.Check??=new();settings.CustomRules??=[];try{settings.Check.Validate();}catch{settings.Check=new();}
        settings.Check.Dictionary=settings.Check.Grammar=settings.Check.Protection=settings.Check.DenseReview=true;settings.FontSize=Math.Clamp(settings.FontSize,14,30);settings.UiFontSize=Math.Clamp(settings.UiFontSize,12,18);if(!CheckShortcut.Valid(settings.CheckShortcut))settings.CheckShortcut=CheckShortcut.Default;
        if(preview){settings.KeepHistory=false;settings.SaveDraft=false;settings.Hotkeys=false;settings.CloseToTray=false;}
        if(App.Testing)FontFamily=new FontFamily("Noto Sans CJK SC");
        Title="纠错 Pro · Mac";Width=1400;Height=920;MinWidth=1040;MinHeight=720;WindowStartupLocation=WindowStartupLocation.CenterScreen;
        if(File.Exists(Path.Combine(Program.Assets,"app.ico")))Icon=new WindowIcon(Path.Combine(Program.Assets,"app.ico"));
        BuildLayout();batchList.ItemsSource=batch;LoadSettings();var saved=settings.SaveDraft?store.LoadWorkspace():new WorkspaceState();source.Text=saved.Source;count.Text=$"{saved.Source.Length:N0} 字符";result=saved.Result;documents.SelectedIndex=saved.View;initialized=true;ApplyAppearance();RefreshHistory();RefreshRules();if(result!=null)RenderResult();
        source.PropertyChanged+=(_,e)=>{if(e.Property!=TextBox.TextProperty)return;count.Text=$"{source.Text?.Length??0:N0} 字符";stale.IsVisible=result!=null&&result.Original!=source.Text;if(checkingSource&&source.Text!=activeSnapshot)work?.Cancel();ScheduleSave();ScheduleWarmup();};
        check.Click+=(_,_)=>Run(CheckAsync);stop.Click+=(_,_)=>work?.Cancel();
        mode.SelectionChanged+=(_,_)=>{temperature.IsEnabled=mode.SelectedIndex==0;foreach(var t in thresholds)t.IsEnabled=mode.SelectedIndex==0;settings.Check.Professional=mode.SelectedIndex==0;ScheduleWarmup();};
        documents.SelectionChanged+=(_,e)=>{if(e.Source==documents){RenderVisible();ScheduleSave();}};ruleSearch.TextChanged+=(_,_)=>RefreshRules();
        draftTimer.Tick+=(_,_)=>{draftTimer.Stop();TrySaveDraft();};historyTimer.Tick+=(_,_)=>{historyTimer.Stop();SaveHistoryState();};
        idleTimer.Tick+=(_,_)=>{if(!IsVisible||WindowState==WindowState.Minimized)Run(()=>engine.ReleaseIfIdleAsync(TimeSpan.FromMinutes(10)));};idleTimer.Start();
        warmTimer.Tick+=async(_,_)=>{warmTimer.Stop();try{await engine.PrepareAsync(settings.Check,lifetime.Token);}catch(OperationCanceledException){}catch(Exception ex){Program.Log("Preload: "+ex.Message);}};
        DragDrop.SetAllowDrop(this,true);AddHandler(DragDrop.DragOverEvent,(_,e)=>e.DragEffects=e.DataTransfer.Contains(DataFormat.File)?DragDropEffects.Copy:DragDropEffects.None);
        AddHandler(DragDrop.DropEvent,(_,e)=>{var paths=e.DataTransfer.TryGetFiles()?.Select(x=>x.TryGetLocalPath()).OfType<string>().ToArray()??[];Run(()=>ImportPathsAsync(paths));});
        AddHandler(KeyDownEvent,OnKey,RoutingStrategies.Tunnel);
        Closing+=(_,e)=>{if(Quitting)return;e.Cancel=true;if(settings.CloseToTray&&tray!=null)Hide();else Run(QuitAsync);};
        Opened+=(_,_)=>{if(!preview&&!App.Testing){ConfigureDesktop();ScheduleWarmup();}};
        pages.SelectionChanged+=(_,e)=>{if(e.Source==pages)ApplyTypography();};
        ActualThemeVariantChanged+=(_,_)=>{if(initialized)ApplyPalette();};
        var menu=new NativeMenu();var file=new NativeMenuItem("文件"){Menu=new NativeMenu()};
        var open=new NativeMenuItem("导入…"){Gesture=new(Key.O,KeyModifiers.Meta)};open.Click+=(_,_)=>Run(PickImportAsync);file.Menu.Add(open);
        var save=new NativeMenuItem("导出…"){Gesture=new(Key.S,KeyModifiers.Meta)};save.Click+=(_,_)=>Run(ExportAsync);file.Menu.Add(save);menu.Add(file);NativeMenu.SetMenu(this,menu);
    }
    private async void Run(Func<Task> action){try{await action();}catch(OperationCanceledException){Status("操作已取消。");}catch(Exception ex){ShowError(ex);}}
    public void ShowError(Exception ex){Status(ex.Message);Program.Log(ex.ToString());if(!App.Testing)_=Dialogs.Message(this,ex.Message);}
    private void Status(string text)=>status.Text=text;
    public void RestoreWindow(){Show();if(WindowState==WindowState.Minimized)WindowState=WindowState.Normal;Activate();}
    public void ShowPage(int index){RestoreWindow();pages.SelectedIndex=index;}
    private CheckSettings ReadConfig()
    {
        var c=settings.Check.Snapshot();c.Professional=mode.SelectedIndex==0;
        if(c.Professional){c.Temperature=float.Parse(temperature.Text??"",CultureInfo.InvariantCulture);c.Thresholds=thresholds.Select(t=>float.Parse(t.Text??"",CultureInfo.InvariantCulture)).ToArray();}c.Validate();settings.Check=c;return c.Snapshot();
    }
    private void SetBusy(bool busy){check.IsEnabled=!busy;stop.IsEnabled=busy;progress.IsVisible=busy;progress.IsIndeterminate=busy;if(!busy)progress.Value=0;}
    private async Task CheckAsync()
    {
        if(Busy){Status("请先停止当前任务。");return;}string text=source.Text??"";if(string.IsNullOrWhiteSpace(text))return;
        var config=ReadConfig();store.Save("settings.json",settings);using var ct=new CancellationTokenSource();work=ct;activeSnapshot=text;checkingSource=true;SetBusy(true);
        // Coalesce display updates; inference and cancellation retain their original granularity.
        CheckProgress? latest=null;var progressTimer=new DispatcherTimer{Interval=TimeSpan.FromMilliseconds(100)};
        progressTimer.Tick+=(_,_)=>{var p=Interlocked.Exchange(ref latest,null);if(p!=null){progress.IsIndeterminate=false;progress.Value=p.Total==0?0:p.Completed*100.0/p.Total;Status($"正在检查 · {p.Completed}/{p.Total} 段 · {p.Changes} 条建议");}};progressTimer.Start();
        try
        {
            var r=await engine.CheckAsync(text,config,settings.CustomRules,new CallbackProgress(p=>Interlocked.Exchange(ref latest,p)),ct.Token);
            if(ct.IsCancellationRequested||text!=source.Text)return;SaveHistoryState();result=r;revisions.Clear();if(settings.KeepHistory)store.AddHistory(r);RenderResult();RefreshHistory();Status($"检查完成 · {r.Changes.Count} 条建议 · {r.ElapsedMs/1000.0:F2} 秒");
        }
        catch(OperationCanceledException){Status("检查已停止，已有结果仍可查看。");}
        finally{progressTimer.Stop();activeSnapshot=null;checkingSource=false;work=null;SetBusy(false);}
    }
    private void SetSource(string text)
    {
        if(text.Length>300_000)throw new InvalidDataException("单篇文本最多 30 万字。");source.SelectAll();source.SelectedText=text;source.SelectionStart=source.SelectionEnd=0;pages.SelectedIndex=0;documents.SelectedIndex=0;source.Focus();
    }
    private Task<bool> ConfirmReplaceAsync()=>string.IsNullOrEmpty(source.Text)?Task.FromResult(true):Dialogs.Confirm(this,"用新内容替换当前输入？可用 ⌘ Z 撤销原文编辑。");
    private void RenderResult(){if(result!=null)for(int i=0;i<result.Changes.Count;i++)result.Changes[i].Number=i+1;undoRevision.IsEnabled=revisions.CanUndo;redoRevision.IsEnabled=revisions.CanRedo;ScheduleSave();Array.Fill(dirty,true);RenderVisible();RefreshSuggestions();stale.IsVisible=result!=null&&result.Original!=source.Text;historyTimer.Stop();if(settings.KeepHistory)historyTimer.Start();}
    private void RenderVisible()
    {
        if(result==null)return;int tab=documents.SelectedIndex;if(tab<0||!dirty[tab])return;
        if(tab==0)RenderText(output,"inline");else {RenderText(before,"before");RenderText(after,"after");}dirty[tab]=false;
    }
    private readonly Dictionary<SelectableTextBlock,List<(int Start,int End,Change Change)>> marks=[];
    private void RenderText(SelectableTextBlock block,string kind)
    {
        if(!marks.ContainsKey(block))
        {
            block.PointerMoved+=(_,e)=>{var c=Hit(block,e.GetPosition(block));ToolTip.SetTip(block,c==null?null:c.Label+"\n"+c.Detail);block.Cursor=new Cursor(c==null?StandardCursorType.Ibeam:StandardCursorType.Hand);};
            Point pressed=default;block.PointerPressed+=(_,e)=>pressed=e.GetPosition(block);
            block.PointerReleased+=(_,e)=>{var p=e.GetPosition(block);if(Math.Abs(p.X-pressed.X)<5&&Math.Abs(p.Y-pressed.Y)<5&&Hit(block,p) is {} c)SelectChange(c);};
        }
        var ranges=new List<(int,int,Change)>();marks[block]=ranges;block.Inlines!.Clear();if(result==null)return;int at=0,offset=0;
        foreach(var c in result.Changes.OrderBy(c=>c.Start))
        {
            Plain(result.Original[at..c.Start]);
            if(kind=="before")Mark(c.Original,c,false,false);
            else if(!c.Accepted)Mark(c.Original,c,false,false,true);
            else{if(kind=="inline")Mark(c.Original,c,false,true);Mark(c.Replacement,c,true,false);}
            if(kind=="inline"){Note(c.NumberLabel,c,true);if(c.Confidence.HasValue)Note($"（{(c.ManuallyEdited?"原建议":"")}置信度 {c.Confidence.Value*100:F1}%）",c,false);}
            at=c.End;
        }
        Plain(result.Original[at..]);
        void Plain(string text){block.Inlines.Add(new Run(text));offset+=text.Length;}
        void Note(string text,Change c,bool number){var run=new Run(text){FontSize=Math.Max(11,settings.FontSize*.68),Foreground=Brush.Parse(number?(ActualThemeVariant==ThemeVariant.Dark?"#92B7FF":"#326BDB"):(ActualThemeVariant==ThemeVariant.Dark?"#B1BED0":"#758399"))};ranges.Add((offset,offset+text.Length,c));offset+=text.Length;block.Inlines.Add(run);}
        void Mark(string text,Change c,bool good,bool strike,bool restored=false)
        {
            if(text.Length==0)return;bool dark=ActualThemeVariant==ThemeVariant.Dark;
            var run=new Run(text){Background=restored?Brushes.Transparent:Brush.Parse(good?(dark?"#24543F":"#DFF3E6"):(dark?"#63363D":"#FCE2E5")),Foreground=Brush.Parse(dark?"#F0F5FA":"#263449")};
            if(strike)run.TextDecorations=TextDecorations.Strikethrough;
            ranges.Add((offset,offset+text.Length,c));offset+=text.Length;block.Inlines.Add(run);
        }
    }
    private Change? Hit(SelectableTextBlock block,Point point)
    {
        var hit=block.TextLayout.HitTestPoint(point);if(!hit.IsInside)return null;
        int offset=hit.TextPosition;return marks[block].FirstOrDefault(r=>offset>=r.Start&&offset<r.End).Change;
    }
    private void RefreshSuggestions()
    {
        if(!initialized)return;var selected=suggestions.SelectedItem;var changes=result?.Changes??[];suggestions.ItemsSource=changes.Where(c=>filter.SelectedIndex==0||!c.Accepted).ToList();summary.Text=$"{changes.Count} 处修改"+(changes.Any(c=>!c.Accepted)?$" · 已还原 {changes.Count(c=>!c.Accepted)} 处":"");suggestions.SelectedItem=selected;
    }
    private void SelectChange(Change c){filter.SelectedIndex=0;suggestions.SelectedItem=c;suggestions.ScrollIntoView(c);SelectSuggestion();}
    private void SelectSuggestion()
    {
        if(suggestions.SelectedItem is not Change c){changeTools.IsVisible=false;return;}changeTools.IsVisible=true;position.Text=$"第 {c.Start+1} 字"+(c.Kind!="模型"&&!string.IsNullOrWhiteSpace(c.Explanation)?" · "+c.Explanation:"");replacement.Text=c.Replacement;toggleSuggestion.Content=c.Accepted?"还原为原字":"恢复纠正";
        if(result?.Original==source.Text){source.SelectionStart=c.Start;source.SelectionEnd=c.End;source.CaretIndex=c.End;}
        ScrollToChange(output,c);ScrollToChange(before,c);ScrollToChange(after,c);
    }
    private void ToggleSuggestion(){if(suggestions.SelectedItem is Change c){revisions.Record(result!);c.Accepted=!c.Accepted;RenderResult();SelectChange(c);}}
    private void EditSuggestion(){if(suggestions.SelectedItem is Change c){if((replacement.Text?.Length??0)>300){Status("单条替换最多 300 字。");return;}revisions.Record(result!);c.Replacement=replacement.Text??"";c.Accepted=true;c.ManuallyEdited=true;RenderResult();SelectChange(c);}}
    private void RestoreAll(){if(result==null)return;revisions.Record(result);result.Changes.ForEach(c=>c.Accepted=false);RenderResult();}
    private void ProtectSuggestion(){if(suggestions.SelectedItem is Change c){ruleSource.Text=(source.SelectedText?.Length??0)>1?source.SelectedText:c.Original;ruleTarget.Text="";pages.SelectedIndex=3;Status("请填写完整词语或短语，再添加到保护词。");}}
    private void SyncScroll(ScrollViewer a,ScrollViewer b){if(syncing||!settings.SyncScroll)return;syncing=true;try{double max=Math.Max(0,a.Extent.Height-a.Viewport.Height);b.Offset=new Vector(b.Offset.X,max<=0?0:a.Offset.Y/max*Math.Max(0,b.Extent.Height-b.Viewport.Height));}finally{syncing=false;}}
    private void FindNext(){string text=source.Text??"",q=find.Text??"";if(q.Length==0)return;int start=Math.Min(text.Length,Math.Max(source.SelectionStart,source.SelectionEnd));int at=text.IndexOf(q,start,StringComparison.Ordinal);if(at<0)at=text.IndexOf(q,StringComparison.Ordinal);if(at>=0){documents.SelectedIndex=0;source.SelectionStart=at;source.SelectionEnd=at+q.Length;source.CaretIndex=at+q.Length;source.Focus();}}
    private void ReplaceAll(){if(Busy||string.IsNullOrEmpty(find.Text))return;SetSource((source.Text??"").Replace(find.Text,replace.Text??"",StringComparison.Ordinal));}
    private void CleanPunctuation(){if(!Busy)SetSource(EditorActions.CleanPunctuation(source.Text??""));}
    private void LoadExample()=>Run(async()=>{if(!Busy&&await ConfirmReplaceAsync())SetSource(Example);});
    internal const string Example="他认真得检查了这份报告，又把遗漏地细节补充完整。\n\n她高兴的跑进温室，看到植物长的很好，便小心地记录下叶片的变化。\n\n这项工作大约持续了三天左右。我们会在下周继续做实验，并根据实际结果作出调整。\n\n他做的作业已经交了。地理老师说，这张地图画得很清楚。";
    private void ToggleFocus(){focus=!focus;if(workGrid!=null){workGrid.ColumnDefinitions[2].Width=new GridLength(focus?0:310);workGrid.Children[^1].IsVisible=!focus;}}
    private void OnKey(object? sender,KeyEventArgs e)
    {
        if(shortcut.IsFocused)return;
        bool cmd=(e.KeyModifiers&(KeyModifiers.Meta|KeyModifiers.Control))!=0;
        if(e.Key==Key.Escape){work?.Cancel();e.Handled=true;}else if(e.Key==Key.F11){ToggleFocus();e.Handled=true;}
        else if(ShortcutFromKey(e)==settings.CheckShortcut){Run(CheckAsync);e.Handled=true;}
        else if(cmd){switch(e.Key){case Key.O:Run(PickImportAsync);break;case Key.S:Run(ExportAsync);break;case Key.F:findBar.IsVisible=true;find.Focus();break;case Key.OemComma:pages.SelectedIndex=4;break;case Key.C when e.KeyModifiers.HasFlag(KeyModifiers.Shift):Run(CopyAsync);break;default:return;}e.Handled=true;}
    }
    private sealed class CallbackProgress(Action<CheckProgress> action):IProgress<CheckProgress>{public void Report(CheckProgress p)=>action(p);}
}
