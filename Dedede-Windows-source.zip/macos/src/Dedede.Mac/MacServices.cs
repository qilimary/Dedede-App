using System.Diagnostics;
using System.Text;
using Avalonia.Threading;

namespace Dedede.Mac;
internal static class MacServices
{
    public static string Helper=>Path.Combine(AppContext.BaseDirectory,"native","dedede-native");
    private static ProcessStartInfo Info(params string[] args){var info=new ProcessStartInfo(Helper){UseShellExecute=false,RedirectStandardOutput=true,RedirectStandardError=true,StandardOutputEncoding=Encoding.UTF8,StandardErrorEncoding=Encoding.UTF8};foreach(var a in args)info.ArgumentList.Add(a);return info;}
    private static async Task<string> RunAsync(CancellationToken ct,params string[] args)
    {
        if(!File.Exists(Helper))throw new InvalidOperationException("本地识字组件缺失，请重新安装完整 Mac 版。");
        using var p=Process.Start(Info(args))??throw new IOException("无法启动本地识字组件。");
        using var registration=ct.Register(()=>{try{if(!p.HasExited)p.Kill(true);}catch(InvalidOperationException){}});
        var output=p.StandardOutput.ReadToEndAsync();var error=p.StandardError.ReadToEndAsync();await p.WaitForExitAsync();ct.ThrowIfCancellationRequested();string text=await output,message=await error;if(p.ExitCode==20)throw new OperationCanceledException(message);if(p.ExitCode!=0)throw new IOException(message.Trim().Length>0?message.Trim():"本地识字失败。");return text.TrimEnd('\r','\n');
    }
    public static Task<string> OcrAsync(string path,CancellationToken ct)=>RunAsync(ct,"ocr",path);
    public static async Task<string> ClipboardOcrAsync(CancellationToken ct)
    {
        string p=Path.Combine(Path.GetTempPath(),"Dedede-"+Guid.NewGuid().ToString("N")+".png");try{await RunAsync(ct,"clipboard",p);return await OcrAsync(p,ct);}finally{if(File.Exists(p))File.Delete(p);}
    }
    public static async Task<string> ScreenshotAsync(CancellationToken ct)
    {
        string p=Path.Combine(Path.GetTempPath(),"Dedede-"+Guid.NewGuid().ToString("N")+".png");try{await RunAsync(ct,"screenshot",p);return await OcrAsync(p,ct);}finally{if(File.Exists(p))File.Delete(p);}
    }
    public static void Open(string path){try{Process.Start(new ProcessStartInfo("/usr/bin/open"){UseShellExecute=false,ArgumentList={path}});}catch(Exception ex){Program.Log(ex.ToString());}}
    public sealed class Hotkeys:IDisposable
    {
        private Process? process;private bool disposed;
        public Hotkeys(Action<string> trigger,Action<string> status)
        {
            try{process=Process.Start(Info("hotkeys"));if(process==null)return;var p=process;_=Task.Run(async()=>{try{var error=p.StandardError.ReadToEndAsync();while(await p.StandardOutput.ReadLineAsync() is {} line)if(line is "text" or "image")Dispatcher.UIThread.Post(()=>{if(!disposed)trigger(line);});string message=await error;if(!disposed&&message.Trim().Length>0)Dispatcher.UIThread.Post(()=>status(message.Trim()));}catch(Exception ex){if(!disposed)Program.Log(ex.ToString());}});}catch(Exception ex){status("全局快捷键暂不可用："+ex.Message);}
        }
        public void Dispose(){disposed=true;try{if(process is {HasExited:false})process.Kill(true);}catch(InvalidOperationException){}process?.Dispose();process=null;}
    }
}
