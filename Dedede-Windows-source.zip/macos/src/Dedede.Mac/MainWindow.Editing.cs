using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.LogicalTree;
using Dedede.Core;
namespace Dedede.Mac;
public partial class MainWindow
{
    private void ScheduleSave(){if(!initialized||Quitting)return;draftTimer.Stop();if(settings.SaveDraft)draftTimer.Start();}
    private void ScheduleWarmup(){if(!initialized||Quitting||preview||App.Testing)return;warmTimer.Stop();if(settings.Check.Professional)warmTimer.Start();}
    private void SetShortcut(string value){shortcut.Tag=value;shortcut.Text=CheckShortcut.Format(value,true);}
    private static string? ShortcutFromKey(KeyEventArgs e){string name=e.Key.ToString();if(name=="Return")name="Enter";if(name.Length==2&&name[0]=='D'&&char.IsDigit(name[1]))name=name[1..];var p=new List<string>();if(e.KeyModifiers.HasFlag(KeyModifiers.Meta))p.Add("Primary");if(e.KeyModifiers.HasFlag(KeyModifiers.Control))p.Add("Control");if(e.KeyModifiers.HasFlag(KeyModifiers.Alt))p.Add("Alt");if(e.KeyModifiers.HasFlag(KeyModifiers.Shift))p.Add("Shift");p.Add(name);string value=string.Join('+',p);return CheckShortcut.Valid(value)?value:null;}
    private void CaptureShortcut(object? sender,KeyEventArgs e){if(e.Key==Key.Tab)return;e.Handled=true;var value=ShortcutFromKey(e);if(value==null){Status("请使用组合键或功能键，避开编辑和系统快捷键。");return;}SetShortcut(value);Status("点击保存设置后生效。");}
    private void IndentText(){if(!Busy)SetSource(EditorActions.IndentParagraphs(source.Text??""));}
    private async Task ClearInputAsync(){if(!Busy&&await ConfirmReplaceAsync()){SetSource("");ClearResult();ScheduleSave();}}
    private async Task ContinueEditingAsync(){if(result!=null&&!Busy&&await ConfirmReplaceAsync()){SetSource(result.Corrected);Status("已放回原文继续编辑，可撤销此次替换。");}}
    private void ClearResult(){result=null;revisions.Clear();foreach(var b in new[]{output,before,after}){b.Inlines!.Clear();if(marks.ContainsKey(b))marks[b]=[];}RefreshSuggestions();stale.IsVisible=false;changeTools.IsVisible=false;}
    private void ApplyRevisionUndo(bool forward){if(result==null)return;int at=(suggestions.SelectedItem as Change)?.Number??1;if(revisions.Apply(result,forward)){RenderResult();if(result.Changes.Count>0)SelectChange(result.Changes[Math.Clamp(at-1,0,result.Changes.Count-1)]);}}
    private void ScrollToChange(SelectableTextBlock block,Change c){if(!block.IsEffectivelyVisible||!marks.TryGetValue(block,out var ranges))return;var range=ranges.FirstOrDefault(x=>ReferenceEquals(x.Change,c));if(range.Change==null)return;block.UpdateLayout();var rect=block.TextLayout.HitTestTextPosition(range.Start);block.BringIntoView(new Rect(rect.X,Math.Max(0,rect.Y-20),Math.Max(1,rect.Width),rect.Height+40));}
    private void ApplyTypography(){var roots=new List<ILogical>{this};roots.AddRange(pages.Items.OfType<TabItem>());roots.AddRange(documents.Items.OfType<TabItem>());foreach(var text in roots.SelectMany(x=>x.GetLogicalDescendants()).OfType<TextBlock>().Distinct())if(text.Tag is double size)text.FontSize=size+settings.UiFontSize-14;}
}
