using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Input.Platform;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Dedede.Core;

namespace Dedede.Mac;
internal static class Dialogs
{
    public static Task<bool> Confirm(Window owner,string text)=>Show(owner,text,true);
    public static Task<bool> Message(Window owner,string text)=>Show(owner,text,false);
    private static Task<bool> Show(Window owner,string text,bool cancel)
    {
        var w=new Window{Title="纠错 Pro",Width=480,SizeToContent=SizeToContent.Height,CanResize=false,WindowStartupLocation=WindowStartupLocation.CenterOwner};
        var buttons=new StackPanel{Orientation=Orientation.Horizontal,Spacing=10,HorizontalAlignment=HorizontalAlignment.Right};if(cancel){var no=new Button{Content="取消"};no.Click+=(_,_)=>w.Close(false);buttons.Children.Add(no);}var yes=new Button{Content="确定",Classes={"primary"}};yes.Click+=(_,_)=>w.Close(true);buttons.Children.Add(yes);
        w.Content=new StackPanel{Margin=new Thickness(24),Spacing=22,Children={new TextBlock{Text=text,TextWrapping=TextWrapping.Wrap},buttons}};return w.ShowDialog<bool>(owner);
    }
}
internal sealed class DraftWindow : Window
{
    private readonly TextBox editor=new(){AcceptsReturn=true,AcceptsTab=true,TextWrapping=TextWrapping.Wrap,FontSize=18,MaxLength=300_000};private string saved;private bool force,closing;
    public DraftWindow(string text)
    {
        saved=text;Title="编辑成稿 · 纠错 Pro";Width=880;Height=650;MinWidth=500;MinHeight=350;editor.Text=text;
        var save=new Button{Content="另存为…  ⌘ S"};save.Click+=async(_,_)=>await SaveAsync();var copy=new Button{Content="复制全文"};copy.Click+=async(_,_)=>{try{if(Clipboard!=null)await Clipboard.SetTextAsync(editor.Text??"");}catch(Exception ex){await Dialogs.Message(this,ex.Message);}};
        var layout=new DockPanel{Margin=new Thickness(18)};var bar=new StackPanel{Orientation=Orientation.Horizontal,Spacing=10,Margin=new Thickness(0,0,0,14),Children={save,copy}};DockPanel.SetDock(bar,Dock.Top);layout.Children.Add(bar);layout.Children.Add(editor);Content=layout;
        Closing+=async(_,e)=>{if(force)return;e.Cancel=true;if(closing)return;closing=true;try{if(await CanCloseAsync())ForceClose();}finally{closing=false;}};
        KeyDown+=async(_,e)=>{if(e.Key==Key.S&&(e.KeyModifiers&(KeyModifiers.Meta|KeyModifiers.Control))!=0){e.Handled=true;await SaveAsync();}};
    }
    private async Task SaveAsync()
    {
        try{var file=await StorageProvider.SaveFilePickerAsync(new(){SuggestedFileName="成稿.txt",ShowOverwritePrompt=true,FileTypeChoices=[new("纯文本"){Patterns=["*.txt"]},new("Markdown"){Patterns=["*.md"]},new("Word 正文"){Patterns=["*.docx"]}]});string? path=file?.TryGetLocalPath();if(path==null)return;string text=editor.Text??"";await Task.Run(()=>{if(Path.GetExtension(path).Equals(".docx",StringComparison.OrdinalIgnoreCase))Documents.ExportDocx(path,text);else LocalStore.AtomicWrite(path,text);});saved=text;Title="已保存 · 编辑成稿";}catch(Exception ex){await Dialogs.Message(this,ex.Message);}
    }
    public Task<bool> CanCloseAsync()=>(editor.Text??"")==saved?Task.FromResult(true):Dialogs.Confirm(this,"成稿有尚未保存的修改。确定放弃这些修改并关闭？如需保存，请取消后选择“另存为”。");
    public void ForceClose(){force=true;Close();}
}
internal sealed class MiniWindow : Window
{
    private readonly TextBox input=new(){AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,MaxLength=300_000,Watermark="输入或粘贴文字"},output=new(){AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,IsReadOnly=true};private readonly TextBlock status=new(){Text="窗口已置顶"};private CancellationTokenSource? work;
    public MiniWindow(CorrectionEngine engine,Func<CheckSettings> config,Func<Dictionary<string,string>> rules,Func<string,Task> send)
    {
        Title="迷你纠错";Width=530;Height=570;MinWidth=430;MinHeight=350;Topmost=true;
        var check=new Button{Content="开始纠错",Classes={"primary"}};var cancel=new Button{Content="停止"};cancel.Click+=(_,_)=>Cancel();
        check.Click+=async(_,_)=>{if(work!=null)return;using var ct=new CancellationTokenSource();work=ct;check.IsEnabled=false;input.IsReadOnly=true;try{var r=await engine.CheckAsync(input.Text??"",config(),rules(),null,ct.Token);output.Text=r.Corrected;status.Text=$"{r.Changes.Count} 条建议 · {r.ElapsedMs/1000.0:F2} 秒";}catch(OperationCanceledException){status.Text="已停止";}catch(Exception ex){status.Text=ex.Message;}finally{work=null;input.IsReadOnly=false;check.IsEnabled=true;}};
        var paste=new Button{Content="粘贴"};paste.Click+=async(_,_)=>{try{if(work==null&&Clipboard!=null){string? text=await Clipboard.TryGetTextAsync();if(text?.Length>300_000)throw new Exception("单篇文本最多 30 万字。");if(text!=null)input.Text=text;}}catch(Exception ex){status.Text=ex.Message;}};
        var copy=new Button{Content="复制"};copy.Click+=async(_,_)=>{try{if(Clipboard!=null)await Clipboard.SetTextAsync(output.Text??"");}catch(Exception ex){status.Text=ex.Message;}};
        var expand=new Button{Content="送到工作台"};expand.Click+=async(_,_)=>{try{await send(input.Text??"");}catch(Exception ex){status.Text=ex.Message;}};
        var grid=new Grid{RowDefinitions=new RowDefinitions("Auto,*,12,*,Auto"),Margin=new Thickness(16)};grid.Children.Add(new StackPanel{Orientation=Orientation.Horizontal,Spacing=8,Margin=new Thickness(0,0,0,12),Children={check,cancel,paste,copy}});Grid.SetRow(input,1);grid.Children.Add(input);Grid.SetRow(output,3);grid.Children.Add(output);var foot=new StackPanel{Orientation=Orientation.Horizontal,Spacing=10,Margin=new Thickness(0,12,0,0),Children={expand,status}};Grid.SetRow(foot,4);grid.Children.Add(foot);Content=grid;Closed+=(_,_)=>Cancel();
    }
    public void Cancel()=>work?.Cancel();
}
