using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Avalonia.Threading;
using Dedede.Core;

namespace Dedede.Mac;
public partial class App : Application
{
    public static bool Testing { get; set; }
    public override void Initialize()=>AvaloniaXamlLoader.Load(this);
    public override void OnFrameworkInitializationCompleted()
    {
        Dispatcher.UIThread.UnhandledException+=(_,e)=>{Program.Log(e.Exception.ToString());if(ApplicationLifetime is IClassicDesktopStyleApplicationLifetime d&&d.MainWindow is MainWindow w)w.ShowError(e.Exception);e.Handled=true;};
        if(ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var args=desktop.Args??[];bool preview=args.Contains("--render-preview");
            var window=new MainWindow(preview?new LocalStore(Path.Combine(Path.GetTempPath(),"DededePreview-"+Guid.NewGuid().ToString("N"))):new LocalStore(),preview);
            desktop.MainWindow=window;desktop.ShutdownMode=ShutdownMode.OnExplicitShutdown;
            desktop.ShutdownRequested+=(_,e)=>{if(!window.Quitting){e.Cancel=true;_=window.QuitAsync();}};
            var appMenu=new NativeMenu();var about=new NativeMenuItem("关于纠错 Pro");about.Click+=(_,_)=>window.ShowPage(5);appMenu.Add(about);
            var prefs=new NativeMenuItem("偏好设置…"){Gesture=new(Avalonia.Input.Key.OemComma,Avalonia.Input.KeyModifiers.Meta)};prefs.Click+=(_,_)=>window.ShowPage(4);appMenu.Add(prefs);appMenu.Add(new NativeMenuItemSeparator());
            var hide=new NativeMenuItem("隐藏纠错 Pro"){Gesture=new(Avalonia.Input.Key.H,Avalonia.Input.KeyModifiers.Meta)};hide.Click+=(_,_)=>window.Hide();appMenu.Add(hide);
            var quit=new NativeMenuItem("退出纠错 Pro"){Gesture=new(Avalonia.Input.Key.Q,Avalonia.Input.KeyModifiers.Meta)};quit.Click+=async(_,_)=>await window.QuitAsync();appMenu.Add(quit);NativeMenu.SetMenu(this,appMenu);
            window.Opened+=async(_,_)=>
            {
                if(preview){try{await window.CapturePreviewsAsync(args.SkipWhile(x=>x!="--render-preview").Skip(1).FirstOrDefault()??"previews");await window.QuitAsync();}catch(Exception ex){Program.Log(ex.ToString());desktop.Shutdown(1);}return;}
                Program.Listen(window);await window.ImportPathsAsync(args.Where(File.Exists).ToArray());
            };
        }
        base.OnFrameworkInitializationCompleted();
    }
}
