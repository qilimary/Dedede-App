using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Templates;
using Avalonia.Layout;
using Avalonia.Data;
using Avalonia.Media;
using Dedede.Core;

namespace Dedede.Mac;
public partial class MainWindow
{
    private readonly TabControl pages=new(),documents=new();
    private readonly TextBox source=Editor(),replacement=new(),find=new(){Watermark="查找",Width=160},replace=new(){Watermark="替换",Width=160};
    private readonly SelectableTextBlock output=Body(),before=Body(),after=Body();
    private readonly ComboBox mode=Combo("专业","极速"),filter=Combo("全部建议","已采纳","已还原");
    private readonly TextBox temperature=Field("1.0",50),threads=Field("4",70);
    private readonly TextBox[] thresholds=[Field("0.70",50),Field("0.70",50),Field("0.75",50),Field("0.75",50),Field("0.75",50)];
    private readonly ListBox suggestions=new(),batchList=new(),historyList=new(),ruleList=new();
    private readonly TextBlock count=Text("0 字符"),summary=Text("检查后在这里逐条复核"),position=Text(""),stale=Text("原文已编辑，请重新检查。"),status=Text("准备好了。输入文字，或拖入文件。"),batchFolder=Text("尚未选择输出文件夹");
    private readonly ProgressBar progress=new(){Width=110,MinWidth=0,Height=5,Maximum=100,IsVisible=false};
    private readonly StackPanel changeTools=new(){Spacing=10},findBar=new(){Orientation=Orientation.Horizontal,Spacing=8};
    private readonly Button check=new(){Content="开始纠错  ⌘ Enter",Classes={"primary"}},stop=new(){Content="停止",IsEnabled=false};
    private readonly TextBox ruleSource=new(){Watermark="词语或短语"},ruleTarget=new(){Watermark="留空表示保护原词"},ruleSearch=new(){Watermark="搜索词库"};
    private readonly ComboBox theme=Combo("跟随系统","浅色","深色"),accent=Combo("晴空蓝","植物绿","丁香紫","暖杏色");
    private readonly TextBox shortcut=new(){IsReadOnly=true};
    private readonly Slider uiFont=new(){Minimum=12,Maximum=18,Value=14,TickFrequency=1,IsSnapToTickEnabled=true};
    private readonly Button toggleSuggestion=new(){Content="还原为原字"},undoRevision=new(){Content="撤销修改"},redoRevision=new(){Content="重做修改"};
    private readonly ScrollViewer outputScroll=new(),beforeScroll=new(),afterScroll=new();
    private readonly TextBlock help=Text("");
    private readonly Slider font=new(){Minimum=14,Maximum=30,Value=18,TickFrequency=1,IsSnapToTickEnabled=true};
    private readonly CheckBox sync=Check("并排对比同步滚动"),traySetting=Check("关闭窗口后留在菜单栏"),hotkeySetting=Check("全局快捷键：⌘ ⌥ D / O"),keepHistory=Check("保留本机历史记录"),saveDraft=Check("下次打开时恢复原文与修订结果");
    private static TextBlock Text(string s,double size=14)=>new(){Text=s,FontSize=size,Tag=size,TextWrapping=TextWrapping.Wrap,VerticalAlignment=VerticalAlignment.Center};
    private static TextBox Field(string value,double width)=>new(){Text=value,Width=width};
    private static TextBox Editor()=>new(){AcceptsReturn=true,AcceptsTab=true,TextWrapping=TextWrapping.Wrap,MaxLength=300_000,FontSize=18,Padding=new Thickness(18),BorderThickness=new Thickness(0),VerticalContentAlignment=VerticalAlignment.Top};
    private static SelectableTextBlock Body()=>new(){TextWrapping=TextWrapping.Wrap,FontSize=18,LineHeight=34,Margin=new Thickness(18)};
    private static ComboBox Combo(params string[] items)=>new(){ItemsSource=items,SelectedIndex=0,MinWidth=120};
    private static CheckBox Check(string text)=>new(){Content=text,Margin=new Thickness(0,4)};
    private static Button Button(string text,Action action){var b=new Button{Content=text};b.Click+=(_,_)=>action();return b;}
    private Button AsyncButton(string text,Func<Task> action)=>Button(text,()=>Run(action));
    private static Control NumberedLabel(Control number,string label){var g=new Grid{ColumnDefinitions=new ColumnDefinitions("Auto,*")};number.Margin=new Thickness(0,0,9,0);g.Children.Add(number);var text=Text(label,17);Grid.SetColumn(text,1);g.Children.Add(text);return g;}
    private static WrapPanel Tools(params Control[] controls){var panel=new WrapPanel();foreach(var c in controls){c.Margin=new Thickness(0,0,6,4);panel.Children.Add(c);}return panel;}
    private static StackPanel Row(params Control[] children)=>new StackPanel{Orientation=Orientation.Horizontal,Spacing=8}.With(children);
    private static StackPanel Column(params Control[] children)=>new StackPanel{Spacing=14}.With(children);
    private static Border Card(Control child)=>new(){Classes={"card"},Child=child};
    private static ScrollViewer Scroll(Control child)=>new(){Content=child,VerticalScrollBarVisibility=Avalonia.Controls.Primitives.ScrollBarVisibility.Auto};
    private static TabItem Tab(string title,Control content)=>new(){Header=title,Content=content};
    private static Control Two(Control left,Control right)
    {
        var g=new Grid{ColumnDefinitions=new ColumnDefinitions("*,8,*")};g.Children.Add(left);var s=new GridSplitter{Width=6,HorizontalAlignment=HorizontalAlignment.Stretch};Grid.SetColumn(s,1);g.Children.Add(s);Grid.SetColumn(right,2);g.Children.Add(right);return g;
    }
    private static Control Titled(string title,Control body,Control? extra=null)
    {
        var g=new Grid{RowDefinitions=new RowDefinitions("Auto,*")};var header=new DockPanel{Margin=new Thickness(16,10),MinHeight=40};if(extra!=null){DockPanel.SetDock(extra,Dock.Right);header.Children.Add(extra);}header.Children.Add(Text(title,15));g.Children.Add(header);Grid.SetRow(body,1);g.Children.Add(body);return g;
    }
    private static Control EditorPanel(string title,Control body,Control toolbar,Control? extra=null)
    {
        var g=new Grid{RowDefinitions=new RowDefinitions("Auto,*")};var header=new DockPanel();if(extra!=null){DockPanel.SetDock(extra,Dock.Right);header.Children.Add(extra);}header.Children.Add(Text(title,15));var head=new Border{Padding=new Thickness(16,12),BorderThickness=new Thickness(0,0,0,1),Classes={"editorHeader"},Child=Column(header,toolbar)};g.Children.Add(head);Grid.SetRow(body,1);g.Children.Add(body);return g;
    }
    private Control BuildWork()
    {
        var g=new Grid{RowDefinitions=new RowDefinitions("Auto,Auto,Auto,*"),Margin=new Thickness(0,12,0,0)};
        var controls=new WrapPanel{Orientation=Orientation.Horizontal};controls.Children.Add(mode);controls.Children.Add(Text("   温度 "));controls.Children.Add(temperature);controls.Children.Add(Text("   修改阈值 "));
        for(int i=0;i<5;i++){controls.Children.Add(Text("的地得做作"[i]+" "));controls.Children.Add(thresholds[i]);}
        foreach(var c in controls.Children)c.Margin=new Thickness(0,0,7,4);var controlBar=new DockPanel{LastChildFill=true};var runButtons=Row(check,stop);DockPanel.SetDock(runButtons,Dock.Right);runButtons.Margin=new Thickness(14,0,0,0);controlBar.Children.Add(runButtons);controlBar.Children.Add(controls);g.Children.Add(Card(controlBar));
        var toolbar=new WrapPanel{Margin=new Thickness(0,10,0,10)};
        foreach(var c in new Control[]{AsyncButton("导入文件",PickImportAsync),AsyncButton("粘贴文字",PasteAsync),AsyncButton("图片 OCR",PickImageAsync),AsyncButton("剪贴板 OCR",ClipboardOcrAsync),AsyncButton("截图识字",ScreenshotAsync),Button("查找替换",()=>findBar.IsVisible=!findBar.IsVisible),Button("标点整理",CleanPunctuation),Button("示例",LoadExample)}){c.Margin=new Thickness(0,0,6,6);toolbar.Children.Add(c);}Grid.SetRow(toolbar,1);g.Children.Add(toolbar);
        findBar.Children.Add(find);findBar.Children.Add(replace);findBar.Children.Add(Button("下一个",FindNext));findBar.Children.Add(Button("替换全部",ReplaceAll));findBar.Children.Add(Button("关闭",()=>findBar.IsVisible=false));findBar.IsVisible=false;stale.Foreground=Brushes.DarkOrange;stale.IsVisible=false;var notices=Column(findBar,stale);notices.Margin=new Thickness(0,0,0,8);Grid.SetRow(notices,2);g.Children.Add(notices);
        outputScroll.Content=output;beforeScroll.Content=before;afterScroll.Content=after;
        beforeScroll.ScrollChanged+=(_,_)=>SyncScroll(beforeScroll,afterScroll);afterScroll.ScrollChanged+=(_,_)=>SyncScroll(afterScroll,beforeScroll);
        var editTools=Tools(Button("撤销",()=>{source.Undo();source.Focus();}),Button("重做",()=>{source.Redo();source.Focus();}),Button("首行缩进",IndentText),AsyncButton("清空",ClearInputAsync));
        var resultTools=Tools(AsyncButton("复制全文",CopyAsync),AsyncButton("导出",ExportAsync),AsyncButton("继续编辑",ContinueEditingAsync));
        documents.Items.Add(Tab("修订标注",Two(EditorPanel("原文",source,editTools,count),EditorPanel("修订标注",outputScroll,resultTools))));
        documents.Items.Add(Tab("全文对比",Two(Titled("检查时的原文",beforeScroll),Titled("修订后的全文",afterScroll,Row(AsyncButton("复制全文",CopyAsync),AsyncButton("导出",ExportAsync))))));documents.SelectedIndex=0;
        suggestions.ItemTemplate=new FuncDataTemplate<Change>((c,_)=>{var number=Button(c?.NumberLabel??"",()=>{if(c!=null)SelectChange(c);});number.Padding=new Thickness(7,3);number.Classes.Add("number");return Column(NumberedLabel(number,c?.Label??""),Text(c?.Detail??"",12));});suggestions.SelectionChanged+=(_,_)=>SelectSuggestion();filter.SelectionChanged+=(_,_)=>RefreshSuggestions();
        toggleSuggestion.Click+=(_,_)=>ToggleSuggestion();undoRevision.Click+=(_,_)=>ApplyRevisionUndo(false);redoRevision.Click+=(_,_)=>ApplyRevisionUndo(true);
        changeTools.Children.Add(Row(undoRevision,redoRevision));changeTools.Children.Add(position);changeTools.Children.Add(replacement);changeTools.Children.Add(Row(toggleSuggestion,Button("保存修订",EditSuggestion)));changeTools.Children.Add(Button("加入保护词",ProtectSuggestion));changeTools.IsVisible=false;
        var side=new Grid{RowDefinitions=new RowDefinitions("Auto,Auto,Auto,*,Auto")};side.Children.Add(Text("修改建议",21));var info=Column(summary,filter);Grid.SetRow(info,1);side.Children.Add(info);var all=Row(Button("全部采纳",()=>AcceptAll(true)),Button("全部还原",()=>AcceptAll(false)));all.Margin=new Thickness(0,10);Grid.SetRow(all,2);side.Children.Add(all);Grid.SetRow(suggestions,3);side.Children.Add(suggestions);Grid.SetRow(changeTools,4);side.Children.Add(changeTools);
        var body=new Grid{ColumnDefinitions=new ColumnDefinitions("*,10,310")};body.Children.Add(Card(documents));var splitter=new GridSplitter{Width=8,HorizontalAlignment=HorizontalAlignment.Stretch};Grid.SetColumn(splitter,1);body.Children.Add(splitter);var sidebar=Card(side);Grid.SetColumn(sidebar,2);body.Children.Add(sidebar);Grid.SetRow(body,3);g.Children.Add(body);workGrid=body;return g;
    }
    private Grid? workGrid;
    private void BuildLayout()
    {
        var root=new Grid{RowDefinitions=new RowDefinitions("66,*,32"),Margin=new Thickness(22,14,22,10)};
        var header=new DockPanel();var buttons=Row(Button("迷你窗口",OpenMini),Button("专注模式",ToggleFocus));DockPanel.SetDock(buttons,Dock.Right);header.Children.Add(buttons);var logo=new Image{Source=new Avalonia.Media.Imaging.Bitmap(Path.Combine(Program.Assets,"app.png")),Width=38,Height=38,Margin=new Thickness(0,0,12,0)};DockPanel.SetDock(logo,Dock.Left);header.Children.Add(logo);var brand=Column(Text("纠错 Pro",24),Text("让每一次表达，更准确一些",12));brand.Spacing=3;header.Children.Add(brand);root.Children.Add(header);
        pages.Items.Add(Tab("文本工作台",BuildWork()));
        batchList.ItemTemplate=new FuncDataTemplate<BatchItem>((item,_)=>{var t=Text("");t.Bind(TextBlock.TextProperty,new Binding(nameof(BatchItem.Display)){Source=item});return t;});
        var batchPage=new Grid{RowDefinitions=new RowDefinitions("Auto,Auto,*,Auto"),Margin=new Thickness(0,16)};batchPage.Children.Add(Row(AsyncButton("添加文件",PickBatchAsync),Button("移除选中",RemoveBatch),AsyncButton("选择输出文件夹",PickOutputAsync),AsyncButton("开始批量纠错",RunBatchAsync)));Grid.SetRow(batchFolder,1);batchFolder.Margin=new Thickness(0,14);batchPage.Children.Add(batchFolder);Grid.SetRow(batchList,2);batchPage.Children.Add(batchList);var note=Text("支持文档和图片。每个文件生成修订文本与对比报告，原文件保留。",12);Grid.SetRow(note,3);batchPage.Children.Add(note);pages.Items.Add(Tab("批量处理",Card(batchPage)));
        historyList.ItemTemplate=new FuncDataTemplate<CheckResult>((r,_)=>Column(Text($"{r?.Created:MM-dd HH:mm} · {r?.Changes.Count} 条建议"),Text((r?.Original??"").Replace('\n',' ').Truncate(90),12)));
        pages.Items.Add(Tab("历史记录",Card(Titled("本机历史",historyList,Row(AsyncButton("恢复",RestoreHistoryAsync),Button("删除",DeleteHistory),AsyncButton("清空",ClearHistoryAsync))))));
        ruleList.ItemTemplate=new FuncDataTemplate<KeyValuePair<string,string>>((p,_)=>Text(p.Key==p.Value?p.Key+"　保护原词":p.Key+" → "+p.Value));
        var rules=new Grid{RowDefinitions=new RowDefinitions("Auto,Auto,*")};rules.Children.Add(Column(Text("我的词库",22),Text("填入完整词语或短语。替换留空时，纠错会保留原词。",13),Row(ruleSource,ruleTarget,AsyncButton("添加 / 更新",AddRuleAsync),Button("删除选中",DeleteRule),AsyncButton("导入",ImportRulesAsync),AsyncButton("导出",ExportRulesAsync))));ruleSource.Width=180;ruleTarget.Width=190;ruleSearch.Margin=new Thickness(0,16);Grid.SetRow(ruleSearch,1);rules.Children.Add(ruleSearch);Grid.SetRow(ruleList,2);rules.Children.Add(ruleList);pages.Items.Add(Tab("我的词库",Card(rules)));
        shortcut.KeyDown+=CaptureShortcut;
        var fontValue=Text("");fontValue.Bind(TextBlock.TextProperty,new Binding("Value"){Source=font,StringFormat="正文字号  {0:0}"});
        var uiFontValue=Text("");uiFontValue.Bind(TextBlock.TextProperty,new Binding("Value"){Source=uiFont,StringFormat="界面字号  {0:0}"});
        var appearance=Card(Column(Text("外观与阅读",22),Text("明暗模式"),theme,Text("主题色"),accent,fontValue,font,uiFontValue,uiFont,sync,Row(Button("保存设置",SaveSettings),AsyncButton("恢复默认",ResetSettingsAsync))));
        var background=new Expander{Header="后台工具",Content=Column(traySetting,hotkeySetting,Text("D：读取文字；O：识别剪贴板图片。菜单栏可再次打开工作台或退出。",12))};
        var performance=new Expander{Header="性能设置",Content=Row(Text("CPU 线程数（1～32）"),threads)};
        var preferences=Card(Column(Text("快捷键与保存",22),Text("开始纠错快捷键"),shortcut,Text("点击输入框，再按下想使用的组合键。",12),Button("恢复 ⌘ + Enter",()=>SetShortcut(CheckShortcut.Default)),keepHistory,saveDraft,Text("文字与图片识别均在本机完成。",13),background,performance,Row(AsyncButton("清空草稿",ClearDraftAsync),Button("打开数据目录",()=>MacServices.Open(store.Root)))));
        pages.Items.Add(Tab("偏好设置",Scroll(Two(appearance,preferences))));
        help.LineHeight=28;
        pages.Items.Add(Tab("关于与帮助",Scroll(Card(Column(Text("纠错 Pro · Mac 1.2",28),Text("作者：奇　·　公众号：Li的信箱"),Text("使用说明",22),help,Row(AsyncButton("复制诊断信息",CopyDiagnosticsAsync),Button("打开说明",()=>MacServices.Open(Path.Combine(AppContext.BaseDirectory,"使用说明.html"))),AsyncButton("退出程序",QuitAsync)))))));
        pages.SelectedIndex=0;Grid.SetRow(pages,1);root.Children.Add(pages);var foot=new DockPanel{Margin=new Thickness(0,8,0,0)};var offline=Text("离线运行",12);DockPanel.SetDock(offline,Dock.Right);foot.Children.Add(offline);DockPanel.SetDock(progress,Dock.Left);progress.Margin=new Thickness(0,0,10,0);foot.Children.Add(progress);status.Classes.Add("muted");foot.Children.Add(status);Grid.SetRow(foot,2);root.Children.Add(foot);Content=root;
    }
}
internal static class LayoutExtensions
{
    public static StackPanel With(this StackPanel panel,IEnumerable<Control> controls){foreach(var c in controls)panel.Children.Add(c);return panel;}
    public static string Truncate(this string s,int max)=>s.Length>max?s[..max]+"…":s;
}
