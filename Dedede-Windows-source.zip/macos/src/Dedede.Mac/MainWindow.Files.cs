using Avalonia.Controls;
using Avalonia.Input.Platform;
using Avalonia.Platform.Storage;
using Dedede.Core;
using System.ComponentModel;
using System.Text;
using System.Text.Json;

namespace Dedede.Mac;
public partial class MainWindow
{
    private static readonly FilePickerFileType Docs=new("文档与图片"){Patterns=["*.txt","*.md","*.csv","*.log","*.srt","*.docx","*.pptx","*.pdf","*.png","*.jpg","*.jpeg","*.bmp","*.tif","*.tiff","*.webp","*.heic"]};
    private static readonly FilePickerFileType Images=new("图片"){Patterns=["*.png","*.jpg","*.jpeg","*.bmp","*.tif","*.tiff","*.webp","*.heic"]};
    private static bool IsImage(string path)=>Documents.ImageExtensions.Contains(Path.GetExtension(path).ToLowerInvariant())||Path.GetExtension(path).Equals(".heic",StringComparison.OrdinalIgnoreCase);
    private async Task<string[]> PickAsync(FilePickerFileType type,bool many=true)=>(await StorageProvider.OpenFilePickerAsync(new(){Title="选择文件",AllowMultiple=many,FileTypeFilter=[type,FilePickerFileTypes.All]})).Select(x=>x.TryGetLocalPath()).OfType<string>().ToArray();
    private async Task PickImportAsync(){if(!Busy)await ImportPathsAsync(await PickAsync(Docs));}
    private async Task PickImageAsync(){if(!Busy)await ImportPathsAsync(await PickAsync(Images,false));}
    public async Task ImportPathsAsync(string[] paths)
    {
        if(paths.Length==0)return;if(Busy){Status("请先停止当前任务。");return;}if(paths.Length>1){AddBatch(paths);pages.SelectedIndex=1;return;}if(!await ConfirmReplaceAsync())return;
        await WithWorkAsync(async ct=>{SetSource(await ReadAsync(paths[0],ct));Status("已导入："+Path.GetFileName(paths[0])+"。请核对正文。");});
    }
    private static Task<string> ReadAsync(string path,CancellationToken ct)=>IsImage(path)?MacServices.OcrAsync(path,ct):Task.Run(()=>{ct.ThrowIfCancellationRequested();string s=Documents.ReadText(path);ct.ThrowIfCancellationRequested();return s;},ct);
    private async Task WithWorkAsync(Func<CancellationToken,Task> action)
    {
        if(Busy)return;using var ct=new CancellationTokenSource();work=ct;SetBusy(true);source.IsReadOnly=true;
        try{await action(ct.Token);}finally{source.IsReadOnly=false;work=null;SetBusy(false);}
    }
    private async Task PasteAsync(){RestoreWindow();if(Busy)return;string? text=Clipboard==null?null:await Clipboard.TryGetTextAsync();if(text==null){Status("剪贴板没有文字。");return;}if(await ConfirmReplaceAsync())SetSource(text);}
    private async Task ClipboardOcrAsync(){RestoreWindow();if(Busy||!await ConfirmReplaceAsync())return;await WithWorkAsync(async ct=>{Status("正在识别剪贴板图片…");SetSource(await MacServices.ClipboardOcrAsync(ct));Status("识别完成，请核对文字。");});}
    private async Task ScreenshotAsync()
    {
        if(Busy||!await ConfirmReplaceAsync())return;
        await WithWorkAsync(async ct=>{try{Hide();await Task.Delay(200,ct);string text=await MacServices.ScreenshotAsync(ct);RestoreWindow();SetSource(text);Status("截图识别完成，请核对文字。");}finally{RestoreWindow();}});
    }
    private async Task CopyAsync(){if(result==null){Status("尚无纠错结果。");return;}if(Clipboard!=null)await Clipboard.SetTextAsync(result.Corrected);Status(result.Original==source.Text?"已复制修订后的全文。":"已复制旧结果；原文已变化。");}
    private async Task<string?> SavePathAsync(string suggested,params FilePickerFileType[] types)=>(await StorageProvider.SaveFilePickerAsync(new(){Title="保存文件",SuggestedFileName=suggested,FileTypeChoices=types,ShowOverwritePrompt=true}))?.TryGetLocalPath();
    private static FilePickerFileType Type(string name,string ext)=>new(name){Patterns=["*."+ext]};
    private async Task ExportAsync()
    {
        if(result==null){Status("请先完成一次检查。");return;}var path=await SavePathAsync("修订文本.txt",Type("纯文本","txt"),Type("Markdown","md"),Type("Word 正文","docx"),Type("全文对比报告","html"),Type("修改清单","csv"));if(path==null)return;
        var snapshot=JsonSerializer.Deserialize<CheckResult>(JsonSerializer.Serialize(result))!;
        await Task.Run(()=>{string ext=Path.GetExtension(path).ToLowerInvariant();if(ext==".docx")Documents.ExportDocx(path,snapshot.Corrected);else LocalStore.AtomicWrite(path,ext==".html"?Reports.Html(snapshot):ext==".csv"?"\ufeff"+Reports.Csv(snapshot):snapshot.Corrected);});Status("已保存："+path);
    }
    private void AddBatch(IEnumerable<string> paths){foreach(string p in paths)if(File.Exists(p)&&!batch.Any(x=>x.Path==p))batch.Add(new(p));}
    private async Task PickBatchAsync(){if(!Busy)AddBatch(await PickAsync(Docs));}
    private void RemoveBatch(){if(!Busy&&batchList.SelectedItem is BatchItem item)batch.Remove(item);}
    private async Task PickOutputAsync(){if(Busy)return;var dirs=await StorageProvider.OpenFolderPickerAsync(new(){Title="选择输出文件夹",AllowMultiple=false});outputFolder=dirs.FirstOrDefault()?.TryGetLocalPath();batchFolder.Text=outputFolder??"尚未选择输出文件夹";}
    private async Task RunBatchAsync()
    {
        if(Busy||batch.Count==0)return;if(outputFolder==null)await PickOutputAsync();if(outputFolder==null)return;var config=ReadConfig();var rules=new Dictionary<string,string>(settings.CustomRules);string folder=outputFolder;
        await WithWorkAsync(async ct=>
        {
            int done=0,failed=0;
            foreach(var item in batch.ToArray())
            {
                ct.ThrowIfCancellationRequested();item.State="处理中…";
                try{string text=await ReadAsync(item.Path,ct);var r=await engine.CheckAsync(text,config,rules,null,ct);ct.ThrowIfCancellationRequested();await Task.Run(()=>{WriteNew(folder,item.Path,".txt",r.Corrected);WriteNew(folder,item.Path,".html",Reports.Html(r));},ct);item.State=$"完成 · {r.Changes.Count} 条 · {r.ElapsedMs/1000.0:F2} 秒";done++;}
                catch(OperationCanceledException){item.State="已停止";throw;}catch(Exception ex){item.State="失败："+ex.Message;failed++;}
                progress.IsIndeterminate=false;progress.Value=(done+failed)*100.0/batch.Count;Status($"批量处理 · 完成 {done} · 失败 {failed}");
            }
        });
    }
    private static void WriteNew(string folder,string input,string ext,string text)
    {
        string stem=Path.GetFileNameWithoutExtension(input)+"-修订";Directory.CreateDirectory(folder);
        for(int i=0;;i++)
        {
            string path=Path.Combine(folder,stem+(i==0?"":"-"+i)+ext);FileStream stream;
            try{stream=new FileStream(path,FileMode.CreateNew,FileAccess.Write,FileShare.None);}
            catch(IOException)when(File.Exists(path)){continue;}
            try{using(stream)using(var writer=new StreamWriter(stream,new UTF8Encoding(false)))writer.Write(text);return;}
            catch{try{File.Delete(path);}catch{}throw;}
        }
    }
    private void RefreshHistory()=>historyList.ItemsSource=store.History();
    private void SaveHistoryState()
    {
        if(!settings.KeepHistory||result==null)return;
        try{var history=store.History();int i=history.FindIndex(x=>x.Created==result.Created);if(i>=0){history[i]=result;store.Save("history.json",history);}}catch(Exception ex){Status("历史保存失败："+ex.Message);}
    }
    private async Task RestoreHistoryAsync(){if(Busy||historyList.SelectedItem is not CheckResult r||!await ConfirmReplaceAsync())return;SaveHistoryState();SetSource(r.Original);result=r;revisions.Clear();RenderResult();Status("已恢复原文与修改状态。");}
    private void DeleteHistory(){if(historyList.SelectedItem is CheckResult r){store.Save("history.json",store.History().Where(x=>x.Created!=r.Created).ToList());RefreshHistory();}}
    private async Task ClearHistoryAsync(){if(await Dialogs.Confirm(this,"清空本机历史记录？")){historyTimer.Stop();store.Delete("history.json");RefreshHistory();}}
    private void RefreshRules(){string q=ruleSearch.Text??"";ruleList.ItemsSource=settings.CustomRules.Where(x=>x.Key.Contains(q,StringComparison.OrdinalIgnoreCase)||x.Value.Contains(q,StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x.Key).ToArray();}
    private async Task AddRuleAsync()
    {
        string from=ruleSource.Text?.Trim()??"",to=ruleTarget.Text?.Trim()??"";if(from.Length==0)return;if(from.Length>300||to.Length>300)throw new InvalidDataException("每条规则最多 300 字。");if(to.Length==0)to=from;
        if(from.Length==1&&to==from&&!await Dialogs.Confirm(this,"保护单个字会影响所有包含它的文本。建议使用完整词语，仍要添加吗？"))return;
        settings.CustomRules[from]=to;store.Save("settings.json",settings);RefreshRules();Status("词库已保存，下次检查生效。");
    }
    private void DeleteRule(){if(ruleList.SelectedItem is KeyValuePair<string,string> p){settings.CustomRules.Remove(p.Key);store.Save("settings.json",settings);RefreshRules();}}
    private async Task ImportRulesAsync()
    {
        var paths=await PickAsync(new FilePickerFileType("规则"){Patterns=["*.json","*.txt"]},false);if(paths.Length==0)return;if(new FileInfo(paths[0]).Length>4*1024*1024)throw new InvalidDataException("规则文件最多 4 MiB。");var incoming=LocalStore.ParseCustomRules(await File.ReadAllTextAsync(paths[0]));if(incoming.Any(x=>string.IsNullOrEmpty(x.Key)||x.Value==null||x.Key.Length>300||x.Value.Length>300))throw new InvalidDataException("规则内容无效。");if(!await Dialogs.Confirm(this,$"合并 {incoming.Count} 条规则？同名规则将更新。"))return;
        foreach(var p in incoming)settings.CustomRules[p.Key]=p.Value;store.Save("settings.json",settings);RefreshRules();
    }
    private async Task ExportRulesAsync(){var path=await SavePathAsync("纠错自定义规则.json",Type("JSON","json"));if(path!=null)LocalStore.AtomicWrite(path,JsonSerializer.Serialize(settings.CustomRules,LocalStore.JsonOptions));}
    private sealed class BatchItem(string path):INotifyPropertyChanged
    {
        public string Path{get;}=path;private string state="待处理";
        public string State{get=>state;set{state=value;PropertyChanged?.Invoke(this,new(nameof(Display)));}}
        public string Display=>System.IO.Path.GetFileName(Path)+"　　"+State;
        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
