using Avalonia;
using Avalonia.Controls;
using Avalonia.Media.Imaging;
using Avalonia.Threading;
using Dedede.Core;
using System.Text.Json;

namespace Dedede.Mac;
public partial class MainWindow
{
    public async Task CapturePreviewsAsync(string directory)
    {
        Directory.CreateDirectory(directory);Width=1440;Height=940;settings.KeepHistory=false;settings.SaveDraft=false;settings.Theme="light";ApplyAppearance();SetSource(Example);await CheckAsync();keepHistory.IsChecked=true;saveDraft.IsChecked=true;
        if(result==null||result.ModelCalls==0)throw new InvalidOperationException("Preview inference failed.");
        await Save("01-workspace.png");documents.SelectedIndex=1;await Save("02-side-by-side.png");SelectChange(result.Changes.First());documents.SelectedIndex=0;await Save("03-review.png");
        pages.SelectedIndex=1;await Save("04-batch.png");pages.SelectedIndex=3;await Save("05-rules.png");pages.SelectedIndex=4;await Save("06-settings.png");pages.SelectedIndex=5;await Save("07-help.png");
        pages.SelectedIndex=0;documents.SelectedIndex=0;settings.Theme="dark";ApplyAppearance();await Save("08-dark.png");settings.Theme="light";settings.UiFontSize=18;settings.FontSize=24;ApplyAppearance();await Save("09-large-fonts.png");settings.UiFontSize=14;settings.FontSize=18;ApplyAppearance();
        LocalStore.AtomicWrite(Path.Combine(directory,"preview-result.json"),JsonSerializer.Serialize(result,LocalStore.JsonOptions));
        async Task Save(string name){await Dispatcher.UIThread.InvokeAsync(()=>{},DispatcherPriority.ApplicationIdle);UpdateLayout();await Task.Delay(120);using var bitmap=new RenderTargetBitmap(new PixelSize((int)Bounds.Width,(int)Bounds.Height),new Vector(96,96));bitmap.Render(this);bitmap.Save(Path.Combine(directory,name));}
    }
    // Exercise actual UI event handlers and inference in the headless integration runner.
    public async Task<int> VerifyWorkflowAsync()
    {
        int passed=0;void Assert(bool ok,string name){if(!ok)throw new InvalidOperationException(name);passed++;}
        SetSource(Example);await CheckAsync();Assert(result is {ModelCalls:>0},"real inference through UI");string corrected=result!.Corrected;
        Assert(corrected.Contains("遗漏的"),"model result displayed");Assert(result.Changes.Any(c=>c.Confidence.HasValue&&c.Detail.Contains("置信度")),"visible confidence");
        AcceptAll(false);Assert(result.Corrected==result.Original,"reject all exact original");AcceptAll(true);Assert(result.Corrected==corrected,"accept all restores output");
        filter.SelectedIndex=2;Assert(!suggestions.ItemsSource!.Cast<Change>().Any(),"ignored filter");filter.SelectedIndex=0;
        var change=result.Changes.First();SelectChange(change);replacement.Text="测试替换";EditSuggestion();Assert(result.Corrected.Contains("测试替换"),"manual edit");Assert(!change.Detail.Contains(change.Kind,StringComparison.Ordinal),"no source displayed");
        SetSource("新的输入");Assert(stale.IsVisible,"stale results marked");
        SetSource(string.Concat(Enumerable.Repeat("他认真得检查了这份报告。",200)));var running=CheckAsync();SetSource("编辑后");await running;Assert(result.Original==Example,"editing cancels stale inference");
        SetSource(Example);await CheckAsync();
        for(int i=0;i<2;i++){documents.SelectedIndex=i;RenderVisible();Assert(!dirty[i],"comparison lazy rendering "+i);}
        documents.SelectedIndex=0;
        Assert(documents.Items.Count==2,"exactly two result views");
        Assert(output.Inlines!.OfType<Avalonia.Controls.Documents.Run>().Any(r=>r.Text?.Contains("置信度")==true),"confidence in annotated text");
        Assert(output.Inlines!.OfType<Avalonia.Controls.Documents.Run>().Any(r=>r.TextDecorations==Avalonia.Media.TextDecorations.Strikethrough),"struck original visible");
        Assert(result.Changes.Select(c=>c.Number).SequenceEqual(Enumerable.Range(1,result.Changes.Count)),"stable navigation numbers");
        var first=result.Changes.First();SelectChange(first);ToggleSuggestion();Assert(!first.Accepted&&toggleSuggestion.Content?.ToString()=="采纳本条","restore original action");ApplyRevisionUndo(false);Assert(result.Changes.First().Accepted,"undo correction decision");ApplyRevisionUndo(true);Assert(!result.Changes.First().Accepted,"redo correction decision");
        source.Text="第一段\r\n\r\n第二段";IndentText();Assert(source.Text=="　　第一段\r\n\r\n　　第二段","paragraph indentation");source.Undo();Assert(source.Text=="第一段\r\n\r\n第二段","native text undo");source.Redo();Assert(source.Text!.StartsWith("　　"),"native text redo");
        settings.SaveDraft=true;TrySaveDraft();var saved=store.LoadWorkspace();Assert(saved.Result?.Corrected==result.Corrected&&saved.Source==source.Text,"save complete workspace");settings.SaveDraft=false;
        SetShortcut("Primary+Shift+Enter");SaveSettings();Assert(settings.CheckShortcut=="Primary+Shift+Enter"&&check.Content!.ToString()!.Contains("⇧"),"custom shortcut persisted");font.Value=22;uiFont.Value=16;SaveSettings();Assert(source.FontSize==22&&FontSize==16&&check.FontSize==16,"independent UI and body fonts");font.Value=18;uiFont.Value=14;SetShortcut(CheckShortcut.Default);SaveSettings();
        SetSource(Example);await CheckAsync();Assert(result!.CacheHits>0,"repeated check reuses exact inputs");
        SetSource(new string('\n',45)+"他高兴的跳了起来。");await CheckAsync();UpdateLayout();SelectChange(result!.Changes.Last());UpdateLayout();Assert(outputScroll.Offset.Y>0,"number navigation scrolls actual document");
        SetSource(Example);await CheckAsync();settings.SaveDraft=true;result!.Changes[0].Accepted=false;TrySaveDraft();store.Save("settings.json",settings);
        var reopened=new MainWindow(store);reopened.Show();Assert(reopened.source.Text==source.Text&&reopened.result?.Corrected==result.Corrected&&!reopened.result!.Changes[0].Accepted,"reopened window restores source result and decisions");await reopened.QuitAsync();settings.SaveDraft=false;
        return passed;
    }
}
