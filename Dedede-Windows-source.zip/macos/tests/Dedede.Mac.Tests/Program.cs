using Avalonia;
using Avalonia.Headless;
using Avalonia.Threading;
using Dedede.Core;
using Dedede.Mac;
using System.Text.Json;
App.Testing=true;
AppBuilder.Configure<App>().UseSkia().UseHeadless(new AvaloniaHeadlessPlatformOptions{UseHeadlessDrawing=false}).SetupWithoutStarting();
using var stop=new CancellationTokenSource();int code=1;
Dispatcher.UIThread.Post(async()=>
{
    string temp=Path.Combine(Path.GetTempPath(),"DededeUiTest-"+Guid.NewGuid().ToString("N"));
    var window=new MainWindow(new LocalStore(temp),true);
    try{window.Show();int passed=await window.VerifyWorkflowAsync();if(args.Length>0)await window.CapturePreviewsAsync(args[0]);Console.WriteLine(JsonSerializer.Serialize(new{passed,platform=Environment.OSVersion.ToString(),realModel=true}));code=0;}
    catch(Exception ex){Console.Error.WriteLine(ex);}
    finally{await window.QuitAsync();stop.Cancel();}
});
Dispatcher.UIThread.MainLoop(stop.Token);return code;
