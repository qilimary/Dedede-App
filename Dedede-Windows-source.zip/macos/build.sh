#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
case "${1:-$(uname -m)}" in arm64|osx-arm64) rid=osx-arm64; arch=arm64; label=AppleSilicon;; x86_64|osx-x64) rid=osx-x64; arch=x86_64; label=Intel;; *) echo 'Use osx-arm64 or osx-x64'; exit 1;; esac
if [[ $(uname -s) != Darwin ]]; then echo 'Build this package on macOS with Xcode command line tools.'; exit 1; fi
if [[ ! -f ../windows/assets/models/HCAM_V2_5CHAR_INT8_PT.onnx ]]; then python3 -m pip install gdown==5.2.0; python3 ../windows/scripts/fetch_model.py; fi
python3 - <<'PY'
from pathlib import Path
import hashlib
for name,sha in {'HCAM_V2_5CHAR_INT8_PT.onnx':'15f0af5c03857ac2b049ac9f02cfe1dde2fba11ea639e191ca6453cb9a6e75cc','tokenizer.json':'bed4387895500314ffba9608340c56069ca6df8635029535b9becdef8ce7ddf0'}.items():
 assert hashlib.sha256(Path('../windows/assets/models',name).read_bytes()).hexdigest()==sha, name+' checksum mismatch'
PY
builddir=$(mktemp -d "$PWD/.package.XXXXXX")
app="$builddir/纠错 Pro.app"
publish="$app/Contents/MacOS"
mkdir -p "$publish/native" "$app/Contents/Resources" dist
# A separate temporary directory prevents stale files from a previous architecture entering the bundle.
dotnet restore src/Dedede.Mac/Dedede.Mac.csproj --locked-mode
dotnet publish src/Dedede.Mac/Dedede.Mac.csproj -c Release -r "$rid" --self-contained true --no-restore -o "$publish"
xcrun swiftc -swift-version 5 -O -target "$arch-apple-macos14.0" native/DededeNative.swift -framework AppKit -framework Vision -framework Carbon -framework ImageIO -framework UniformTypeIdentifiers -o "$publish/native/dedede-native"
chmod +x "$publish/Dedede" "$publish/native/dedede-native"
cp ../windows/docs/使用说明.html ../windows/THIRD-PARTY-NOTICES.txt "$publish/"
cp README.md "$publish/Mac-README.md"
mkdir "$builddir/App.iconset"
for size in 16 32 128 256 512; do
 sips -z "$size" "$size" ../windows/assets/app.png --out "$builddir/App.iconset/icon_${size}x${size}.png" >/dev/null
 double=$((size*2)); sips -z "$double" "$double" ../windows/assets/app.png --out "$builddir/App.iconset/icon_${size}x${size}@2x.png" >/dev/null
done
iconutil -c icns "$builddir/App.iconset" -o "$app/Contents/Resources/App.icns"
python3 - "$app" <<'PY'
import plistlib,sys,pathlib
info={'CFBundleExecutable':'Dedede','CFBundleIdentifier':'com.qilimary.dedede','CFBundleName':'纠错 Pro','CFBundleDisplayName':'纠错 Pro','CFBundleVersion':'1.2.0','CFBundleShortVersionString':'1.2.0','CFBundleInfoDictionaryVersion':'6.0','CFBundlePackageType':'APPL','CFBundleIconFile':'App.icns','LSMinimumSystemVersion':'14.0','NSHighResolutionCapable':True,'NSPrincipalClass':'NSApplication','NSHumanReadableCopyright':'奇 · Li的信箱','LSApplicationCategoryType':'public.app-category.productivity'}
pathlib.Path(sys.argv[1],'Contents','Info.plist').write_bytes(plistlib.dumps(info))
PY
identity=${DEDEDE_SIGN_IDENTITY:--}
export DEDEDE_PACKAGE_APP="$app" DEDEDE_PACKAGE_IDENTITY="$identity" DEDEDE_PACKAGE_ENTITLEMENTS="$PWD/entitlements.plist"
python3 - <<'PY'
import os,pathlib,subprocess
root=pathlib.Path(os.environ['DEDEDE_PACKAGE_APP']); identity=os.environ['DEDEDE_PACKAGE_IDENTITY']
base=['codesign','--force','--sign',identity]
if identity!='-':base+=['--timestamp','--options','runtime']
for p in sorted((root/'Contents/MacOS').rglob('*')):
 if p.is_file() and not p.is_symlink():
  with p.open('rb') as f: magic=f.read(4)
  if magic in (b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\xca\xfe\xba\xbe',b'\xbe\xba\xfe\xca'):
   subprocess.run(base+['--entitlements',os.environ['DEDEDE_PACKAGE_ENTITLEMENTS'],str(p)],check=True)
subprocess.run(base+['--entitlements',os.environ['DEDEDE_PACKAGE_ENTITLEMENTS'],str(root)],check=True)
PY
codesign --verify --deep --strict --verbose=2 "$app"
if [[ ${DEDEDE_SKIP_TESTS:-0} != 1 ]]; then
 "$publish/Dedede" --smoke-test "$PWD/dist/smoke-$rid.json"
 dotnet run --project tests/Dedede.Mac.Tests/Dedede.Mac.Tests.csproj -c Release -- "$PWD/dist/previews-$label"
fi
if [[ -n ${DEDEDE_NOTARY_PROFILE:-} ]]; then
 if [[ $identity == - ]]; then echo 'Notarization requires a Developer ID Application certificate.'; exit 1; fi
 ditto -c -k --keepParent "$app" "$builddir/notarize.zip"
 xcrun notarytool submit "$builddir/notarize.zip" --keychain-profile "$DEDEDE_NOTARY_PROFILE" --wait
 xcrun stapler staple "$app"
fi
stage="$builddir/dmg";mkdir "$stage";mv "$app" "$stage/";ln -s /Applications "$stage/Applications";cp README.md "$stage/安装说明.md"
hdiutil create -volname '纠错 Pro' -srcfolder "$stage" -ov -format UDZO "dist/Dedede-Mac-$label.dmg"
if [[ -n ${DEDEDE_NOTARY_PROFILE:-} ]]; then
 xcrun notarytool submit "dist/Dedede-Mac-$label.dmg" --keychain-profile "$DEDEDE_NOTARY_PROFILE" --wait
 xcrun stapler staple "dist/Dedede-Mac-$label.dmg"
fi
# Only remove the temporary directory created by mktemp above.
python3 - "$builddir" <<'PY'
import pathlib,shutil,sys
p=pathlib.Path(sys.argv[1]);assert p.parent==pathlib.Path.cwd() and p.name.startswith('.package.');shutil.rmtree(p)
PY
printf 'Ready: macos/dist/Dedede-Mac-%s.dmg\n' "$label"
